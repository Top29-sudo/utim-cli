"""
UTIM Orchestrator — Manages the full agentic loop.

Architecture:
  - Maintains local message history (system prompt + conversation)
  - For each user message, runs a ReAct loop:
      1. Calls LLM via the UTIM server (/completions, streaming) — keeps API key off client
      2. Content tokens are written to stdout in real-time as they arrive
      3. If the LLM returns tool_calls, executes them locally (filesystem tools)
      4. Feeds tool results back into the loop
      5. Repeats until the LLM responds with plain text (no more tool calls)
  - Falls back to calling OpenRouter directly if the server is unreachable
"""
from __future__ import annotations

import difflib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

import requests
from utim_cli.constants import DEFAULT_MODEL
# openai SDK removed — we call OpenRouter directly via requests (no Rust/jiter needed)
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from rich.spinner import Spinner
from rich.text import Text

from .tools import get_tools
import utim_cli.tools as _tools_module   # for injecting cancel_event
from .config import config

# ─── Dynamic Context Budget ─────────────────────────────────────────────────
def _get_model_max_output(model_id: str, fallback: int = 32_768) -> int:
    """Return the model's real max completion tokens from the registry, or user config."""
    try:
        settings = config.get(f"model_settings_{model_id}")
        if settings and isinstance(settings, dict) and "max_tokens" in settings:
            return settings["max_tokens"]
        from utim_cli.server.models import get_max_output_tokens
        return get_max_output_tokens(model_id, fallback=fallback)
    except Exception:
        return fallback


def _extract_write_file_calls(content: str) -> list:
    """Parse large fenced code blocks from a plain-text model response and
    convert them into ``write_file`` tool-call dicts.

    This recovers content when a model outputs code as prose instead of calling
    the write_file tool, preventing expensive generations from being wasted.

    Only activates for code blocks ≥ 40 lines.  Filename is inferred from:
      1. Inline hint on the opening fence line  (e.g. ````html index.html``)
      2. The closest "filename.ext" pattern in the 3 lines *before* the block
      3. Language-to-extension mapping as a last resort

    Returns a list of OpenAI-style tool call dicts (may be empty).
    """
    import json, re, uuid

    # Map common fence languages to default filenames when no hint is found
    _LANG_DEFAULTS: dict = {
        "html": "index.html",
        "css": "style.css",
        "javascript": "script.js",
        "js": "script.js",
        "typescript": "index.ts",
        "ts": "index.ts",
        "python": "main.py",
        "py": "main.py",
        "json": "data.json",
        "yaml": "config.yaml",
        "yml": "config.yml",
        "bash": "script.sh",
        "sh": "script.sh",
        "sql": "query.sql",
        "go": "main.go",
        "rust": "main.rs",
        "cpp": "main.cpp",
        "c": "main.c",
        "java": "Main.java",
    }

    # Regex: captures opening fence (with optional language + filename hint),
    # the block content, and the closing fence.
    _FENCE_RE = re.compile(
        r"```(?P<lang>[a-zA-Z0-9_+-]*)[ \t]*(?P<hint>[^\n]*)\n"
        r"(?P<code>.*?)"
        r"```",
        re.DOTALL,
    )

    # Filename pattern (for scanning lines before the block)
    _FNAME_RE = re.compile(
        r"\b([\w./\\-]+\.(html|css|js|ts|jsx|tsx|py|json|yaml|yml|sh|bash|go|rs|cpp|c|java|sql|txt|md))\b",
        re.IGNORECASE,
    )

    tool_calls = []
    lines = content.split("\n")

    for m in _FENCE_RE.finditer(content):
        code_body = m.group("code")
        if code_body.count("\n") < 40:
            continue  # skip short snippets

        lang = m.group("lang").strip().lower()
        hint = m.group("hint").strip()

        # 1. Try filename from fence hint line
        fname = None
        if hint:
            fn_m = _FNAME_RE.search(hint)
            if fn_m:
                fname = fn_m.group(1)

        # 2. Scan the 3 lines before the opening fence
        if not fname:
            block_start_pos = m.start()
            pre_text = content[:block_start_pos]
            pre_lines = pre_text.rstrip().split("\n")[-3:]
            for pre_line in reversed(pre_lines):
                fn_m = _FNAME_RE.search(pre_line)
                if fn_m:
                    fname = fn_m.group(1)
                    break

        # 3. Fall back to language default
        if not fname:
            fname = _LANG_DEFAULTS.get(lang)

        if not fname:
            continue  # can't determine filename — skip

        call_id = f"auto_{uuid.uuid4().hex[:8]}"
        tool_calls.append({
            "id": call_id,
            "type": "function",
            "function": {
                "name": "write_file",
                "arguments": json.dumps({
                    "path": fname,
                    "content": code_body,
                    "overwrite": True,
                }),
            },
        })

    return tool_calls


def _get_compression_threshold(model_id: str, context_window: int) -> int:
    """Calculate dynamic compression threshold based on model's context window.
    
    We set the safety net auto-compression threshold to 90% of the model's actual physical context window,
    so that auto-compression only runs when absolutely necessary to prevent context overflow.
    """
    if not context_window or context_window <= 0:
        context_window = 128_000
    return int(context_window * 0.90)

from utim_cli.config import get_utim_dir
_utim_dir_posix = get_utim_dir().as_posix()

# System Prompt
SYSTEM_PROMPT = f"""You are UTIM AI, a high-agency senior software engineer operating autonomously inside a CLI. You focus purely on the technical project or task at hand.

### CORE DIRECTIVES:
1. **Explore & Route**: Classify the task immediately:
   - *Surgical/Localized* (styling, copy edits, single-file changes): Limit context gathering to the target file and central conventions. Use `query_codebase`. Avoid global listings.
   - *Architectural/System-Wide*: Map project structure and dependencies.
2. **Planning/Autonomous Tooling**: Do not wait for permissions. Use tools (`edit_file`, `write_file`, `run_command`, `project_res`, `plan_project`, `manage_todos`) proactively to achieve the goal. No placeholders or stubs.
3. **Think-Create-Verify**: ALWAYS use the `plan_project` tool to formulate a plan before taking any mutating actions. NEVER outline or generate the plan yourself in plain text. Track tasks, write code, and ALWAYS verify with execution (`run_command` -> build/test/run) rather than just reading files.
4. **Manifesto Reference**: Detailed engineering rules, coding standards, and safety/sandbox instructions are in {_utim_dir_posix}/UTIM.md. Read/reference it only when specific guidance is needed.
5. **Output**: Be concise and professional. Summarize all changes and test results when complete. Speak colloquially and warmly in the user's language.
6. **Execution**: When executing tools to get the project ready always create a todo list and follow them to the end. Add todos based on detailed steps.
7. **Tool Calling format**: You MUST use the native JSON-schema function-calling mechanism provided by the API to invoke tools. NEVER output raw JSON, <think to=...> tags, <|message|> tags, or other raw tool-call markup in your text response. Any tool usage must be strictly structured via the API.
8. **Premium Web Design**: When creating, updating, or styling web user interfaces, read/reference `{_utim_dir_posix}/DESIGN.md` to apply modern visual design conventions (such as premium typography, HSL color themes, glassmorphism, and smooth animations) instead of default browser styles or raw colors.
"""

# ─── Runtime environment detection ───────────────────────────────────────────

def _detect_environment() -> str:
    """Detect the runtime environment and return a context string for the prompt."""
    import platform, os

    is_termux   = os.path.isdir("/data/data/com.termux")
    is_wsl      = "microsoft" in platform.uname().release.lower()
    system      = platform.system()   # 'Linux', 'Windows', 'Darwin'
    machine     = platform.machine()  # 'x86_64', 'aarch64', etc.
    home        = os.path.expanduser("~")
    cwd         = os.getcwd()
    shell       = os.environ.get("SHELL", os.environ.get("COMSPEC", "unknown"))

    lines = ["\n\nRUNTIME ENVIRONMENT (auto-detected):"]
    lines.append(f"- OS: {system} ({machine})")
    lines.append(f"- Shell: {shell}")
    lines.append(f"- Home: {home}")
    lines.append(f"- Working directory: {cwd}")

    if is_termux:
        lines += [
            "- Platform: Android Termux",
            "- Package manager: pkg (use `pkg install <name>` not apt/brew/choco)",
            "- Home path: /data/data/com.termux/files/home",
            "- No sudo — Termux is already a user-level Linux environment",
            "- Node.js, Python, git, curl all available via `pkg install`",
            "- The user is on a MOBILE DEVICE (Android). Keep file paths short,",
            "  avoid opening browsers or GUIs, prefer terminal-based workflows.",
            "- Do NOT suggest desktop editors (VS Code, etc.) — use nano/vim instead.",
        ]
    elif is_wsl:
        lines += [
            "- Platform: Windows Subsystem for Linux (WSL)",
            "- Package manager: apt (sudo apt install <name>)",
            "- Windows drives mounted at /mnt/c, /mnt/d, etc.",
            "- Can run both Linux and Windows commands",
        ]
    elif system == "Windows":
        lines += [
            "- Platform: Windows (native PowerShell/CMD)",
            "- Package manager: winget, choco, or scoop",
            "- Use PowerShell syntax for shell commands",
            "- Use backslashes or raw strings for paths when needed",
            "- **CRITICAL**: '&&' and '||' are NOT valid in PowerShell. Use ';' to chain commands.",
            "  WRONG: npm test && npm run build",
            "  RIGHT: npm test ; npm run build",
        ]
    elif system == "Darwin":
        lines += [
            "- Platform: macOS",
            "- Package manager: brew (brew install <name>)",
        ]
    elif system == "Linux":
        lines += [
            "- Platform: Linux",
            "- Package manager: apt / dnf / pacman depending on distro",
        ]

    return "\n".join(lines)


# Build the prompt once at import time (environment is stable per process)
SYSTEM_PROMPT = SYSTEM_PROMPT + _detect_environment()

COMPRESSED_SYSTEM_PROMPT = f"""You are UTIM AI, a high-agency senior CLI software engineer.

### CORE DIRECTIVES:
1. **Explore & Route**: Localized (styling, edits): Target file/conventions. System-wide: Map dependencies.
2. **Planning/Autonomous**: Use tools (`edit_file`, `write_file`, `run_command`, `project_res`, `plan_project`, `manage_todos`) proactively. No stubs.
3. **Think-Create-Verify**: ALWAYS use `plan_project` to formulate a plan before writing. Verify with `run_command` (build/test/run), do not just read.
4. **Manifesto**: Safety and coding standards are in {_utim_dir_posix}/UTIM.md.
5. **Output**: Be concise, professional. Speak colloquially/warmly.
6. **Execution**: Create and follow a detailed todo list to the end.
7. **Tool Calling**: Use native function-calling. No raw JSON, `<think>` tags, or raw tool markup in text responses.
8. **Premium Web Design**: Style web UIs per `{_utim_dir_posix}/DESIGN.md` (premium typography, HSL colors, glassmorphism, animations).
"""

def _detect_environment_compressed() -> str:
    """Detect the runtime environment and return a compressed context string."""
    import platform, os
    is_termux   = os.path.isdir("/data/data/com.termux")
    is_wsl      = "microsoft" in platform.uname().release.lower()
    system      = platform.system()
    shell       = os.environ.get("SHELL", os.environ.get("COMSPEC", "unknown"))
    cwd         = os.getcwd()

    lines = ["\n\nENV:"]
    lines.append(f"- OS: {system} | Shell: {shell} | CWD: {cwd}")
    if is_termux:
        lines.append("- Termux: pkg manager, user-level Linux, mobile device.")
    elif is_wsl:
        lines.append("- WSL: apt, Windows mount at /mnt/c.")
    elif system == "Windows":
        lines.append("- Windows (PowerShell/CMD). PowerShell syntax. CRITICAL: Use ';' instead of '&&'/'||'.")
    elif system == "Darwin":
        lines.append("- macOS: brew.")
    elif system == "Linux":
        lines.append("- Linux.")
    return "\n".join(lines)


def is_casual_message(prompt: str) -> bool:
    if not prompt:
        return True
    p = prompt.strip().lower().rstrip("?.!")
    if not p:
        return True
    
    casual_words = {
        "hello", "hi", "hey", "yo", "sup", "hola", "greetings", "good morning", "good afternoon", "good evening",
        "how are you", "how's it going", "howdy", "hi there", "hello there", "test", "testing", "ping", "clear",
        "exit", "quit", "menu", "help", "restart", "reset", "ok", "okay", "yes", "no", "thanks", "thank you",
        "nice", "cool", "sure", "fine", "awesome", "perfect", "good", "great", "hello!", "hi!"
    }
    
    if p in casual_words:
        return True
        
    # If the message is very short (e.g. less than 15 chars) and doesn't contain code/paths/technical symbols
    if len(p) <= 15:
        # Heuristics: if it doesn't contain slashes, backslashes, dots, underscores, braces, or brackets
        import re
        if not re.search(r'[./_\\{}()\[\]=+\-*<>]', p):
            # Check if it has any common casual words as substrings
            for w in casual_words:
                if w in p:
                    return True
            # Otherwise, check if it's purely letters and spaces
            if re.match(r'^[a-z\s]+$', p):
                return True
                
    return False

def estimate_tokens(text: str) -> int:
    """Estimate token count based on typical ~4 chars per token ratio."""
    return len(text) // 4

def compress_experience(text: str) -> str:
    """Shorten common verbose patterns to compress experiences/lessons and conserve context window space."""
    t = text.strip()
    replacements = {
        "Windows PowerShell": "PowerShell",
        "the && operator is not supported": "no &&",
        "do not use '&&' as a statement separator because it is invalid and throws a ParserError. Instead, use a semicolon ';' to chain commands or run them separately.": "use ';' instead of '&&'",
        "do not use '&&' as a statement separator. Instead, use a semicolon ';' to chain commands.": "use ';' instead of '&&'",
        "do not use && as a statement separator. Instead, use a semicolon ;": "use ';' instead of '&&'",
        "Use a semicolon ; to separate commands instead": "use ';'",
        "Sequential tool workflow observed": "Workflow",
        "broad search → inspect result → identify noise/inconsistency": "search → inspect → target",
        "Always run pytest": "Run pytest",
        "before final commit": "before commit",
        "Todo tracking for bug fixes and feature implementation": "Track bugs/features in todos"
    }
    for old, new in replacements.items():
        t = t.replace(old, new)
    return t

_qwen_model = None
_qwen_tokenizer = None
_qwen_downloading = False

def _trigger_qwen_download_bg():
    """Trigger background download and caching of Qwen local model if not already loaded or downloading."""
    global _qwen_model, _qwen_tokenizer, _qwen_downloading
    if _qwen_model is None and not _qwen_downloading:
        import sys
        if "pytest" in sys.modules:
            return
        
        _qwen_downloading = True
        import threading
        
        def download_model_bg():
            global _qwen_model, _qwen_tokenizer, _qwen_downloading
            try:
                import torch
                from transformers import AutoModelForCausalLM, AutoTokenizer
                model_id = "Qwen/Qwen2.5-0.5B-Instruct"
                tok = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True, local_files_only=False)
                mod = AutoModelForCausalLM.from_pretrained(
                    model_id,
                    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                    device_map="auto",
                    trust_remote_code=True,
                    local_files_only=False
                )
                _qwen_tokenizer = tok
                _qwen_model = mod
            except Exception:
                pass
            finally:
                _qwen_downloading = False
                
        t = threading.Thread(target=download_model_bg, daemon=True)
        t.start()

def summarize_experiences_with_model(experiences: list[dict], existing_cache: str = "") -> str:
    """Summarize list of experiences into a clean list of rules under 2000 tokens using local Qwen model first, falling back to LLM API."""
    if not experiences:
        return existing_cache
        
    raw_texts = []
    for idx, e in enumerate(experiences):
        c = str(e.get("content", "")).strip().replace("\n", " ")
        if c:
            raw_texts.append(f"- {c}")
            
    if not raw_texts:
        return existing_cache
        
    raw_block = "\n".join(raw_texts)
    
    if existing_cache:
        prompt = (
            "You are an expert context compressor and rules merger.\n"
            "You will be given a list of existing rules and a set of new technical learnings/preferences.\n"
            "Your task is to merge the new learnings into the existing list of rules, removing redundancies "
            "and keeping the output consolidated, action-oriented, and high-density.\n\n"
            "Rules to follow:\n"
            "1. Do NOT repeat similar rules; merge them into single clear guidelines.\n"
            "2. Keep the rules action-oriented (e.g. 'Use semicolon instead of && in PowerShell').\n"
            "3. Preserve critical syntax details, library name changes, and language preferences.\n"
            "4. Categorize each rule by prefixing it with exactly one of these tags:\n"
            "   - [SHELL_CONVENTION] for command execution, terminal operators, powershell rules.\n"
            "   - [CODING_STYLE] for language preference, libraries, styling conventions.\n"
            "   - [BUG_FIX] for error/failure corrections and debug tips.\n"
            "   - [USER_PREF] for user likes and dislikes.\n"
            "   - [GENERAL_RULE] for any other guidelines.\n"
            "5. Format the output as a clean markdown list of tagged rules.\n\n"
            f"Existing rules:\n{existing_cache}\n\n"
            f"New learnings to merge:\n{raw_block}\n\n"
            "Output ONLY the clean markdown list of merged rules (do not include introductory or concluding text):"
        )
    else:
        prompt = (
            "You are an expert context compressor. You will be given a list of technical learnings, "
            "rules, and user preferences retrieved from our experience memory database. "
            "Your task is to consolidate and summarize them into a clean, unified, high-density list of "
            "rules (under 2000 tokens total) that the coding agent must strictly follow.\n\n"
            "Rules to follow:\n"
            "1. Do NOT repeat similar rules; merge them into single clear guidelines.\n"
            "2. Keep the rules action-oriented (e.g. 'Use semicolon instead of && in PowerShell').\n"
            "3. Preserve critical syntax details, library name changes, and language preferences.\n"
            "4. Categorize each rule by prefixing it with exactly one of these tags:\n"
            "   - [SHELL_CONVENTION] for command execution, terminal operators, powershell rules.\n"
            "   - [CODING_STYLE] for language preference, libraries, styling conventions.\n"
            "   - [BUG_FIX] for error/failure corrections and debug tips.\n"
            "   - [USER_PREF] for user likes and dislikes.\n"
            "   - [GENERAL_RULE] for any other guidelines.\n"
            "5. Format the output as a clean markdown list of tagged rules.\n\n"
            f"Input experiences:\n{raw_block}\n\n"
            "Output ONLY the clean markdown list of rules (do not include introductory or concluding text):"
        )

    # Proactively trigger Qwen local model download in a background thread if needed
    _trigger_qwen_download_bg()

    # 1. Attempt Cloud API completions (via UTIM completions server or direct OpenRouter)
    import os
    api_key = config.get("api_key")
    llm_key = os.environ.get("OPENROUTER_API_KEY") or os.environ.get("UTIM_API_KEY")
    
    if api_key or llm_key:
        from utim_cli.reflection import REFLECTION_MODELS
        from utim_cli.client_utils import proxy_openrouter_request
        
        for model in REFLECTION_MODELS:
            try:
                resp = proxy_openrouter_request({
                    "model": model,
                    "messages": [
                        {"role": "system", "content": "You are a context compressor. Output rules list directly."},
                        {"role": "user", "content": prompt}
                    ],
                    "max_tokens": 1000
                })
                if resp.status_code == 200:
                    content = resp.json()["choices"][0]["message"]["content"].strip()
                    if content:
                        return content
            except Exception:
                continue

    # 2. Fallback to local execution using Qwen2.5-0.5B-Instruct if background loader has completed
    global _qwen_model, _qwen_tokenizer
    if _qwen_model is not None:
        try:
            import torch
            messages = [
                {"role": "system", "content": "You are a context compressor. Output rules list directly."},
                {"role": "user", "content": prompt}
            ]
            
            text = _qwen_tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )
            model_inputs = _qwen_tokenizer([text], return_tensors="pt").to(_qwen_model.device)
            
            with torch.no_grad():
                generated_ids = _qwen_model.generate(
                    **model_inputs,
                    max_new_tokens=1024,
                    temperature=0.1,
                    do_sample=False
                )
                
            generated_ids = [
                output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
            ]
            response = _qwen_tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0].strip()
            if response:
                return response
        except Exception:
            pass

    return existing_cache or "\n".join(raw_texts[:15])

def update_experience_summary_cache(user_prompt: str) -> str:
    """Fetch relevant experiences, expand queries for potential tool usage,
    summarize them using an LLM reflection model, and cache the result.
    """
    if not user_prompt:
        return ""
        
    try:
        import os
        from utim_cli.vector_memory import fetch_relevant_experiences
        from utim_cli.situational_scoring import score_and_filter_context
        
        os.makedirs(".utim_tmp", exist_ok=True)
        cache_path = ".utim_tmp/summarized_experiences_cache.txt"
        dirty_path = ".utim_tmp/experience_cache_dirty.txt"
        
        existing_cache = ""
        if os.path.exists(cache_path):
            try:
                with open(cache_path, "r", encoding="utf-8") as f:
                    existing_cache = f.read().strip()
            except Exception:
                pass
                
        # Feature 4: Incremental Memory Merging - Reuse cache if not dirty
        if existing_cache and not os.path.exists(dirty_path):
            return existing_cache
            
        active_task = _get_active_task(user_prompt)
        
        # 1. Expand queries to cover ALL aspects of UTIM usage and experience:
        # A. Task-Specific Context (semantic domain of current user task)
        task_exps = fetch_relevant_experiences(active_task, top_k=15)
        
        # B. User Preferences, Likes, and Dislikes (what the user wants/prefers)
        pref_exps = fetch_relevant_experiences("user preferences likes dislikes formatting styles language code constraints", top_k=8)
        
        # C. General Architectural Conventions, Rules, and System Guidelines
        rules_exps = fetch_relevant_experiences("architectural rules system conventions project guidelines failure corrections", top_k=8)
        
        # D. Operational Command and Tool Execution Syntax (PowerShell, file operations)
        op_exps = fetch_relevant_experiences("command syntax terminal execution operator file read write edit path", top_k=8)
        
        # E. Conceptual Pattern Matching (dot connections, analogies, object & relationship insights)
        pattern_exps = fetch_relevant_experiences("object relationship patterns concept analogies dot connections matching", top_k=8)
        
        # Merge all
        all_exps = task_exps + pref_exps + rules_exps + op_exps + pattern_exps
        
        # Deduplicate
        seen_content = set()
        unique_exps = []
        for e in all_exps:
            c = str(e.get("content", "")).strip()
            if c and c not in seen_content:
                metadata = e.get("metadata") or {}
                category = metadata.get("category")
                if category == "task_experience" or c.startswith("Task:"):
                    continue
                seen_content.add(c)
                unique_exps.append(e)
                
        # Re-score using situational scoring
        scored_exps = score_and_filter_context(unique_exps, active_task, limit=len(unique_exps))
        
        # Feature 1: Semantic Relevance Filtering (Zero-Token Baseline)
        # Drop experiences that fall below similarity threshold (situational_score < 0.45)
        scored_exps = [e for e in scored_exps if e.get("situational_score", 1.0) >= 0.45]
        
        # 2. Run model-based summarization (incremental merging if existing_cache exists)
        summary = summarize_experiences_with_model(scored_exps, existing_cache=existing_cache)
        
        # 3. Cache the summary
        with open(cache_path, "w", encoding="utf-8") as f:
            f.write(summary)
            
        # Clear the dirty flag
        if os.path.exists(dirty_path):
            try:
                os.remove(dirty_path)
            except Exception:
                pass
                
        return summary
    except Exception as e:
        from utim_cli.logger import log_error
        log_error("orchestrator", "Failed to update experience summary cache", e)
        return ""

def _get_active_task(user_prompt: str) -> str:
    """Determine the current active objective or fallback to the user prompt."""
    import os, json
    todo_file = ".utim_tmp/todos.json"
    if os.path.exists(todo_file):
        try:
            with open(todo_file, "r", encoding="utf-8") as f:
                todos = json.load(f)
            if todos and isinstance(todos, dict):
                for tid, t in todos.items():
                    if t.get("status") != "done":
                        desc = t.get("description", "").strip()
                        if desc:
                            return desc
        except Exception:
            pass
    return user_prompt

def _get_dynamic_directives(is_compressed: bool, messages: Optional[List[Dict]] = None) -> str:
    from pathlib import Path
    _skills_posix = Path(".utim_tmp/skills").resolve().as_posix()
    from utim_cli.config import get_utim_dir
    _posix = get_utim_dir().as_posix()
    
    skills_list_str = ""
    try:
        from utim_cli.bootstrap import scan_available_skills
        _skills_dict = scan_available_skills()
        if _skills_dict:
            lines = []
            for name, info in _skills_dict.items():
                already_read = False
                if messages:
                    for m in messages:
                        if m.get("role") == "assistant" and m.get("tool_calls"):
                            for tc in m.get("tool_calls", []):
                                if tc.get("function", {}).get("name") == "view_file":
                                    args = tc.get("function", {}).get("arguments", "")
                                    if isinstance(args, str):
                                        try:
                                            import json
                                            args_dict = json.loads(args)
                                        except:
                                            args_dict = {}
                                    else:
                                        args_dict = args or {}
                                    path = args_dict.get("AbsolutePath", "")
                                    if name in path.replace("\\", "/"):
                                        already_read = True
                                        break
                        if m.get("role") == "tool" and m.get("name") == "view_file":
                            content = str(m.get("content", ""))
                            if f"RELEVANT CORE SKILL: {name.upper()}" in content:
                                already_read = True
                                break
                        if already_read:
                            break
                if already_read:
                    continue
                p = Path(info["path"]).resolve().as_posix()
                lines.append(f"    - `{name}`: [{info['name']}](file:///{p}) - {info.get('description', '')}")
            skills_list_str = "\n  Currently available skills in the workspace (use `read_file` or `view_file` to read them directly using their path):\n" + "\n".join(lines)
        else:
            skills_list_str = "\n  (Currently no custom or workspace-scoped skills are configured.)"
    except Exception as e:
        skills_list_str = f"\n  (Error scanning skills: {str(e)})"

    from utim_cli.config import config
    disabled = config.get("disabled_tools") or []
    if not isinstance(disabled, list):
        disabled = []

    # Derive the real enabled tool names from the actual tool registry
    try:
        from utim_cli.tools import get_tools as _gt
        _all_real = [t["function"]["name"] for t in _gt()[0]]
    except Exception:
        _all_real = ["edit_file", "write_file", "run_command", "read_file",
                     "list_directory", "query_codebase", "plan_project", "manage_todos"]

    enabled_tools = [t for t in _all_real if t not in disabled]
    all_disabled = len(enabled_tools) == 0 and len(_all_real) > 0

    has_query_codebase = "query_codebase" in enabled_tools
    has_plan_project   = "plan_project"   in enabled_tools
    has_run_command    = "run_command"    in enabled_tools

    # ── When ALL tools are disabled, emit a minimal override directive ────────
    # The model must understand it has zero capabilities and answer accordingly.
    if all_disabled:
        return (
            "### TOOL STATUS: ALL TOOLS DISABLED\n"
            "The user has disabled every tool. You have NO tools available whatsoever — "
            "no read_file, no write_file, no run_command, nothing. "
            "Do NOT pretend to have tools. Do NOT attempt to call any tool. "
            "If asked what tools you have, respond honestly: \"I currently don't have any tools — "
            "all tools are disabled. You can enable them using /tools.\"\n"
            "You may only respond in text. You cannot read files, run commands, or take any action.\n"
        )
    # ── Normal directives when some tools are available ───────────────────────
    if is_compressed:
        directives = ["### CORE DIRECTIVES:"]

        if has_query_codebase:
            directives.append("1. **Explore & Route**: Localized (styling, edits): Target file/conventions. Use `query_codebase`. Avoid global listings.")
        else:
            directives.append("1. **Explore & Route**: Localized (styling, edits): Target file/conventions. Avoid global listings.")

        if enabled_tools:
            tools_str = ", ".join(f"`{t}`" for t in enabled_tools)
            directives.append(f"2. **Planning/Autonomous**: Use tools ({tools_str}) proactively. No stubs.")
        else:
            directives.append("2. **Planning/Autonomous**: No tools are currently enabled. Do NOT attempt to call any tools.")

        if has_plan_project and has_run_command:
            directives.append("3. **Think-Create-Verify**: Start executing right away. You do NOT need to write a plan or preamble in text before calling tools. Output tool calls immediately, then explain results or check tests. Verify with `run_command` (build/test/run), do not just read.")
        elif has_plan_project:
            directives.append("3. **Think-Create-Verify**: Start executing right away. You do NOT need to write a plan or preamble in text before calling tools. Output tool calls immediately, then explain results or check tests.")
        elif has_run_command:
            directives.append("3. **Think-Create-Verify**: Start executing right away. You do NOT need to write a plan or preamble in text before calling tools. Output tool calls immediately, then explain results or check tests. Verify with `run_command` (build/test/run), do not just read.")
        else:
            directives.append("3. **Think-Create-Verify**: Start executing right away. You do NOT need to write a plan or preamble in text before calling tools. Output tool calls immediately, then explain results or check tests.")

        directives.append(f"4. **Manifesto**: Safety and coding standards are in {_posix}/UTIM.md.")
        directives.append("5. **Output**: Be concise and professional. Summarize all changes and test results when complete. Speak colloquially and warmly. If you notice other code smells, potential bugs, or logical issues in the code snippets you read during execution, list them as proposed improvements in your final summary for the user instead of fixing them immediately.")
        directives.append("6. **Execution**: Avoid announcing what you are going to do or writing text-only planning steps. Just invoke the appropriate tool call directly. You may explain your reasoning in the same message alongside the tool call if needed, but the tool call MUST be present if there is work to do.")
        directives.append("7. **Tool Calling**: Use native function-calling. Avoid conversational preamble. Do not output raw JSON, `<think>` tags, or raw tool markup in text responses.")
        directives.append(f"8. **Premium Web Design**: Style web UIs per `{_posix}/DESIGN.md` (premium typography, HSL colors, glassmorphism, animations).")
        directives.append("9. **Hint Guidance**: Follow any `[Secret Hint Guidance: <instruction>]` prefix in the user prompt as a high-priority system directive.")
        directives.append("10. **Speed & Safety Balance**: Trust your edits. Do NOT waste tokens/time calling `read_file` or `view_file` immediately after writing or editing just to verify. Instead, verify safety instantly by running a compilation, build, or test command via `run_command`. Only re-read files if compilation/tests fail or return errors.")
        directives.append(f"11. **Workspace Skills**: Custom and reflection-created skills are located in `{_skills_posix}/`. Read or reference them to guide your behavior when relevant to the task.{skills_list_str}")

    else:
        directives = ["### CORE DIRECTIVES:"]

        if has_query_codebase:
            directives.append("1. **Explore & Route**: Classify the task immediately:\n"
                              "   - *Surgical/Localized* (styling, copy edits, single-file changes): Limit context gathering to the target file and central conventions. Use `query_codebase`. Avoid global listings.\n"
                              "   - *Architectural/System-Wide*: Map project structure and dependencies.")
        else:
            directives.append("1. **Explore & Route**: Classify the task immediately:\n"
                              "   - *Surgical/Localized* (styling, copy edits, single-file changes): Limit context gathering to the target file and central conventions. Avoid global listings.\n"
                              "   - *Architectural/System-Wide*: Map project structure and dependencies.")

        if enabled_tools:
            tools_str = ", ".join(f"`{t}`" for t in enabled_tools)
            directives.append(f"2. **Planning/Autonomous Tooling**: Do not wait for permissions. Use tools ({tools_str}) proactively to achieve the goal. No placeholders or stubs.")
        else:
            directives.append("2. **Planning/Autonomous Tooling**: No tools are currently enabled. Do NOT attempt to use any tools.")

        if has_plan_project and has_run_command:
            directives.append("3. **Think-Create-Verify**: Start executing right away. You do NOT need to write a detailed plan or preamble in text before calling tools. Output tool calls immediately, then explain results or check tests. Verify with execution (`run_command` -> build/test/run) rather than just reading files.")
        elif has_plan_project:
            directives.append("3. **Think-Create-Verify**: Start executing right away. You do NOT need to write a detailed plan or preamble in text before calling tools. Output tool calls immediately, then explain results or check tests.")
        elif has_run_command:
            directives.append("3. **Think-Create-Verify**: Start executing right away. You do NOT need to write a detailed plan or preamble in text before calling tools. Output tool calls immediately, then explain results or check tests. Verify with execution (`run_command` -> build/test/run) rather than just reading files.")
        else:
            directives.append("3. **Think-Create-Verify**: Start executing right away. You do NOT need to write a detailed plan or preamble in text before calling tools. Output tool calls immediately, then explain results or check tests.")

        directives.append(f"4. **Manifesto Reference**: Detailed engineering rules, coding standards, and safety/sandbox instructions are in {_posix}/UTIM.md. Read/reference it only when specific guidance is needed.")
        directives.append("5. **Output**: Be concise and professional. Summarize all changes and test results when complete. Speak colloquially and warmly in the user's language. If you notice other code smells, potential bugs, or logical issues in the code snippets you read during execution, list them as proposed improvements in your final summary for the user instead of fixing them immediately.")
        directives.append("6. **Execution**: Avoid announcing what you are going to do or writing text-only planning steps. Just invoke the appropriate tool call directly. You may explain your reasoning in the same message alongside the tool call if needed, but the tool call MUST be present if there is work to do.")
        directives.append("7. **Tool Calling format**: You MUST use the native JSON-schema function-calling mechanism provided by the API to invoke tools. Avoid conversational preamble. NEVER output raw JSON, <think to=...> tags, <|message|> tags, or other raw tool-call markup in your text response. Any tool usage must be strictly structured via the API.")
        directives.append(f"8. **Premium Web Design**: When creating, updating, or styling web user interfaces, read/reference `{_posix}/DESIGN.md` to apply modern visual design conventions (such as premium typography, HSL color themes, glassmorphism, and smooth animations) instead of default browser styles or raw colors.")
        directives.append("9. **Secret Hint Guidance**: If a user message begins with `[Secret Hint Guidance: <instruction>]`, you MUST treat that instruction as a high-priority system-level override directive. Customize your reasoning, tool selection, explanation detail, and output formatting to strictly adhere to that instruction throughout the entire task execution.")
        directives.append("10. **Speed & Safety Balance**: Trust your edits. Do NOT waste tokens/time calling `read_file` or `view_file` immediately after writing or editing just to verify. Instead, verify safety instantly by running a compilation, build, or test command via `run_command`. Only re-read files if compilation/tests fail or return errors.")
        directives.append(f"11. **Workspace Skills**: Custom and reflection-created skills are located in `{_skills_posix}/`. Read or reference them to guide your behavior when relevant to the task.{skills_list_str}")

    return "\n".join(directives)

def get_system_prompt(user_prompt: str = "", current_iteration: int = 0, elapsed_seconds: int = 0, turn_history: Optional[List[Dict]] = None, messages: Optional[List[Dict]] = None) -> str:
    """Gets the dynamic system prompt with active MCP servers and semantically fetched Hugging Face vector memories."""
    # If the user prompt is just a casual greeting/message, return a minimal prompt to save tokens
    if user_prompt and is_casual_message(user_prompt):
        return "You are UTIM AI. Respond warmly and concisely in under 2 sentences without repeating long introductory lists of your roles or capabilities."

    # 1. Determine base system prompt and experience token limit based on iteration count
    if current_iteration == 0:
        identity = "You are UTIM AI, a high-agency senior software engineer operating autonomously inside a CLI. You focus purely on the technical project or task at hand.\n\n"
        base_prompt = identity + _get_dynamic_directives(is_compressed=False, messages=messages) + _detect_environment()
        exp_token_limit = 1000
        is_first = True
    else:
        identity = "You are UTIM AI, a high-agency senior CLI software engineer.\n\n"
        base_prompt = identity + _get_dynamic_directives(is_compressed=True, messages=messages) + _detect_environment_compressed()
        exp_token_limit = 2000
        is_first = False

    mcp_prompt = ""
    try:
        from utim_cli.config import config as _cfg
        _all_disabled = _cfg.get("disabled_tools") or []
        if not isinstance(_all_disabled, list):
            _all_disabled = []
        from utim_cli.tools import get_tools as _get_tools
        _all_tool_names = [t["function"]["name"] for t in _get_tools()[0]]
        _tools_all_off = bool(_all_tool_names) and all(t in _all_disabled for t in _all_tool_names)
        if not _tools_all_off:
            from utim_cli.mcp_client import mcp_manager
            mcp_context = mcp_manager.get_notification_context()
            if mcp_context:
                mcp_prompt += f"\n\n### MCP SERVERS AND TOOLS NOTIFICATION ###\n{mcp_context}\n"
    except Exception:
        pass

    exp_prompt = ""
    try:
        import os
        cache_path = ".utim_tmp/summarized_experiences_cache.txt"
        cached_summary = ""
        if os.path.exists(cache_path):
            with open(cache_path, "r", encoding="utf-8") as f:
                cached_summary = f.read().strip()
                
        # Synchronously generate if cache is missing
        if not cached_summary and user_prompt:
            cached_summary = update_experience_summary_cache(user_prompt)
            
        if cached_summary:
            # 1. Feature 2: Adaptive Token Budgeting
            active_task = _get_active_task(user_prompt) if user_prompt else ""
            from utim_cli.situational_scoring import classify_task_type
            task_type = classify_task_type(active_task)
            
            # Decide budget
            is_simple = task_type in ["general", "search"] or (user_prompt and is_casual_message(user_prompt))
            token_budget = 400 if is_simple else 2000
            char_budget = token_budget * 4
            
            # 2. Feature 3: Dynamic "Just-in-Time" Segment Injection
            active_tags = {"[USER_PREF]", "[GENERAL_RULE]"}
            
            # Let's inspect active/enabled tools
            from utim_cli.config import config as _cfg
            _disabled = _cfg.get("disabled_tools") or []
            if not isinstance(_disabled, list):
                _disabled = []
            has_run_command = "run_command" not in _disabled
            has_plan_project = "plan_project" not in _disabled
            
            if task_type in ["setup", "testing"] or has_run_command:
                active_tags.add("[SHELL_CONVENTION]")
            if task_type in ["file_edit", "refactoring"] or has_plan_project:
                active_tags.add("[CODING_STYLE]")
                active_tags.add("[BUG_FIX]")
                
            # Filter cache by active tags
            lines = cached_summary.splitlines()
            filtered_lines = []
            current_len = 0
            for line in lines:
                has_any_tag = any(t in line for t in ["[SHELL_CONVENTION]", "[CODING_STYLE]", "[BUG_FIX]", "[USER_PREF]", "[GENERAL_RULE]"])
                # If it matches active tags or doesn't have a tag, keep it
                if not has_any_tag or any(tag in line for tag in active_tags):
                    # Check adaptive budget
                    if current_len + len(line) + 1 <= char_budget:
                        filtered_lines.append(line)
                        current_len += len(line) + 1
                    else:
                        break
                        
            cached_summary = "\n".join(filtered_lines).strip()
            if cached_summary:
                exp_prompt = f"\n\n[RELEVANT LESSONS]:\n{cached_summary}\n"
        
        # Query relationship-based Experience Memory using the ExperienceManager
        try:
            from utim_cli.reflection import experience_manager, extract_context_from_interaction
            from utim_cli.state import STATE
            active_task = _get_active_task(user_prompt)
            ctx = extract_context_from_interaction(active_task, "")
            
            # 1. Check for relevant unverified experiences that need confirmation
            unverified_nodes = []
            if ctx.get("objects"):
                for node in experience_manager.experience_nodes.values():
                    if getattr(node, "status", "verified") == "unverified" and getattr(node, "clarifying_question", None):
                        # If the node shares objects/concepts with the current task context
                        if any(obj in ctx["objects"] for obj in node.objects):
                            unverified_nodes.append(node)
                            
            if unverified_nodes:
                # Select only the first one to avoid asking multiple questions at once
                node_to_verify = unverified_nodes[0]
                question = node_to_verify.clarifying_question
                
                # Store the asked question details in STATE so the next user turn evaluates the answer
                STATE["asked_clarifying_question"] = {
                    "pattern_id": node_to_verify.pattern_id,
                    "question": question
                }
                
                question_prompt = (
                    f"\n\n[CONFIRMATION QUESTION REQUIRED]:\n"
                    f"You must ask the user this brief question in your response to verify an assumption: "
                    f"\"{question}\"\n"
                    f"Integrate this question naturally and politely into your reply. Do not mention system rules or prompts.\n"
                )
                exp_prompt = question_prompt + exp_prompt

            # 2. Query standard/verified relationship-based experiences
            if ctx.get("objects"):
                analysis = experience_manager.analyze_pattern(ctx["objects"], ctx.get("relationships", {}))
                # Only show verified experiences or high confidence ones
                if analysis and analysis.get("confidence", 0.0) > 0.4:
                    primary_id = analysis.get("primary_pattern_id")
                    is_verified = True
                    if primary_id and primary_id in experience_manager.experience_nodes:
                        is_verified = getattr(experience_manager.experience_nodes[primary_id], "status", "verified") == "verified"
                        
                    if is_verified:
                        insights = []
                        if analysis.get("interpretation"):
                            insights.append(f"Interpretation: {analysis['interpretation']}")
                        if analysis.get("suggestions"):
                            for s in analysis["suggestions"]:
                                insights.append(f"Suggestion: {s}")
                        if analysis.get("emergent_insights"):
                            for ei in analysis["emergent_insights"]:
                                insights.append(f"Emergent Insight: {ei}")
                        
                        if insights:
                            relationship_prompt = "\n\n[RELATIONSHIP EXPERIENCE INSIGHTS]:\n" + "\n".join(f"- {ins}" for ins in insights) + "\n"
                            exp_prompt = relationship_prompt + exp_prompt
        except Exception:
            pass
    except Exception:
        pass

    # 4. Situational Active Skills Scoring & Injection
    skills_prompt = ""
    try:
        from utim_cli.bootstrap import scan_available_skills
        skills = scan_available_skills()
        if skills:
            active_task = _get_active_task(user_prompt) if user_prompt else ""
            active_task_lower = active_task.lower()
            
            relevant_skills = []
            for skill_name, skill_info in skills.items():
                matched = False
                # Check keywords matching
                if any(kw in active_task_lower for kw in skill_info["keywords"]):
                    matched = True
                if not matched:
                    # Fallback check on name
                    if skill_name.replace("-", " ") in active_task_lower or skill_name in active_task_lower:
                        matched = True
                if matched:
                    relevant_skills.append(skill_name)
                    
            # Filter out already read/seen skills
            unread_skills = []
            for skill in relevant_skills:
                already_read = False
                if messages:
                    for m in messages:
                        # Check assistant's tool call to view_file for this skill
                        if m.get("role") == "assistant" and m.get("tool_calls"):
                            for tc in m.get("tool_calls", []):
                                if tc.get("function", {}).get("name") == "view_file":
                                    args = tc.get("function", {}).get("arguments", "")
                                    if isinstance(args, str):
                                        try:
                                            import json
                                            args_dict = json.loads(args)
                                        except:
                                            args_dict = {}
                                    else:
                                        args_dict = args or {}
                                    path = args_dict.get("AbsolutePath", "")
                                    if skill in path.replace("\\", "/"):
                                        already_read = True
                                        break
                        # Check if message content contains compressed skill header
                        if m.get("role") == "tool" and m.get("name") == "view_file":
                            content = str(m.get("content", ""))
                            if f"RELEVANT CORE SKILL: {skill.upper()}" in content:
                                already_read = True
                                break
                        if already_read:
                            break
                if not already_read:
                    unread_skills.append(skill)
                    
            if unread_skills:
                # Only inject the skill reading directive if read_file is actually available
                try:
                    from utim_cli.config import config as _scfg
                    _sdisabled = _scfg.get("disabled_tools") or []
                    _read_file_disabled = isinstance(_sdisabled, list) and "read_file" in _sdisabled
                except Exception:
                    _read_file_disabled = False
                if not _read_file_disabled:
                    lines = []
                    for name in unread_skills:
                        skill_md_path = skills[name]["path"]
                        skill_md_url = str(skill_md_path.absolute()).replace('\\', '/')
                        lines.append(f"- {skills[name]['name']}: [SKILL.md](file:///{skill_md_url})")
                    skills_prompt = (
                        "\n\n### ACTIVE WORKSPACE SKILLS RECOMMENDED (MUST READ) ###\n"
                        "You are working on a task that relates to the following technical domains. "
                        "You MUST read the corresponding SKILL.md file(s) using the read_file tool before implementing: \n"
                        + "\n".join(lines) + "\n"
                    )
    except Exception:
        pass

    # ── 5. Inject Structured Session Summary Memory ──
    session_summary = ""
    import os
    from utim_cli.config import get_utim_dir
    summary_path = get_utim_dir() / "session_summary.md"
    if os.path.exists(summary_path):
        try:
            with open(summary_path, "r", encoding="utf-8") as sf:
                session_summary = sf.read().strip()
        except Exception:
            pass
            
    if not session_summary and turn_history:
        # Generate summary dynamically on the fly
        summary_lines = ["# UTIM Session Summary", "## Completed Actions"]
        for idx, t in enumerate(turn_history):
            req = t.get("user_msg", "").strip().split("\n")[0][:120]
            summary_lines.append(f"### Step {idx+1}: {req}")
            # Add files modified
            changes = t.get("changes", [])
            if changes:
                summary_lines.append("#### Modified Files:")
                for chg in changes:
                    fp = chg.get("file_path", "") or chg.get("path", "")
                    act = chg.get("type", "") or chg.get("action", "modified")
                    summary_lines.append(f"- `{os.path.basename(fp)}` ({act})")
        session_summary = "\n".join(summary_lines)

    if session_summary:
        session_prompt = f"\n\n### PERSISTENT SESSION MEMORY (PROGRESS AND CHANGE HISTORY) ###\n" \
                         f"The following is a structured log of all accomplishments, user prompts, and file edits " \
                         f"completed in this session. Refer to this to avoid repeating work or asking for things already done:\n" \
                         f"```markdown\n{session_summary}\n```\n"
    # ── 6. Inject Live User Hint Directives (System Prompt Override) ──
    hint_prompt = ""
    try:
        from utim_cli.state import STATE
        pending_hints = []
        if STATE.get("hint"):
            pending_hints.append(STATE.get("hint"))
        if STATE.get("hint_messages") and isinstance(STATE["hint_messages"], list):
            for hm in STATE["hint_messages"]:
                if hm and hm not in pending_hints:
                    pending_hints.append(hm)
                    
        if pending_hints:
            hint_lines = [f"- \"{h.strip()}\"" for h in pending_hints if h and h.strip()]
            if hint_lines:
                hint_prompt = (
                    "\n\n### USER LIVE HINT DIRECTIVE (HIGH-PRIORITY IMMEDIATE OVERRIDE) ###\n"
                    "The user has provided the following live guidance/directive for your execution:\n"
                    + "\n".join(hint_lines) + "\n"
                    "You MUST strictly follow and incorporate these live user hint(s) into your immediate reasoning, tool selection, and output generation for this request.\n"
                )
            # Clear pending hints once consumed into system prompt for the next request
            STATE["hint"] = None
            STATE["hint_messages"] = []
    except Exception:
        pass

    return base_prompt + mcp_prompt + exp_prompt + skills_prompt + hint_prompt

# ── Context management settings ───────────────────────────────────────────────
KEEP_FULL_TURNS = 10      # last N turns (including current) kept with full fidelity
TOKEN_BUDGET    = 90_000  # hard token cap for messages sent to the LLM per call


# Tool display metadata
# Color constants for consolidated 3-color palette
PURPLE = "#cba6f7"
BLUE = "#42bcf5"
YELLOW = "#f9e2af"

# Accent colour per tool (subtle, no bold labels)
TOOL_COLOR: Dict[str, str] = {
    "read_file":             BLUE,
    "write_file":            YELLOW,
    "edit_file":             YELLOW,
    "move_file":             BLUE,
    "delete_file":           PURPLE,
    "run_command":           YELLOW,
    "list_directory":        PURPLE,
    "get_background_output": BLUE,
    "send_background_input": YELLOW,
    "stop_background_process": PURPLE,
    "list_background_processes": BLUE,
    "web_search":            YELLOW,
    "manage_todos":            PURPLE,
    "query_codebase":          YELLOW,
    "generate_image":          YELLOW,
}


class _ServerUnavailableError(RuntimeError):
    """Raised when the UTIM server cannot be reached and no local key is configured.
    Caught in run_task to display a clean user-facing message (no traceback).
    """


class _FatalClientError(RuntimeError):
    """Raised when a non-retryable gating or credit validation error occurs.
    Caught in run_task to immediately abort the turn without retry.
    """


class Orchestrator:
    """Runs the full ReAct agentic loop, proxying LLM calls through the UTIM server."""

    def __init__(self, console: Console):
        self.console = console
        # Start MCP Manager
        try:
            from utim_cli.mcp_client import mcp_manager
            mcp_manager.start()
        except Exception:
            pass
        self.server_url = "https://api.utim.dev"
        self.session_id: Optional[str] = None
        # Primary model — falls back through config.fallback_models on failure
        self.model_id: str = DEFAULT_MODEL
        self._current_line_len = 0
        self.tool_results: List[Dict[str, Any]] = []
        self.turn_step_timings: List[Dict[str, Any]] = []
        self.session_hints: List[str] = []
        
        # Track session start for elapsed time awareness
        self._session_start_time: float = time.time()
        

        
        # Dynamic compression threshold based on model's context window
        self._compression_threshold = self._get_dynamic_threshold()

        # Local conversation history — the single source of truth for this session.
        # Commands like /clear, /resume operate on this list directly.
        self.messages: List[Dict[str, Any]] = [
            {"role": "system", "content": get_system_prompt()}
        ]

        # ── API key / .env loading ────────────────────────────────────────────
        # Priority (highest to lowest):
        #   1. Shell environment variable already set by the user
        #   2. .env file in the CURRENT WORKING DIRECTORY  (folder-local key)
        #   3. .utim/.env  (global fallback written by /auth)
        #
        # IMPORTANT: We load the CWD .env with override=True so that a
        # project-local key always beats any key inherited from a previous
        # utim installation in a different folder (which was the root cause of
        # "Server unavailable" errors when running `utim` from random folders).
        # We also load it by EXPLICIT absolute path — not by letting dotenv
        # walk up the directory tree — so there is no ambiguity about which
        # file wins.
        _cwd_env = os.path.join(os.getcwd(), ".env")
        try:
            from dotenv import load_dotenv as _load_dotenv
            if os.path.isfile(_cwd_env):
                _load_dotenv(_cwd_env, override=True)
            else:
                # No local .env — still call load_dotenv so it picks up any
                # shell-level exports, but do NOT override them.
                _load_dotenv(override=False)
        except Exception:
            pass

        # Load user-saved API key from local .utim/.env (written by the setup wizard / /auth)
        import pathlib
        _user_env = pathlib.Path(".utim").resolve() / ".env"
        if _user_env.exists():
            try:
                from dotenv import load_dotenv as _load_dotenv
                _load_dotenv(_user_env, override=False)  # override=False: env vars win
            except Exception:
                pass

        # Load user-saved API key from global ~/.utim/.env (written by the setup wizard / /auth)
        _global_env = pathlib.Path.home() / ".utim" / ".env"
        if _global_env.exists():
            try:
                from dotenv import load_dotenv as _load_dotenv
                _load_dotenv(_global_env, override=False)  # override=False: env vars win
            except Exception:
                pass

        # User identity from config (can be removed later)
        self.email = config.email or os.getenv("UTIM_EMAIL", "local@utim.dev")
        self.token = config.token

        # Local API key used for OpenRouter.
        # Read AFTER all .env files have been loaded so the correct key wins.
        self._local_api_key: Optional[str] = os.getenv("OPENROUTER_API_KEY")
        if not self._local_api_key:
            self.console.print(
                "\n[bold yellow]Warning: OPENROUTER_API_KEY not found in environment "
                f"or .env file (looked in {_cwd_env!r} then .utim/.env).[/bold yellow]\n"
            )

        self._local_client: bool = bool(self._local_api_key)  

        # OpenRouter base URL (can be overridden per-model for custom providers)
        self._openrouter_base_url = "https://openrouter.ai/api/v1/chat/completions"
        self.model_source: Optional[str] = config.get("main_model_source")

        # Cancellation flag
        self.cancel_event = threading.Event()

        # Lock protecting self.messages from concurrent reads/writes.
        # The background summarisation thread and the main agent loop both
        # access self.messages; without this lock they can race and produce
        # hallucinated summaries or corrupt the message list.
        self._messages_lock = threading.Lock()

        # Manual-mode confirm hook
        self._get_confirm_fn = lambda: None  

        # Turn-level file-change tracking
        self.turn_history: List[Dict[str, Any]] = []
        self.redo_history: List[Dict[str, Any]] = []
        self._turn_changes: List[Dict[str, Any]] = []
        self._current_turn_start: int = 1  

        # Eager session create removed for local mode - sessions are created by _persist_messages


    # LLM calling

    def _persist_messages(self, in_progress_turn: Optional[Dict] = None) -> None:
        """Push the current full message list to the local database in a background thread.
        Silently drops on error — this is best-effort local persistence.
        """
        if not self.session_id:
            # Create a local session if we don't have one
            try:
                from utim_cli.local_db import HistoryManager
                hm = HistoryManager()
                # Use the orchestrator's email (which defaults to local@utim.dev)
                user_email = self.email or os.getenv("UTIM_EMAIL", "local@utim.dev")
                self.session_id = hm.create_session(self.model_id, email=user_email)
            except Exception:
                return
        
        # Find the first user message to use as the conversation title
        first_user = next(
            (m.get("content", "") or "" for m in self.messages if m.get("role") == "user"),
            "",
        )
        if isinstance(first_user, list):
            first_user = " ".join(p.get("text", "") for p in first_user if isinstance(p, dict))

        # Serialise the messages — exclude any private _-prefixed keys we add for tracking
        clean_messages = [
            {k: v for k, v in m.items() if not k.startswith("_")}
            for m in self.messages
        ]

        # Clean turn_history messages
        clean_turn_history = []
        for turn in self.turn_history:
            clean_turn = dict(turn)
            if "messages" in clean_turn:
                clean_turn["messages"] = [
                    {k: v for k, v in m.items() if not k.startswith("_")}
                    for m in clean_turn["messages"]
                ]
            clean_turn_history.append(clean_turn)
            
        # Append in-progress turn if provided
        if in_progress_turn:
            clean_ipt = dict(in_progress_turn)
            if "messages" in clean_ipt:
                clean_ipt["messages"] = [
                    {k: v for k, v in m.items() if not k.startswith("_")}
                    for m in clean_ipt["messages"]
                ]
            clean_turn_history.append(clean_ipt)
            
        clean_redo_history = []
        if hasattr(self, "redo_history"):
            for turn in self.redo_history:
                clean_turn = dict(turn)
                if "messages" in clean_turn:
                    clean_turn["messages"] = [
                        {k: v for k, v in m.items() if not k.startswith("_")}
                        for m in clean_turn["messages"]
                    ]
                clean_redo_history.append(clean_turn)

        # Save to local database and session_state.json
        def _save_local():
            try:
                from utim_cli.local_db import HistoryManager
                hm = HistoryManager()
                hm.add_messages(
                    self.session_id,
                    clean_messages,
                    self.email,
                    first_user,
                    turn_history=clean_turn_history,
                    redo_history=clean_redo_history
                )
                
                # Write current active session state to session_state.json
                state_data = {
                    "session_id": self.session_id,
                    "messages": clean_messages,
                    "turn_history": clean_turn_history,
                    "redo_history": clean_redo_history,
                    "model_id": self.model_id,
                    "model_source": self.model_source,
                }
                from utim_cli.config import get_utim_dir
                utim_dir = get_utim_dir()
                os.makedirs(utim_dir, exist_ok=True)
                with open(utim_dir / "session_state.json", "w", encoding="utf-8") as f:
                    json.dump(state_data, f, ensure_ascii=False, indent=4)

                # Generate a clean, readable session_summary.md
                from datetime import datetime
                summary_lines = [
                    "# UTIM Session Summary",
                    f"**Session ID:** `{self.session_id}`",
                    f"**Model:** `{self.model_id}`",
                    f"**Last Sync:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    "",
                    "## Completed Actions",
                ]
                if not clean_turn_history:
                    summary_lines.append("*No actions completed yet in this session.*")
                else:
                    for idx, t in enumerate(clean_turn_history):
                        req = t.get("user_msg", "").strip()
                        req_short = req.split("\n")[0][:120]
                        if len(req.split("\n")) > 1 or len(req) > 120:
                            req_short += "..."
                        
                        summary_lines.append(f"### Step {idx+1}: {req_short}")
                        
                        # Add files modified
                        changes = t.get("changes", [])
                        if changes:
                            summary_lines.append("#### Modified Files:")
                            for chg in changes:
                                fp = chg.get("file_path", "") or chg.get("path", "")
                                act = chg.get("type", "") or chg.get("action", "modified")
                                summary_lines.append(f"- `{os.path.basename(fp)}` ({act})")
                        summary_lines.append("")
                
                with open(utim_dir / "session_summary.md", "w", encoding="utf-8") as sf:
                    sf.write("\n".join(summary_lines))

                from utim_cli.backup import backup_state
                backup_state()
            except Exception:
                pass  # best-effort — never crash the agent loop

        threading.Thread(target=_save_local, daemon=True).start()

    # Pre-think marker patterns that qwen3.6-plus and similar models emit
    # OUTSIDE their <think> tags — these should be hidden too.
    _PRE_THINK_PATTERNS = re.compile(
        r"^\s*(\*\s*Thinking\.\.\.?|\.\.\.(\s*thinking)?|thinking\.\.\.?)\s*$",
        re.IGNORECASE | re.MULTILINE,
    )

    # ── Custom-provider endpoint resolution ─────────────────────────────────
    def _get_configured_model_source(self, model_id: str, *, is_primary: bool = False) -> Optional[str]:
        """Return the selected source for a model id when the picker recorded one."""
        if is_primary:
            source = getattr(self, "model_source", None) or config.get("main_model_source")
            if source in ("custom", "utim", "openrouter"):
                return source

        for key, value in config._data.items():
            if key.startswith("subagent_model_") and not key.endswith("_source") and value == model_id:
                source = config.get(f"{key}_source")
                if source in ("custom", "utim", "openrouter"):
                    return source
        return None

    def _is_custom_model_selection(self, model_id: str, *, is_primary: bool = False) -> bool:
        source = self._get_configured_model_source(model_id, is_primary=is_primary)
        if source in ("utim", "openrouter"):
            return False
        if source == "custom":
            return bool(config.get_custom_model(model_id))
        return bool(config.get_custom_model(model_id))

    def _resolve_model_endpoint(self, model_id: str, *, is_primary: bool = False) -> tuple:
        """Return (chat_completions_url, api_key) for *model_id*.

        Custom models (added via /model add) carry their own base_url and
        api_key; everything else falls back to OpenRouter.
        """
        custom = config.get_custom_model(model_id) if self._is_custom_model_selection(model_id, is_primary=is_primary) else None
        if custom:
            base = custom.get("base_url", "").rstrip("/")
            # Append /chat/completions if the caller gave us just the base path
            if not base.endswith("/chat/completions"):
                url = base + "/chat/completions"
            else:
                url = base
            key = custom.get("api_key") or self._local_api_key or ""
            return url, key
        # Built-in / OpenRouter model
        return self._openrouter_base_url, self._local_api_key or ""

    def _call_llm(self, messages: List[Dict], override_tools: Optional[List[Dict]] = None, override_model: Optional[str] = None, silent: bool = False) -> Tuple[Dict[str, Any], bool]:
        """POST /chat/completions to OpenRouter (or a custom provider) with real-time streaming."""
        if self.cancel_event.is_set():
            return {
                "role": "assistant",
                "content": "[Aborted by user]",
                "tool_calls": None,
                "was_cut_off": True,
                "aborted": True,
            }, False

        # Pre-flight quota check
        api_key = config.get("api_key")
        if api_key:
            try:
                from utim_cli.auth import SERVER_URL
                resp = requests.get(
                    f"{SERVER_URL}/quota",
                    headers={"X-API-Key": api_key},
                    timeout=5,
                )
                if resp.status_code == 200:
                    quota = resp.json()
                    chosen_model = override_model if override_model else self.model_id
                    is_custom = self._is_custom_model_selection(chosen_model, is_primary=not override_model)

                    # 1. Check if quota is exhausted (only for non-custom models)
                    used = quota.get("credits_used", quota.get("requests_used", 0.0))
                    limit = quota.get("credits_limit", quota.get("requests_limit", 1000))
                    
                    is_exhausted = quota.get("is_exhausted", False)
                    exhaustion_message = quota.get("exhaustion_message", "Credit quota exhausted.")
                    
                    if not is_custom and is_exhausted:
                        reset_time = quota.get("reset_at", "")
                        self.console.print(f"\n[bold red]✗ {exhaustion_message}[/bold red]")
                        if reset_time:
                            self.console.print(f"  Resets at: {reset_time}  •  run [bold]utim upgrade[/bold] to upgrade or visit [bold]utim.dev/pricing[/bold].\n")
                        else:
                            self.console.print(f"  run [bold]utim upgrade[/bold] to upgrade or visit [bold]utim.dev/pricing[/bold].\n")
                        return {
                            "role": "assistant",
                            "content": f"{exhaustion_message} Please upgrade your plan. utim.dev/pricing",
                            "tool_calls": None,
                        }, False
                        
                    # 2. Check if chosen model is allowed — skip entirely for BYOK/custom models
                    #    (custom models use the user's own API key, never UTIM quota)
                    models_allowed = quota["models_allowed"]
                    free_bonus_balance = quota.get("free_bonus_balance", 0.0) or 0.0
                    chosen_model = override_model if override_model else self.model_id
                    is_custom = self._is_custom_model_selection(chosen_model, is_primary=not override_model)

                    # If user has active bonus credits, all models are unlocked — skip gating entirely
                    if not is_custom and free_bonus_balance <= 0.0 and models_allowed != ["all"] and chosen_model not in models_allowed and not chosen_model.endswith(":free"):
                        if quota.get("plan") == "free" or quota.get("display_name") == "Free":
                            self.console.print(f"\n[bold red]✗ Monthly free quota exhausted and no bonus credits remaining.[/bold red]")
                            self.console.print(f"  Model '{chosen_model}' requires bonus credits or an upgraded plan.")
                            self.console.print("  Top up at [bold]utim.dev/pricing[/bold] or run [bold]utim upgrade[/bold].\n")
                            fallback_model = DEFAULT_MODEL
                            self.console.print(f"  Falling back to: [bold]{fallback_model}[/bold]")
                            if override_model:
                                override_model = fallback_model
                            else:
                                self.model_id = fallback_model
                                self.model_source = "utim"
                                config.set("main_model_source", "utim")
                        else:
                            fallback_model = DEFAULT_MODEL  # default free fallback
                            self.console.print(f"\n[bold yellow]⚠ Model '{chosen_model}' is gated under your current '{quota['display_name']}' plan.[/bold yellow]")
                            self.console.print(f"  Downgrading to default allowed model: '{fallback_model}' for this request.")
                            if override_model:
                                override_model = fallback_model
                            else:
                                self.model_id = fallback_model
                                self.model_source = "utim"
                                config.set("main_model_source", "utim")
            except SystemExit:
                raise
            except Exception:
                pass
            
        # Determine models to try for fallback support
        primary_model = override_model if override_model else self.model_id
        
        # Setup fallback for layer 2 (always include fallback models unless override_model is set)
        if not override_model:
            fallback_models = config.fallback_models
            fallback_list = [m for m in fallback_models if m != primary_model]
            models_to_try = [primary_model] + fallback_list
        else:
            models_to_try = [primary_model]

        last_exc = None
        
        for model_idx, current_model in enumerate(models_to_try):
            if self.cancel_event.is_set():
                break
                
            current_is_primary = model_idx == 0
            current_is_custom = self._is_custom_model_selection(current_model, is_primary=current_is_primary and not override_model)
            # Check for API key only if we need it for this built-in/OpenRouter model
            if not current_is_custom and not self._local_api_key and not config.get("api_key"):
                continue

            model_retries = 2
            for attempt in range(model_retries + 1):
                if self.cancel_event.is_set():
                    break
                    
                mcp_tools = []
                try:
                    from utim_cli.mcp_client import mcp_manager
                    mcp_tools = mcp_manager.get_tools()
                except Exception:
                    pass

                from utim_cli.tools import get_tools
                utim_tools, _ = get_tools()
                if override_tools is not None:
                    all_tools = override_tools
                else:
                    all_tools = utim_tools + mcp_tools
                    # Filter disabled tools only for the main agent
                    disabled = config.get("disabled_tools", [])
                    all_tools = [t for t in all_tools if t["function"]["name"] not in disabled]

                from utim_cli.tui.model_dialog import model_supports_reasoning
                
                settings = config.get(f"model_settings_{current_model}") or {}
                
                clean_messages = []
                for msg in messages:
                    msg_copy = dict(msg)
                    if msg_copy.get("role") == "assistant":
                        c_text = (msg_copy.get("content") or "").strip()
                        t_calls = msg_copy.get("tool_calls")
                        if not c_text and not t_calls:
                            msg_copy["content"] = "I'm ready to assist! Could you please clarify or rephrase your request?"
                    clean_messages.append(msg_copy)

                payload = {
                    "model": current_model,
                    "messages": clean_messages,
                    "stream": True,
                    "max_tokens": _get_model_max_output(current_model),
                }
                
                is_reasoning = model_supports_reasoning(current_model)

                # Temperature setting: for reasoning models, omit temperature unless explicitly configured in settings
                if "temperature" in settings:
                    payload["temperature"] = settings["temperature"]
                elif not is_reasoning:
                    payload["temperature"] = 0.3
                    
                # Reasoning setting
                if is_reasoning:
                    reasoning_enabled = settings.get("reasoning_enabled", True)
                    if reasoning_enabled:
                        effort_val = settings.get("reasoning_effort", "medium")
                        payload["reasoning"] = {"effort": effort_val}
                    else:
                        payload.pop("reasoning", None)
                
                # If attempt > 0 (retry after error), strip non-standard params while KEEPING tools intact
                if attempt == 1:
                    payload.pop("reasoning", None)
                    payload.pop("temperature", None)
                elif attempt >= 2:
                    payload.pop("reasoning", None)
                    payload.pop("temperature", None)

                if all_tools:
                    payload["tools"] = all_tools
                printed_header = [False]
                live_printed = [False]
                in_code_block = [False]
                table_buf = []
                in_think = False
                native_reasoning = False
                display_buf = ""
                _think_buf = ""
                _proxy = sys.stdout
                _term_width = self.console.width or 80
                _line_buf = ""
                def stream_markdown_line(part_text):
                    if not part_text.strip():
                        self.console.print()
                        return
                    
                    from rich.markdown import Markdown
                    with self.console.capture() as capture:
                        self.console.print(Markdown(part_text))
                    ansi_text = capture.get().strip("\n")
                    
                    if not ansi_text:
                        self.console.print()
                        return
                    
                    from rich.text import Text
                    text_obj = Text.from_ansi(ansi_text)
                    self.console.print(text_obj)

                def flush_table():
                    if not table_buf:
                        return
                    table_text = "\n".join(table_buf)
                    table_buf.clear()
                    
                    from rich.markdown import Markdown
                    with self.console.capture() as capture:
                        self.console.print(Markdown(table_text))
                    ansi_text = capture.get().strip("\n")
                    
                    if not ansi_text:
                        return
                    
                    from rich.text import Text
                    text_obj = Text.from_ansi(ansi_text)
                    self.console.print(text_obj)

                def process_stream_part(part):
                    if not printed_header[0]:
                        printed_header[0] = True
                        self.console.print()
                    
                    if part.strip().startswith("```"):
                        flush_table()
                        in_code_block[0] = not in_code_block[0]
                        self.console.print(part)
                    elif in_code_block[0] or part.startswith("    ") or part.startswith("\t"):
                        flush_table()
                        self.console.print(part)
                    elif part.strip().startswith("|"):
                        table_buf.append(part)
                    else:
                        flush_table()
                        stream_markdown_line(part)
                    live_printed[0] = True

                # ── Markdown-aware live renderer ──
                # Tokens accumulate into `display_buf`, then a Rich `Live`
                # re-renders the *entire* Markdown tree on each chunk.  This
                # is what keeps tables (header | row | separator) coherent —
                # a token-by-token sys.stdout.write would shred them because
                # the separator row arrives many tokens *after* the header.
                try:
                    start_time = time.time()
                    # last_content_time: updated only when real content/tool-call data arrives.
                    # Intentionally NOT reset by keep-alive pings (empty lines) so stall
                    # detection isn't fooled by the server sending blank heartbeats.
                    last_content_time = start_time
                    _api_key = config.get("api_key")
                    _openrouter_key = self._local_api_key
                    _browser_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                    
                    _current_source = self._get_configured_model_source(
                        current_model,
                        is_primary=current_is_primary and not override_model,
                    )
                    use_utim_server = False
                    if _current_source == "utim":
                        use_utim_server = True
                    elif _current_source == "openrouter":
                        use_utim_server = False
                    elif _current_source == "custom" or current_is_custom:
                        use_utim_server = False
                    else:
                        use_utim_server = bool(_api_key)

                    if use_utim_server and not _api_key:
                        use_utim_server = False

                    if not use_utim_server:
                        _endpoint_url, _endpoint_key = self._resolve_model_endpoint(
                            current_model,
                            is_primary=current_is_primary and not override_model,
                        )
                        _headers = {
                            "Authorization": f"Bearer {_endpoint_key}",
                            "Content-Type": "application/json",
                            "User-Agent": _browser_ua,
                        }
                        request_payload = payload
                    else:
                        from utim_cli.auth import SERVER_URL
                        _endpoint_url = f"{SERVER_URL}/completions"
                        _headers = {
                            "X-API-Key": _api_key,
                            "Content-Type": "application/json",
                            "User-Agent": _browser_ua,
                        }
                        request_payload = {
                            "messages": messages,
                            "model_id": current_model,
                            "tools": all_tools or None,
                            "session_id": self.session_id,
                            "temperature": payload.get("temperature"),
                            "max_tokens": payload.get("max_tokens"),
                            "reasoning": payload.get("reasoning"),
                        }

                    # Check for cancel before we even open the socket
                    if self.cancel_event.is_set():
                        return {
                            "role": "assistant",
                            "content": "[Aborted by user]",
                            "tool_calls": None,
                            "was_cut_off": True,
                            "aborted": True,
                        }, False

                    with requests.post(
                        _endpoint_url,
                        json=request_payload,
                        headers=_headers,
                        stream=True,
                        timeout=(10, 90),  # 10s connect, 90s read — resp.close() handles abort mid-stream
                    ) as resp:
                        resp.raise_for_status()
                        resp.encoding = "utf-8"
                        self.active_response = resp
                    
                        final_content = ""
                        final_tool_calls = []
                        was_cut_off = False

                        try:
                            # Dynamic thinking phases — cycle through contextual messages
                            # during the TTFT wait so the spinner feels alive, not stuck.
                            _THINKING_PHASES = [
                                "Analyzing context...",
                                "Reasoning through approach...",
                                "Evaluating options...",
                                "Structuring response...",
                                "Processing deeply...",
                                "Connecting patterns...",
                                "Formulating plan...",
                                "Almost there...",
                            ]
                            _phase_idx = 0
                            _last_phase_time = start_time

                            # ── Interruptible stream reader ─────────────────────────────
                            # resp.iter_lines() blocks on the socket and can't be woken by
                            # cancel_event alone.  Push lines into a queue from a daemon
                            # thread; the main loop drains it with a short timeout so
                            # cancel_event is checked every 50 ms.  Calling resp.close()
                            # from the main thread kills the socket and unblocks the reader.
                            import queue as _queue_mod
                            _line_queue: _queue_mod.Queue = _queue_mod.Queue()
                            _STREAM_SENTINEL = object()   # signals reader thread finished

                            def _reader_thread(response, q):
                                try:
                                    for _ln in response.iter_lines(decode_unicode=True):
                                        q.put(_ln)
                                except Exception:
                                    pass
                                finally:
                                    q.put(_STREAM_SENTINEL)

                            _rt = threading.Thread(
                                target=_reader_thread,
                                args=(resp, _line_queue),
                                daemon=True,
                                name="utim-stream-reader",
                            )
                            _rt.start()

                            def _iter_lines_cancelable():
                                """Yield lines from the queue; abort by closing resp when cancel fires."""
                                while True:
                                    if self.cancel_event.is_set():
                                        try:
                                            resp.close()
                                        except Exception:
                                            pass
                                        return
                                    try:
                                        item = _line_queue.get(timeout=0.05)
                                    except _queue_mod.Empty:
                                        continue
                                    if item is _STREAM_SENTINEL:
                                        return
                                    yield item

                            for raw_line in _iter_lines_cancelable():
                                if self.cancel_event.is_set():
                                    try:
                                        resp.close()
                                    except Exception:
                                        pass
                                    return {
                                        "role": "assistant",
                                        "content": "[Aborted by user]",
                                        "tool_calls": None,
                                        "was_cut_off": True,
                                        "aborted": True,
                                    }, False

                                
                                now = time.time()

                                # Cycle thinking topic every 8s during TTFT wait
                                if not final_content and not final_tool_calls:
                                    if now - _last_phase_time > 8:
                                        try:
                                            from utim_cli.state import STATE
                                            STATE["thinking_topic"] = _THINKING_PHASES[_phase_idx % len(_THINKING_PHASES)]
                                            _phase_idx += 1
                                            _last_phase_time = now
                                        except Exception:
                                            pass

                                # Stall detection runs on EVERY iteration (including empty
                                # keep-alive lines) so a true stream stall is always caught.
                                if not final_content and not final_tool_calls:
                                    # Hard 180-second timeout for Time-To-First-Token
                                    # Models often need 60-120s to process large tool outputs before streaming
                                    if now - start_time > 180:
                                        raise requests.exceptions.Timeout("Hard TTFT timeout exceeded 180s")
                                else:
                                    # Inter-content stall detection: abort if no real content
                                    # has arrived for 120 seconds, even during keep-alive pings.
                                    if now - last_content_time > 120:
                                        raise requests.exceptions.Timeout("Inter-token stall timeout exceeded 120s")
                                        
                                if not raw_line:
                                    continue
                                
                                # NOTE: last_content_time is updated further below, only when
                                # actual content or tool-call data is parsed from the chunk.
                                    
                                # Clean and normalize the raw line
                                line_str = raw_line.strip()
                                if not line_str:
                                    continue

                                # Strip "data: " prefix if present (SSE stream prefix)
                                if line_str.startswith("data: "):
                                    line_str = line_str[6:].strip()

                                if line_str == "[DONE]":
                                    break

                                # Parse as JSON
                                try:
                                    chunk = json.loads(line_str)
                                except json.JSONDecodeError:
                                    continue

                                # ── 1. UTIM Server response format ─────────────────────────
                                if "type" in chunk:
                                    last_content_time = time.time()
                                    t = chunk["type"]
                                    if t == "content_delta":
                                        text = chunk.get("text", "")
                                        final_content += text
                                        if not silent and text and not self.cancel_event.is_set():
                                            display_buf += text
                                            _line_buf += text
                                            if "\n" in _line_buf:
                                                parts = _line_buf.split("\n")
                                                for part in parts[:-1]:
                                                    process_stream_part(part)
                                                _line_buf = parts[-1]
                                    elif t == "done":
                                        if "error" in chunk and chunk["error"]:
                                            raise RuntimeError(f"Server completion error: {chunk['error']}")
                                        final_content = chunk.get("content") or final_content
                                        final_tool_calls = chunk.get("tool_calls") or final_tool_calls
                                        usage = chunk.get("usage")
                                        if usage:
                                            in_t = usage.get("input_tokens", 0)
                                            out_t = usage.get("output_tokens", 0)
                                            from utim_cli.server.models import estimate_cost
                                            cost = estimate_cost(current_model, in_t, out_t)
                                            from utim_cli.client_utils import update_session_usage
                                            update_session_usage("main_agent", in_t, out_t, cost)
                                        break
                                    continue

                                # ── 2. OpenAI / OpenRouter response format ─────────────────
                                if "usage" in chunk and chunk["usage"]:
                                    usage = chunk["usage"]
                                    in_t = usage.get("prompt_tokens", 0)
                                    out_t = usage.get("completion_tokens", 0)
                                    from utim_cli.server.models import estimate_cost
                                    cost = estimate_cost(current_model, in_t, out_t)
                                    from utim_cli.client_utils import update_session_usage
                                    update_session_usage("main_agent", in_t, out_t, cost)

                                # Check for API errors returned mid-stream
                                if "error" in chunk:
                                    raise RuntimeError(f"OpenRouter error: {chunk['error'].get('message', str(chunk['error']))}")

                                if "choices" in chunk and len(chunk["choices"]) > 0:
                                    choice = chunk["choices"][0]
                                    if choice.get("finish_reason") == "length":
                                        was_cut_off = True
                                    
                                    delta = choice.get("delta", {})
                                    if delta:
                                        # Handle tool calls accumulation
                                        if "tool_calls" in delta:
                                            last_content_time = time.time()  # real data arrived
                                            for tc in delta["tool_calls"]:
                                                idx = tc.get("index", 0)
                                                while len(final_tool_calls) <= idx:
                                                    final_tool_calls.append({"id": "", "type": "function", "function": {"name": "", "arguments": ""}})
                                                if tc.get("id"):
                                                    final_tool_calls[idx]["id"] = tc["id"]
                                                if tc.get("function"):
                                                    f = tc["function"]
                                                    if "name" in f:
                                                        final_tool_calls[idx]["function"]["name"] += f["name"]
                                                    if "arguments" in f:
                                                        final_tool_calls[idx]["function"]["arguments"] += f["arguments"]
                                        
                                        # Handle content streaming
                                        chunk_text = delta.get("content")
                                        reasoning_text = delta.get("reasoning")
                                        
                                        if reasoning_text:
                                            last_content_time = time.time()  # real data arrived
                                            if not in_think:
                                                in_think = True
                                                native_reasoning = True
                                                final_content += "<think>\n"
                                            final_content += reasoning_text
                                            _think_buf += reasoning_text
                                            try:
                                                from utim_cli.state import STATE
                                                lines = [l.strip() for l in _think_buf.split('\n') if l.strip()]
                                                if lines:
                                                    topic = lines[-1]
                                                    if len(topic) > 60:
                                                        topic = topic[:57] + "..."
                                                    STATE["thinking_topic"] = topic
                                            except Exception:
                                                pass
                                            continue
                                            
                                        if chunk_text is not None and chunk_text != "":
                                            last_content_time = time.time()  # real data arrived
                                            if native_reasoning:
                                                native_reasoning = False
                                                in_think = False
                                                final_content += "\n</think>\n"
                                                
                                            final_content += chunk_text
                                            
                                            display = ""
                                            remaining = chunk_text
                                            while remaining:
                                                if in_think:
                                                    for closing in ("</think>", "</thinking>", "[/THINKING]"):
                                                        end_idx = remaining.find(closing)
                                                        if end_idx >= 0:
                                                            _think_buf += remaining[:end_idx]
                                                            remaining = remaining[end_idx + len(closing):]
                                                            in_think = False
                                                            break
                                                    else:
                                                        _think_buf += remaining
                                                        remaining = ""
                                                        
                                                    try:
                                                        from utim_cli.state import STATE
                                                        lines = [l.strip() for l in _think_buf.split('\n') if l.strip()]
                                                        if lines:
                                                            topic = lines[-1]
                                                            if len(topic) > 60:
                                                                topic = topic[:57] + "..."
                                                            STATE["thinking_topic"] = topic
                                                    except Exception:
                                                        pass
                                                else:
                                                    open_found = False
                                                    for opening in ("<think>", "<thinking>", "[THINKING]"):
                                                        start_idx = remaining.find(opening)
                                                        if start_idx >= 0:
                                                            display += remaining[:start_idx]
                                                            remaining = remaining[start_idx + len(opening):]
                                                            in_think = True
                                                            open_found = True
                                                            break
                                                    if not open_found:
                                                        display += remaining
                                                        remaining = ""

                                            if display and not silent and not self.cancel_event.is_set():
                                                cleaned = self._PRE_THINK_PATTERNS.sub("", display)
                                                if cleaned:
                                                    display_buf += cleaned
                                                    _line_buf += cleaned
                                                    if "\n" in _line_buf:
                                                        parts = _line_buf.split("\n")
                                                        for part in parts[:-1]:
                                                            process_stream_part(part)
                                                        _line_buf = parts[-1]
                                    
                                    elif "message" in choice:
                                        # Catch non-streaming choices message (e.g. choice fallback)
                                        msg = choice.get("message", {})
                                        if "content" in msg and msg["content"]:
                                            last_content_time = time.time()
                                            final_content += msg["content"]
                                            if not silent:
                                                display_buf += msg["content"]
                                        if "tool_calls" in msg and msg["tool_calls"]:
                                            last_content_time = time.time()
                                            final_tool_calls = msg["tool_calls"]
                                        break

                        except Exception as stream_exc:
                            # If we have received some content/tool calls, recover gracefully
                            if final_content or final_tool_calls:
                                if not silent:
                                    self.console.print(f"\n[dim yellow]⚠ Stream interrupted: {stream_exc}. Returning partial response.[/dim yellow]\n")
                                was_cut_off = True
                            else:
                                raise stream_exc
                        finally:
                            self.active_response = None

                        if self.cancel_event.is_set():
                            return {
                                "role": "assistant",
                                "content": "[Aborted by user]",
                                "tool_calls": None,
                                "was_cut_off": True,
                                "aborted": True,
                            }, False

                        # Flush any remaining text in _line_buf and table_buf
                        flush_table()
                        if _line_buf and not silent:
                            process_stream_part(_line_buf)
                            _line_buf = ""

                        # ── End of `with resp` streaming block ────────────────────────────
                        # Content was already printed live chunk-by-chunk above if streaming.
                        # Only render as Markdown if somehow nothing was printed live
                        # (e.g. very short response or non-streaming path) — safety fallback.
                        if display_buf and not silent:
                            if not live_printed[0]:
                                # Nothing was printed live: render as Markdown now (short response)
                                self.console.print()
                                self.console.print(Markdown(display_buf))
                                self.console.print()
                            else:
                                # Content was already streamed live — just add trailing newline
                                self.console.print()

                        clean_content = re.sub(
                            r"<think(?:ing)?>.*?</think(?:ing)?>", "", final_content, flags=re.DOTALL
                        ).strip()
                        clean_content = self._PRE_THINK_PATTERNS.sub("", clean_content).strip()

                        # Failsafe: if the model ONLY output reasoning and no actual content,
                        # use the reasoning as the content so the user sees it.
                        if not clean_content and final_content.strip():
                            clean_content = final_content.strip()
                            clean_content = re.sub(r"</?think(?:ing)?>", "", clean_content).strip()

                        clean_content = clean_content if clean_content else None

                        # Parse XML-style tool calls if present in the text content
                        from utim_cli.client_utils import parse_xml_tool_calls
                        parsed_content, parsed_tool_calls = parse_xml_tool_calls(clean_content)
                        if parsed_tool_calls:
                            clean_content = parsed_content
                            if final_tool_calls is None:
                                final_tool_calls = []
                            final_tool_calls.extend(parsed_tool_calls)

                        final_tool_calls = final_tool_calls if final_tool_calls else None

                        # ── Code-block → write_file recovery ─────────────────────────────
                        # If the model output a large code block as plain text instead of
                        # calling write_file/edit_file, synthesize the tool call automatically
                        # so the generated content is not wasted.
                        #
                        # Trigger conditions (ALL must be true):
                        #   • No tool calls were emitted by the model
                        #   • The response contains at least one fenced code block ≥ 40 lines
                        #   • A plausible filename can be inferred from the text
                        if not final_tool_calls and clean_content:
                            try:
                                _recovered_calls = _extract_write_file_calls(clean_content)
                                if _recovered_calls:
                                    final_tool_calls = _recovered_calls
                                    if not silent:
                                        _n = len(_recovered_calls)
                                        _names = ", ".join(
                                            c["function"].get("name", "?") for c in _recovered_calls
                                        )
                                        self.console.print(
                                            f"\n[dim cyan]↩ Auto-recovered {_n} file write(s) from model text output: "
                                            f"{_names}[/dim cyan]\n"
                                        )
                            except Exception:
                                pass

                        if not clean_content and not final_tool_calls:
                            clean_content = "I'm ready to assist! Could you please clarify or rephrase your request?"

                        # Heuristic abrupt-cutoff detector:
                        # Some providers (e.g. OpenRouter) report finish_reason="stop" even
                        # when the response is actually truncated mid-generation.  We catch
                        # two reliable signals of abrupt cutoff:
                        #   1. Unclosed code fence — an odd count of triple-backtick markers
                        #      means the last ```...``` block was never closed.
                        #   2. The response is large (>3 000 chars) and the last non-whitespace
                        #      character is NOT a normal sentence terminator, suggesting the
                        #      model was cut off mid-word or mid-line.
                        if not was_cut_off and clean_content and not final_tool_calls:
                            _backtick_count = clean_content.count("```")
                            _last_char = clean_content.rstrip()[-1] if clean_content.rstrip() else ""
                            _terminal_chars = set(".?!`'\">)]}\\")
                            if _backtick_count % 2 != 0:
                                was_cut_off = True  # unclosed code fence
                            elif len(clean_content) > 3000 and _last_char not in _terminal_chars:
                                was_cut_off = True  # large response ending abruptly

                        final_msg = {
                            "role": "assistant",
                            "content": clean_content,
                            "tool_calls": final_tool_calls,
                            "was_cut_off": was_cut_off,
                        }
                        return final_msg, True

                except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
                    last_exc = exc
                    break  # try next model
                except requests.exceptions.HTTPError as exc:
                    last_exc = exc
                    code = exc.response.status_code if exc.response is not None else "?"
                    if code == 400 and exc.response is not None and attempt == model_retries:
                        try:
                            from rich.markup import escape
                            error_details = exc.response.json()
                            if isinstance(error_details, dict) and "error" in error_details:
                                err_obj = error_details["error"]
                                err_msg = err_obj.get("message", str(err_obj)) if isinstance(err_obj, dict) else str(err_obj)
                            else:
                                err_msg = json.dumps(error_details)
                            self.console.print(f"\n[red]HTTP 400 Error Details from {current_model}: {escape(err_msg)}[/red]")
                        except Exception:
                            from rich.markup import escape
                            self.console.print(f"\n[red]HTTP 400 Error Details from {current_model}: {escape(exc.response.text or 'Bad Request')}[/red]")
                    if code == 403:
                        # Re-check quota live to see if bonus credits are still active
                        _has_bonus = False
                        try:
                            _qr = requests.get(
                                f"{SERVER_URL}/quota",
                                headers={"X-API-Key": config.get("api_key") or ""},
                                timeout=5,
                            )
                            if _qr.status_code == 200:
                                _has_bonus = (_qr.json().get("free_bonus_balance") or 0.0) > 0.0
                        except Exception:
                            pass
                        if _has_bonus:
                            # Bonus credits still active — server may have stale state, skip to next fallback
                            break
                        self.console.print(f"\n[bold red]✗ Model '{current_model}' requires bonus credits or an upgraded plan.[/bold red]")
                        self.console.print("  Top up at [bold]utim.dev/pricing[/bold] or run [bold]utim upgrade[/bold].")
                        self.console.print("  [bold yellow]💡 Tip: Your bonus credits are exhausted. You can still access all free models! [/bold yellow]")
                        self.console.print("  [yellow]   Press Ctrl+M or type /model to switch to a free model, or run 'utim reset'.[/yellow]\n")
                        raise _FatalClientError(f"Model '{current_model}' requires bonus credits or an upgraded plan.")
                    if code == 429:
                        msg_str = ""
                        upgrade_url = ""
                        try:
                            err_data = exc.response.json()
                            if isinstance(err_data, dict):
                                # 1. Check "detail" key
                                detail = err_data.get("detail")
                                if isinstance(detail, dict):
                                    msg_str = detail.get("message", detail.get("error", ""))
                                    upgrade_url = detail.get("upgrade_url", "")
                                elif isinstance(detail, str):
                                    msg_str = detail
                                
                                # 2. Check "error" key (UTIM / OpenRouter format)
                                if not msg_str:
                                    err = err_data.get("error")
                                    if isinstance(err, dict):
                                        msg_str = err.get("message", err.get("detail", ""))
                                    elif isinstance(err, str):
                                        msg_str = err
                                
                                # 3. Check "message" key
                                if not msg_str:
                                    msg_str = err_data.get("message", "")
                        except Exception:
                            pass

                        if not msg_str:
                            msg_str = "Quota exhausted or rate limit exceeded."

                        self.console.print(f"\n[bold red]✗ Quota Exhausted / Limit Reached:[/bold red]")
                        self.console.print(f"  [red]{msg_str}[/red]")
                        if not upgrade_url:
                            upgrade_url = "https://utim.dev/pricing"
                        self.console.print(f"  Please top up credits or upgrade your plan at: [bold]{upgrade_url}[/bold]")
                        self.console.print(f"  You can check your remaining balance by running [bold]/balance[/bold].\n")
                        
                        raise _FatalClientError(f"Quota exhausted: {msg_str}. Please upgrade at {upgrade_url}")
                    if attempt < model_retries:
                        delay = 3 * (attempt + 1)
                        # Interruptible wait — so Ctrl+C can abort immediately
                        deadline = time.time() + delay
                        while time.time() < deadline:
                            if self.cancel_event.is_set():
                                break
                            time.sleep(0.1)
                        if self.cancel_event.is_set():
                            raise _FatalClientError("Cancelled by user")
                        continue
                    break  # try next model
                except RuntimeError as exc:
                    # Mid-stream API errors (e.g. model overloaded) or custom empty response error
                    last_exc = exc
                    break  # try next model
                except Exception as exc:
                    last_exc = exc
                    break  # try next model

        # If we exit the loop, all models failed
        if isinstance(last_exc, requests.exceptions.HTTPError):
            code = last_exc.response.status_code if last_exc.response is not None else "?"
            raise _ServerUnavailableError(f"Model API returned an error after trying all fallbacks (HTTP {code}).") from last_exc
        elif last_exc:
            raise _ServerUnavailableError(f"Cannot reach model API after trying all fallback models. Last error: {last_exc}") from last_exc
        else:
            raise _ServerUnavailableError("OPENROUTER_API_KEY is missing. Please set it in your .env file.")

    # Tool display helpers

    # Icons per tool
    TOOL_ICON: Dict[str, str] = {
        "read_file":              "📄",
        "write_file":             "✏️ ",
        "edit_file":              "🔧",
        "move_file":              "📦",
        "delete_file":            "🗑️ ",
        "run_command":            "⚡",
        "list_directory":         "📁",
        "get_background_output":  "📤",
        "send_background_input": "⌨️ ",
        "stop_background_process":"⏹️ ",
        "list_background_processes": "📋",
        "web_search":             "🔍",
        "plan_project":           "🧠",
        "manage_todos":           "📝",
        "query_codebase":         "🧠",
        "generate_image":         "🎨",
    }

    # User-friendly display names for tools
    TOOL_DISPLAY_NAME: Dict[str, str] = {
        "read_file":              "Reading file",
        "write_file":             "Writing file",
        "edit_file":              "Editing file",
        "move_file":              "Moving file",
        "delete_file":            "Deleting file",
        "run_command":            "Running command",
        "list_directory":         "Listing directory",
        "get_background_output":  "Reading background output",
        "send_background_input":  "Sending background input",
        "web_search":             "Searching web",
        "plan_project":           "Planning project",
        "manage_todos":           "Managing To-Dos",
        "query_codebase":         "Querying Codebase",
        "generate_image":         "Generating image",
    }

    @staticmethod
    def _get_display_arg(func_name: str, arguments: Dict) -> str:
        """Extract the most informative single argument to display inline."""
        if "__" in func_name:
            return ", ".join(f"{k}={v}" for k, v in arguments.items())[:60]
        if func_name in ("read_file", "write_file", "delete_file"):
            path = arguments.get("filepath", arguments.get("path", ""))
            # Append line range for read_file when a range was requested
            if func_name == "read_file":
                s = arguments.get("start_line")
                e = arguments.get("end_line")
                if s or e:
                    path = f"{path}:{s or ''}–{e or ''}"
            return path
        if func_name == "edit_file":
            return arguments.get("filepath", arguments.get("path", ""))
        if func_name == "run_command":
            cmd = arguments.get("command", "")
            if not cmd:
                cmds = arguments.get("commands", [])
                if cmds and isinstance(cmds, list):
                    cmd = "; ".join(cmds)
            display = (cmd or "")[:80] + ("…" if len(cmd or "") > 80 else "")
            dir_p = arguments.get("dir_path", "")
            if dir_p:
                display += f"  [{dir_p}]"
            return display
        if func_name == "list_directory":
            return arguments.get("path", ".")
        if func_name == "move_file":
            src = arguments.get("source", arguments.get("src", ""))
            dst = arguments.get("destination", arguments.get("dst", ""))
            return f"{src} → {dst}"
        if func_name == "web_search":
            return arguments.get("prompt", arguments.get("query", ""))
        if func_name == "generate_image":
            return arguments.get("prompt", "")[:40]
        if func_name == "plan_project":
            return f"{arguments.get('plan_part', 'general')} - {arguments.get('prompt', '')[:30]}"
        if func_name == "query_codebase":
            return arguments.get('query', '')[:40]
        if func_name == "manage_todos":
            ops = arguments.get('operations', [])
            if ops:
                return f"{len(ops)} operations"
            
            action = arguments.get('action', '')
            tid = arguments.get('task_id', '')
            desc = arguments.get('description', '')[:30]
            if action == 'add': return f"Add: {desc}"
            if action in ('mark_done', 'mark_pending', 'delete'): return f"{action}: {tid}"
            return action
        if func_name == "get_background_output":
            return f"process #{arguments.get('process_id', '?')}"
        if func_name == "send_background_input":
            return f"to #{arguments.get('process_id', '?')}: {arguments.get('input_text', '')[:30]}"
        return ""

    def _render_result(self, func_name: str, arguments: Dict, result: str, color: str, user_confirmed: bool = False, expand: bool = False, print_to_console: bool = True) -> str:
        """Render the tool result inside a styled panel appropriate to the tool type."""
        width = min(self.console.width - 2, 120)
        display_name = self.TOOL_DISPLAY_NAME.get(func_name, func_name)

        is_error = result.startswith("Error") or result.startswith("Pre-Commit Validation Failed")
        
        if is_error:
            display_arg = self._get_display_arg(func_name, arguments)
            header = Text()
            header.append(f"✗  ", style="bold red")
            header.append(f"{display_name} Failed", style="bold red")
            if display_arg:
                header.append(f"  {display_arg}", style="white")
                
            with self.console.capture() as capture:
                self.console.print(Panel(
                    Text(result, style="red"),
                    title=header,
                    title_align="left",
                    border_style="red",
                    padding=(0, 1),
                    width=width,
                ))
            rendered_text = capture.get()
            if print_to_console:
                sys.stdout.write(rendered_text)
                sys.stdout.flush()
            return rendered_text

        # ── Header line: icon  ToolName  path/arg ─────────────────────────────
        display_arg = self._get_display_arg(func_name, arguments)
        icon = self.TOOL_ICON.get(func_name, "●")
        header = Text()
        header.append(f"✓  ", style="bold white")
        header.append(f"{display_name}", style=f"bold {color}")
        if display_arg:
            header.append(f"  {display_arg}", style="white")

        # ── Body: tool-specific formatting ─────────────────────────────────────
        if func_name == "edit_file":
            replacements = arguments.get("replacements")
            body = Text()
            if replacements is not None and isinstance(replacements, list):
                removed = 0
                added = 0
                for i, rep in enumerate(replacements):
                    if isinstance(rep, dict):
                        o_str = rep.get("old_str", "") or ""
                        n_str = rep.get("new_str", "") or ""
                        o_lines = o_str.splitlines()
                        n_lines = n_str.splitlines()
                        removed += len(o_lines)
                        added += len(n_lines)
                        
                        if expand or i < 3:
                            if len(replacements) > 1:
                                body.append(f"Replacement #{i+1}:\n", style="bold cyan")
                            
                            o_lines_to_show = o_lines if expand else o_lines[:2]
                            for line in o_lines_to_show:
                                body.append(f"- {line}\n", style="bold red")
                            if not expand and len(o_lines) > 2:
                                body.append(f"  … ({len(o_lines) - 2} more lines)\n", style="dim red")
                                
                            n_lines_to_show = n_lines if expand else n_lines[:2]
                            for line in n_lines_to_show:
                                body.append(f"+ {line}\n", style="bold green")
                            if not expand and len(n_lines) > 2:
                                body.append(f"  … ({len(n_lines) - 2} more lines)\n", style="dim green")
                if not expand and len(replacements) > 3:
                    body.append(f"  … ({len(replacements) - 3} more replacements)\n", style="dim cyan")
            else:
                old_str = arguments.get("old_str", "") or ""
                new_str = arguments.get("new_str", "") or ""
                old_lines = old_str.splitlines()
                new_lines = new_str.splitlines()
                removed = len(old_lines)
                added   = len(new_lines)
                
                old_lines_to_show = old_lines if expand else old_lines[:4]
                for line in old_lines_to_show:
                    body.append(f"- {line}\n", style="bold red")
                if not expand and removed > 4:
                    body.append(f"  … ({removed - 4} more lines)\n", style="dim red")
                    
                new_lines_to_show = new_lines if expand else new_lines[:4]
                for line in new_lines_to_show:
                    body.append(f"+ {line}\n", style="bold green")
                if not expand and added > 4:
                    body.append(f"  … ({added - 4} more lines)\n", style="dim green")
            # Stat footer
            body.append("\n")
            body.append(f" -{removed} lines", style="bold red")
            body.append("   ", style="dim")
            body.append(f"+{added} lines", style="bold green")

            if expand:
                header.append("  (Ctrl+O to collapse)", style="dim italic")
            elif len(replacements or []) > 3 or removed > 4 or added > 4 or any(len((r.get("old_str","") if isinstance(r,dict) else "").splitlines()) > 2 for r in (replacements or [])):
                header.append("  (Ctrl+O to expand)", style="dim italic")

        elif func_name == "write_file":
            old_content = arguments.get("_old_content") or ""
            new_content = arguments.get("content", "")
            old_lines = old_content.splitlines(keepends=True)
            new_lines = new_content.splitlines(keepends=True)
            diff_lines = list(difflib.unified_diff(old_lines, new_lines, lineterm=""))

            body = Text()
            removed_count = 0
            added_count   = 0

            if not diff_lines:
                body.append("  (no changes)", style="dim")
            else:
                shown = 0
                for dl in diff_lines:
                    if dl.startswith("---") or dl.startswith("+++"):
                        continue
                    if not expand and shown >= 30:
                        body.append(f"  … (diff truncated)\n", style="dim")
                        break
                    if dl.startswith("+"):
                        body.append(f"{dl}\n", style="bold green")
                        added_count += 1
                        shown += 1
                    elif dl.startswith("-"):
                        body.append(f"{dl}\n", style="bold red")
                        removed_count += 1
                        shown += 1
                    else:
                        body.append(f"{dl}\n", style="dim white")
                        shown += 1
                # Stat footer
                if removed_count or added_count:
                    body.append("\n")
                    if removed_count:
                        body.append(f" -{removed_count} lines", style="bold red")
                        body.append("   ", style="dim")
                    body.append(f"+{added_count} lines", style="bold green")
                elif not old_content:
                    total = len(new_lines)
                    body.append(f"\n +{total} lines (new file)", style="bold green")

            if expand:
                header.append("  (Ctrl+O to collapse)", style="dim italic")
            elif not expand and len(diff_lines) > 32:
                header.append("  (Ctrl+O to expand)", style="dim italic")

        elif func_name == "run_command":
            raw_output = result.strip()
            body = Text()

            exit_code_val = None
            stdout_section = ""
            stderr_section = ""
            current_section = None
            stdout_lines = []
            stderr_lines = []

            for line in raw_output.splitlines():
                if line.startswith("[exit_code:"):
                    exit_code_val = line.strip().lstrip("[").rstrip("]").split(":", 1)[1].strip()
                elif line == "[stdout]":
                    current_section = "stdout"
                elif line == "[stderr]":
                    current_section = "stderr"
                else:
                    if current_section == "stdout":
                        stdout_section += line + "\n"
                    elif current_section == "stderr":
                        stderr_section += line + "\n"

            if exit_code_val is not None:
                code_int = int(exit_code_val) if exit_code_val.lstrip("-").isdigit() else None
                code_style = "bold red" if (code_int is not None and code_int != 0) else "bold green"
                body.append(f"exit {exit_code_val}\n", style=code_style)

            def clean_line(l: str) -> str:
                return l.rstrip('\r').split('\r')[-1]

            if stdout_section.strip():
                stdout_lines = [clean_line(l) for l in stdout_section.splitlines()]
                if not expand and len(stdout_lines) > 20:
                    shown_block = "\n".join(stdout_lines[:20])
                    tail = f"\n… ({len(stdout_lines) - 20} more lines)"
                else:
                    shown_block = "\n".join(stdout_lines)
                    tail = ""
                t_out = Text.from_ansi(shown_block)
                t_out.style = "dim white"
                body.append(t_out)
                if tail:
                    body.append(tail, style="dim")
                body.append("\n")

            if stderr_section.strip():
                body.append("\n[stderr]\n", style="bold yellow")
                stderr_lines = [clean_line(l) for l in stderr_section.splitlines()]
                if not expand and len(stderr_lines) > 10:
                    shown_err = "\n".join(stderr_lines[:10])
                    err_tail = f"\n… ({len(stderr_lines) - 10} more lines)"
                else:
                    shown_err = "\n".join(stderr_lines)
                    err_tail = ""
                t_err = Text.from_ansi(shown_err)
                t_err.style = "dim #f9e2af"
                body.append(t_err)
                if err_tail:
                    body.append(err_tail, style="dim")

            if not stdout_section.strip() and not stderr_section.strip():
                body.append("(no output)", style="dim")

            if expand:
                header.append("  (Ctrl+O to collapse)", style="dim italic")
            elif not expand and (len(stdout_lines) > 20 or len(stderr_lines) > 10):
                header.append("  (Ctrl+O to expand)", style="dim italic")

        elif func_name == "list_directory":
            output = result.strip()
            lines = output.splitlines()
            body = Text()
            items = lines[1:] if lines and lines[0].startswith("Contents") else lines
            
            items_to_show = items if expand else items[:30]
            for item in items_to_show:
                body.append(f"  {item}\n", style="dim white")
            if not expand and len(items) > 30:
                body.append(f"  … ({len(items) - 30} more items)", style="dim")
                
            if expand:
                header.append("  (Ctrl+O to collapse)", style="dim italic")
            elif not expand and len(items) > 30:
                header.append("  (Ctrl+O to expand)", style="dim italic")

        elif func_name == "read_file":
            all_lines = result.splitlines()
            meta = all_lines[0] if all_lines and all_lines[0].startswith("[") else ""
            content_lines = all_lines[1:] if meta else all_lines
            
            preview_lines = content_lines if expand else content_lines[:15]
            body = Text()
            if meta:
                body.append(meta + "\n", style="dim #585b70")
            for line in preview_lines:
                body.append(line + "\n", style="dim white")
            if not expand and len(content_lines) > 15:
                body.append(f"… ({len(content_lines) - 15} more lines in this chunk)", style="dim")
                
            if expand:
                header.append("  (Ctrl+O to collapse)", style="dim italic")
            elif not expand and len(content_lines) > 15:
                header.append("  (Ctrl+O to expand)", style="dim italic")

        elif func_name == "manage_todos":
            if expand:
                header.append("  (Ctrl+O to collapse)", style="dim italic")
            else:
                header.append("  (Ctrl+O to expand)", style="dim italic")
            
            with self.console.capture() as capture:
                self.console.print(Panel(
                    Text(result.strip(), style="dim white"),
                    title=header,
                    title_align="left",
                    border_style=color,
                    padding=(0, 1),
                    width=width,
                ))
            rendered_text = capture.get()
            if print_to_console:
                sys.stdout.write(rendered_text)
                sys.stdout.flush()
            return rendered_text

        else:
            summary = result.strip()
            if not expand and len(summary) > 300:
                summary = summary[:300] + "…"
            
            if expand:
                header.append("  (Ctrl+O to collapse)", style="dim italic")
            elif not expand and len(result.strip()) > 300:
                header.append("  (Ctrl+O to expand)", style="dim italic")
            
            with self.console.capture() as capture:
                self.console.print(Panel(
                    Text(summary, style="dim white"),
                    title=header,
                    title_align="left",
                    border_style=color,
                    padding=(0, 1),
                    width=width,
                ))
            rendered_text = capture.get()
            if print_to_console:
                sys.stdout.write(rendered_text)
                sys.stdout.flush()
            return rendered_text

        with self.console.capture() as capture:
            self.console.print(Panel(
                body,
                title=header,
                title_align="left",
                border_style=color,
                padding=(0, 1),
                width=width,
            ))
        rendered_text = capture.get()
        if print_to_console:
            sys.stdout.write(rendered_text)
            sys.stdout.flush()
        return rendered_text

    # Tool execution

    def _execute_tool_timed(self, tool_call: Dict) -> str:
        """Execute a tool call without measuring its duration."""
        return self._execute_tool(tool_call)

    def _execute_tool(self, tool_call: Dict) -> str:
        """Execute a single tool call and render a prominent panel indicator."""
        func_name = tool_call["function"]["name"]
        
        # Clean corrupted func_name (e.g. from buggy OpenRouter proxy XML to tool-call translations)
        # E.g. 'read_file filepath=".utim/UTIM.md" />'
        arguments = {}
        raw_args = tool_call["function"].get("arguments", "{}")
        if raw_args:
            try:
                arguments = json.loads(raw_args)
                if not isinstance(arguments, dict):
                    arguments = {}
            except Exception:
                # Fallback: try to parse as XML-style key="value" attribute string.
                # This handles the case where some LLM providers emit raw attributes
                # instead of a JSON object, e.g.: filepath="src/foo.py" content="..."
                import re as _re
                _attrs = _re.findall(
                    r'(\w+)\s*=\s*(?:"((?:[^"\\]|\\.)*)"|\'((?:[^\'\\]|\\.)*)\'|(\S+))',
                    raw_args,
                )
                for _key, _v1, _v2, _v3 in _attrs:
                    _val = _v1 or _v2 or _v3 or ""
                    # Unescape basic backslash sequences
                    _val = _val.replace('\\"', '"').replace("\\'", "'").replace("\\n", "\n").replace("\\t", "\t")
                    arguments[_key] = _val

        func_name_clean = func_name.strip("<> ")
        if func_name_clean:
            parts = func_name_clean.split(None, 1)
            actual_name = parts[0]
            if len(parts) > 1:
                attr_string = parts[1].rstrip("/> ")
                import re
                attrs = re.findall(r'(\w+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))', attr_string)
                for key, val1, val2, val3 in attrs:
                    val = val1 or val2 or val3 or ""
                    arguments[key] = val
            func_name = actual_name

        # Map common alias tool names to actual UTIM CLI tool names
        _TOOL_NAME_ALIASES = {
            "shell": "run_command",
            "bash": "run_command",
            "cmd": "run_command",
            "execute_command": "run_command",
            "view_file": "read_file",
        }
        if func_name in _TOOL_NAME_ALIASES:
            func_name = _TOOL_NAME_ALIASES[func_name]

        # Update the tool_call dict back with the cleaned values
        tool_call["function"]["name"] = func_name
        tool_call["function"]["arguments"] = json.dumps(arguments)

        color = TOOL_COLOR.get(func_name, "#888888")
        icon  = self.TOOL_ICON.get(func_name, "●")

        # The JSON arguments are now guaranteed to be clean/valid
        arguments = json.loads(tool_call["function"]["arguments"])

        # Expand user home directory paths (~) and redirect legacy relative .utim paths to global ~/.utim
        for k, v in list(arguments.items()):
            if isinstance(v, str):
                k_lower = k.lower()
                if any(p in k_lower for p in ("path", "file", "dir", "folder", "cwd")):
                    v_strip = v.strip()
                    v_norm = v_strip.replace("\\", "/")

                    # 1. First prioritize mapping skills folder to project-local .utim_tmp/skills
                    if "skills" in v_norm and (
                        "/.utim/skills" in v_norm or 
                        v_norm.startswith(".utim/skills") or 
                        v_norm.startswith("~/skills") or 
                        v_norm.startswith("~/.utim/skills")
                    ):
                        from pathlib import Path as _Path
                        suffix = v_norm.split("skills", 1)[1].lstrip("/")
                        arguments[k] = str((_Path(".utim_tmp/skills") / suffix).resolve())
                        continue

                    # 2. Expand general ~
                    if v_strip == "~" or v_strip.startswith("~/") or v_strip.startswith("~\\"):
                        import os as _os
                        arguments[k] = _os.path.expanduser(v_strip)
                    # 3. Redirect other general .utim paths to global ~/.utim
                    elif v_strip == ".utim" or v_strip == "./.utim" or v_strip == ".\\.utim":
                        from utim_cli.config import get_utim_dir
                        arguments[k] = str(get_utim_dir())
                    elif v_strip.startswith(".utim/") or v_strip.startswith(".utim\\"):
                        from utim_cli.config import get_utim_dir
                        arguments[k] = str(get_utim_dir() / v_strip[6:])
                    elif v_strip.startswith("./.utim/") or v_strip.startswith(".\\.utim\\"):
                        from utim_cli.config import get_utim_dir
                        arguments[k] = str(get_utim_dir() / v_strip[8:])
                    elif v_strip.startswith("./.utim\\") or v_strip.startswith(".\\.utim/"):
                        from utim_cli.config import get_utim_dir
                        arguments[k] = str(get_utim_dir() / v_strip[8:])
        tool_call["function"]["arguments"] = json.dumps(arguments)

        # ── Disabled-tools enforcement (applies to ALL tools, including MCP) ───
        # Hard-block execution at this point so the user's disable settings are
        # ALWAYS honoured, regardless of what the LLM tries to call. This runs
        # before the MCP early-return so MCP tools are equally blocked.
        _disabled_now = config.get("disabled_tools") or []
        if not isinstance(_disabled_now, list):
            _disabled_now = []
        if func_name in _disabled_now:
            # Silent block — the user disabled tools intentionally.
            # Don't show any warning to the user; just tell the model quietly.
            return (
                f"Tool '{func_name}' is disabled by the user. "
                "Do NOT retry this tool call. "
                "Simply tell the user their tools are currently disabled and they can enable them via /tools."
            )

        # Check if it's an MCP tool
        if "__" in func_name:
            server_name, actual_tool_name = func_name.split("__", 1)
            try:
                from utim_cli.mcp_client import mcp_manager
                if server_name in mcp_manager.sessions:
                    color = "#cba6f7"  # purple accent for MCP
                    icon = "🔌"
                    display_name = f"{server_name} ➔ {actual_tool_name}"
                    display_arg = self._get_display_arg(func_name, arguments)
                    self.console.print(f"  {icon}  Calling MCP tool {display_name}...", style=f"dim {color}")
                    result = mcp_manager.call_tool(server_name, actual_tool_name, arguments)
                    self.TOOL_DISPLAY_NAME[func_name] = display_name
                    self.TOOL_ICON[func_name] = icon
                    TOOL_COLOR[func_name] = color
                    from utim_cli.state import STATE
                    is_expanded = STATE.get("tools_expanded", False)
                    collapsed = self._render_result(func_name, arguments, result, color, expand=False, print_to_console=not is_expanded)
                    if not result.startswith("Error") and not result.startswith("Pre-Commit Validation Failed"):
                        expanded = self._render_result(func_name, arguments, result, color, expand=True, print_to_console=is_expanded)
                        self.last_tool_collapsed_text = collapsed
                        self.last_tool_expanded_text = expanded
                        self.last_tool_state = "expanded" if is_expanded else "collapsed"
                        self.last_tool_lines = len(expanded.splitlines()) if is_expanded else len(collapsed.splitlines())
                    else:
                        self.last_tool_collapsed_text = ""
                        self.last_tool_expanded_text = ""
                        self.last_tool_state = None
                        self.last_tool_lines = 0
                    return result
            except Exception as e:
                self.console.print(Panel(
                    Text(f"Error executing MCP tool {func_name}: {str(e)}", style="red"),
                    border_style="red", padding=(0, 1),
                ))
                return f"Error executing MCP tool {func_name}: {str(e)}"

        from utim_cli.tools import get_tools
        utim_tools, tool_functions = get_tools()
        if func_name not in tool_functions:
            # Check if it's an MCP tool registered by name only (no __ prefix)
            if func_name in self.mcp_tool_names:
                mcp_args = {k: v for k, v in arguments.items() if not k.startswith("_")}
                return self._execute_mcp_tool(func_name, mcp_args)
            return f"Error: The tool '{func_name}' does not exist or is not available in the current context."

        display_arg = self._get_display_arg(func_name, arguments)

        # ── Capture before-state for /rewind tracking ─────────────────────────
        _rewind_entry: Optional[Dict[str, Any]] = None
        _modifying = ("write_file", "edit_file", "delete_file", "move_file")
        if func_name in _modifying:
            path = arguments.get("filepath", arguments.get("path",
                   arguments.get("dst", arguments.get("destination", ""))))
            if func_name == "write_file":
                _rewind_entry = {"action": func_name, "path": path, "before": None, "after": None}
            elif func_name in ("edit_file", "delete_file"):
                before = ""
                try:
                    with open(path, "r", encoding="utf-8") as _rf:
                        before = _rf.read()
                except Exception:
                    pass
                _rewind_entry = {"action": func_name, "path": path, "before": before, "after": None}
            elif func_name == "move_file":
                src = arguments.get("src", arguments.get("source", ""))
                dst = arguments.get("dst", arguments.get("destination", ""))
                # Capture source content before the move, and note whether src existed
                src_content = None
                src_existed = os.path.exists(src)
                if src_existed:
                    try:
                        with open(src, "r", encoding="utf-8") as _sf:
                            src_content = _sf.read()
                    except Exception:
                        src_existed = False
                _rewind_entry = {
                    "action": "move_file",
                    "path": dst,            # destination path (where file will end up)
                    "before_path": src,     # original source path
                    "before": src_content,  # content of source before move (if existed)
                    "before_existed": src_existed,
                    "after": None,
                }

        # For write_file: read old content before overwriting so we can diff later
        if func_name == "write_file":
            filepath = arguments.get("filepath", arguments.get("path", ""))
            try:
                with open(filepath, "r", encoding="utf-8") as _f:
                    arguments["_old_content"] = _f.read()
            except Exception:
                arguments["_old_content"] = None  # File didn't exist before (will trigger deletion on rewind)
            if _rewind_entry:
                _rewind_entry["before"] = arguments["_old_content"]

        # write_file doesn't accept _old_content — strip private keys before calling
        call_args = {k: v for k, v in arguments.items() if not k.startswith("_")}

        # ── Manual-mode confirmation ──────────────────────────────────────────
        _user_confirmed = False
        _CONFIRM_TOOLS = ("write_file", "edit_file", "delete_file", "move_file", "run_command")
        if func_name in _CONFIRM_TOOLS:
            _confirm_fn = self._get_confirm_fn()
            if _confirm_fn is not None:
                # Build compact diff lines for the dialog preview
                _diff_preview: list = []
                if func_name == "edit_file":
                    repls = arguments.get("replacements")
                    if repls and isinstance(repls, list):
                        for r_idx, r in enumerate(repls[:3]):
                            o_str = r.get("old_str", "") or ""
                            n_str = r.get("new_str", "") or ""
                            _diff_preview.append(f"--- Replacement #{r_idx+1} ---")
                            for _l in o_str.splitlines()[:2]:
                                _diff_preview.append(f"- {_l}")
                            for _l in n_str.splitlines()[:2]:
                                _diff_preview.append(f"+ {_l}")
                        if len(repls) > 3:
                            _diff_preview.append(f"... and {len(repls) - 3} more replacements")
                    else:
                        old_str = arguments.get("old_str", "") or ""
                        new_str = arguments.get("new_str", "") or ""
                        for _l in old_str.splitlines()[:5]:
                            _diff_preview.append(f"- {_l}")
                        for _l in new_str.splitlines()[:5]:
                            _diff_preview.append(f"+ {_l}")
                elif func_name == "write_file":
                    import difflib as _dl
                    old_c = arguments.get("_old_content") or ""
                    new_c = arguments.get("content", "")
                    _diff_preview = [
                        ln for ln in list(_dl.unified_diff(
                            old_c.splitlines(), new_c.splitlines(), lineterm="",
                        ))[:15]
                        if not ln.startswith("---") and not ln.startswith("+++")
                    ]
                _decision = _confirm_fn(func_name, arguments, _diff_preview)
                if _decision == "reject":
                    return f"[User rejected {func_name}. Do NOT retry this action — ask the user what they want instead.]"
                # 'allow' or 'allow_session' → user saw and approved the diff
                _user_confirmed = True
            else:
                # Fallback to standard CLI stdin/stdout prompt if in interactive shell
                import sys
                from rich.prompt import Confirm
                if sys.stdin.isatty():
                    self.console.print(f"\n[bold yellow]⬡ Approval Required for {func_name}:[/bold yellow]")
                    if func_name == "run_command":
                        cmd = arguments.get("command") or arguments.get("commands")
                        self.console.print(f"  Command: [bold white]{cmd}[/bold white]")
                    elif func_name in ("write_file", "edit_file", "delete_file", "move_file"):
                        filepath = arguments.get("filepath") or arguments.get("src") or arguments.get("dst")
                        self.console.print(f"  File Action: [bold white]{func_name} on {filepath}[/bold white]")
                        import difflib as _dl
                        old_c = arguments.get("_old_content") or ""
                        new_c = arguments.get("content", "")
                        if func_name == "edit_file":
                            repls = arguments.get("replacements")
                            if repls and isinstance(repls, list):
                                for r in repls[:2]:
                                    self.console.print(f"    - Replace: [red]{repr(r.get('old_str'))}[/red] with [green]{repr(r.get('new_str'))}[/green]")
                            else:
                                old_c = arguments.get("old_str", "") or ""
                                new_c = arguments.get("new_str", "") or ""
                        if func_name == "write_file" or (func_name == "edit_file" and not arguments.get("replacements")):
                            diff_lines = list(_dl.unified_diff(
                                old_c.splitlines(), new_c.splitlines(), lineterm=""
                            ))[:10]
                            for dl in diff_lines:
                                if dl.startswith("+"):
                                    self.console.print(f"    [green]{dl}[/green]")
                                elif dl.startswith("-"):
                                    self.console.print(f"    [red]{dl}[/red]")
                                else:
                                    self.console.print(f"    {dl}")
                    
                    if not Confirm.ask("Do you want to proceed?"):
                        self.console.print("[bold red]✗ Execution cancelled by user.[/bold red]")
                        return f"[User rejected {func_name}. Do NOT retry this action — ask the user what they want instead.]"

        # ── Silent tools: skip all visual output ─────────────────────────────
        _SILENT_TOOLS = {"manage_memory", "recall_experience", "store_experience"}
        if func_name in _SILENT_TOOLS:
            try:
                utim_tools, tool_functions = get_tools()
                result = tool_functions[func_name](**call_args)
            except Exception as exc:
                result = f"Error executing {func_name}: {exc}"
            self.tool_results.append({
                "func_name": func_name,
                "arguments": arguments,
                "result": str(result),
                "color": color
            })
            return str(result)

        # Print a single static "running" line so the user knows which tool
        # is executing. We intentionally avoid Rich Live/Spinner here because
        # it animates at 12 fps and conflicts with prompt_toolkit's own redraws,
        # causing the double-spinner glitch and constant screen flicker.
        _pre = Text()
        _pre.append(f" {icon} ", style=color)
        _pre.append(func_name, style=f"bold {color}")
        if display_arg:
            _pre.append(f"  {display_arg}", style="dim white")
        _pre.append("  …", style="dim")
        self.console.print(_pre)

        try:
            # Dynamically update the thinking indicator so it shows what tool is running
            original_topic = "Thinking..."
            try:
                from utim_cli.state import STATE
                import os
                original_topic = STATE.get("thinking_topic", "Thinking...")
                
                if func_name == "run_command":
                    cmd = arguments.get("command", display_arg)
                    if len(cmd) > 30: cmd = cmd[:27] + "..."
                    STATE["thinking_topic"] = f"Running: {cmd}"
                elif func_name == "plan_project":
                    STATE["thinking_topic"] = f"Architecting {arguments.get('plan_part', 'project')}..."
                elif func_name == "search_web":
                    q = arguments.get("query", "")
                    if len(q) > 25: q = q[:22] + "..."
                    STATE["thinking_topic"] = f"Searching web for '{q}'..."
                elif func_name == "read_file":
                    STATE["thinking_topic"] = f"Reading {os.path.basename(arguments.get('filepath', 'file'))}..."
                elif func_name == "write_file":
                    STATE["thinking_topic"] = f"Writing to {os.path.basename(arguments.get('filepath', 'file'))}..."
                elif func_name in ("edit_file", "multi_replace_file_content"):
                    STATE["thinking_topic"] = f"Editing {os.path.basename(arguments.get('filepath', 'file'))}..."
                else:
                    STATE["thinking_topic"] = f"Executing {func_name}..."
            except Exception:
                pass

            try:
                import inspect
                utim_tools, tool_functions = get_tools()
                func = tool_functions[func_name]
                sig = inspect.signature(func)

                # ── Argument aliasing: remap common LLM hallucinations ─────────
                # Maps (func_name, wrong_key) → correct_key
                _ARG_ALIASES = {
                    # project_res: model sometimes uses 'query' instead of 'prompt'
                    ("project_res", "query"):       "prompt",
                    ("project_res", "text"):        "prompt",
                    ("project_res", "question"):    "prompt",
                    ("project_res", "search"):      "prompt",
                    # query_codebase: model sometimes uses 'prompt' instead of 'query'
                    ("query_codebase", "prompt"):   "query",
                    ("query_codebase", "text"):     "query",
                    ("query_codebase", "search"):   "query",
                    ("query_codebase", "question"): "query",
                    ("query_codebase", "pattern"):  "query",
                    ("query_codebase", "keyword"):  "query",
                    ("query_codebase", "keywords"): "query",
                    ("query_codebase", "term"):     "query",
                    ("query_codebase", "code"):     "query",
                    ("query_codebase", "find"):     "query",
                    # analyze_image: model sometimes uses 'path' instead of 'image_path'
                    ("analyze_image", "path"):      "image_path",
                    ("analyze_image", "file"):      "image_path",
                    ("analyze_image", "filepath"):  "image_path",
                    ("analyze_image", "question"):  "prompt",
                    ("analyze_image", "query"):     "prompt",
                    # plan_project: model sometimes uses 'query'/'text' instead of 'prompt'
                    ("plan_project", "query"):      "prompt",
                    ("plan_project", "text"):       "prompt",
                    ("plan_project", "type"):       "plan_part",
                    ("plan_project", "domain"):     "plan_part",
                    # read_file: model sometimes uses 'path' or 'file'
                    ("read_file", "path"):          "filepath",
                    ("read_file", "file"):          "filepath",
                    ("read_file", "filename"):      "filepath",
                    ("read_file", "start"):         "start_line",
                    ("read_file", "end"):           "end_line",
                    ("read_file", "from_line"):     "start_line",
                    ("read_file", "to_line"):       "end_line",
                    # write_file / edit_file: model sometimes uses other key names
                    ("write_file", "path"):         "filepath",
                    ("write_file", "file"):         "filepath",
                    ("write_file", "filename"):     "filepath",
                    ("write_file", "dest"):         "filepath",
                    ("write_file", "code"):         "content",
                    ("write_file", "text"):         "content",
                    ("write_file", "body"):         "content",
                    ("write_file", "data"):         "content",
                    ("write_file", "contents"):     "content",
                    ("write_file", "payload"):      "content",
                    ("write_file", "value"):        "content",
                    ("write_file", "src"):          "filepath",
                    ("write_file", "target"):       "filepath",
                    ("edit_file", "path"):          "filepath",
                    ("edit_file", "file"):          "filepath",
                    ("edit_file", "filename"):      "filepath",
                    # run_command: model sometimes uses 'cmd' or 'CommandLine'
                    ("run_command", "cmd"):              "command",
                    ("run_command", "shell"):            "command",
                    ("run_command", "script"):           "command",
                    ("run_command", "CommandLine"):      "command",
                    ("run_command", "commandLine"):      "command",
                    ("run_command", "command_line"):     "command",
                    ("run_command", "cmd_line"):         "command",
                    ("run_command", "cwd"):              "dir_path",
                    ("run_command", "directory"):        "dir_path",
                    ("run_command", "folder"):           "dir_path",
                    ("run_command", "path"):             "dir_path",
                    ("run_command", "background"):       "is_background",
                    ("run_command", "bg"):               "is_background",
                    ("run_command", "run_in_background"):"is_background",
                    # web_search: model sometimes uses 'prompt'
                    ("web_search", "prompt"):       "query",
                    ("web_search", "text"):         "query",
                }
                # Apply aliasing before filtering (don't overwrite existing correct keys)
                remapped = dict(call_args)
                for (fn, wrong_key), correct_key in _ARG_ALIASES.items():
                    if fn == func_name and wrong_key in remapped and correct_key not in remapped:
                        remapped[correct_key] = remapped.pop(wrong_key)

                # Filter out args not in the function signature
                has_var_keyword = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
                if has_var_keyword:
                    filtered_args = dict(remapped)
                else:
                    filtered_args = {k: v for k, v in remapped.items() if k in sig.parameters}

                # Check for missing required positional args — try to fill from leftover values.
                # Order: filepath FIRST (short string, usually looks like a path),
                #        content SECOND (longest string, usually the body).
                missing_required = [
                    name for name, param in sig.parameters.items()
                    if param.default is inspect.Parameter.empty
                    and param.kind not in (inspect.Parameter.VAR_KEYWORD, inspect.Parameter.VAR_POSITIONAL)
                    and name not in filtered_args
                ]
                if missing_required:
                    leftover_values = sorted(
                        [v for k, v in call_args.items()
                         if k not in filtered_args and isinstance(v, str)],
                        key=lambda s: len(s),
                    )
                    # Prefer to fill 'filepath' with the shortest leftover (paths are short)
                    ordered_missing = sorted(
                        missing_required,
                        key=lambda n: (0 if n == "filepath" else 1),
                    )
                    for req_name in ordered_missing:
                        if leftover_values:
                            # For filepath, pop the SHORTEST leftover; for everything else, the LONGEST.
                            if req_name == "filepath":
                                filtered_args[req_name] = leftover_values.pop(0)
                            else:
                                filtered_args[req_name] = leftover_values.pop()

                # Final guard: if anything required is still missing, surface a clean error
                # instead of letting TypeError bubble out of func(**filtered_args).
                still_missing = [
                    name for name, param in sig.parameters.items()
                    if param.default is inspect.Parameter.empty
                    and param.kind not in (inspect.Parameter.VAR_KEYWORD, inspect.Parameter.VAR_POSITIONAL)
                    and name not in filtered_args
                ]
                if still_missing:
                    _raw_preview = (raw_args or "")[:200]
                    result = (
                        f"Error executing tool {func_name}: missing required "
                        f"arg(s) {still_missing}. Got keys={sorted(filtered_args.keys())}, "
                        f"raw call_args keys={sorted(call_args.keys())}. "
                        f"raw_args preview={repr(_raw_preview)}. "
                        f"Check _ARG_ALIASES['{func_name}'] or the tool-call parser."
                    )
                else:
                    result = func(**filtered_args)
            except TypeError as e:
                import traceback
                result = (
                    f"Error executing tool {func_name}: {e}\n"
                    f"Args provided: {sorted(filtered_args.keys())}\n"
                    f"{traceback.format_exc()}"
                )
            except Exception as e:
                import traceback
                result = f"Error executing tool {func_name}: {e}\n{traceback.format_exc()}"

            
            # Restore the indicator to evaluating logic
            try:
                STATE["thinking_topic"] = "Evaluating tool results..."
            except Exception:
                pass
        except Exception as exc:
            self.console.print(Panel(
                Text(str(exc), style="red"),
                title=Text(f"✗  {func_name}", style=f"bold red"),
                title_align="left",
                border_style="red",
                padding=(0, 1),
            ))
            return f"Error executing {func_name}: {exc}"

        # Record after-state for rewind tracking
        if _rewind_entry:
            if func_name == "delete_file":
                _rewind_entry["after"] = None  # file no longer exists
            elif func_name == "move_file":
                # After move: destination exists with content, source is gone
                try:
                    with open(_rewind_entry["path"], "r", encoding="utf-8") as _af:
                        _rewind_entry["after"] = _af.read()
                except Exception:
                    _rewind_entry["after"] = None
                # Note: we don't need to track source's after state because it's gone
            else:
                try:
                    with open(_rewind_entry["path"], "r", encoding="utf-8") as _af:
                        _rewind_entry["after"] = _af.read()
                except Exception:
                    _rewind_entry["after"] = None
            self._turn_changes.append(_rewind_entry)

        # Render the result panel (compact if user already approved via dialog)
        from utim_cli.state import STATE
        is_expanded = STATE.get("tools_expanded", False)
        collapsed = self._render_result(func_name, arguments, str(result), color, user_confirmed=_user_confirmed, expand=False, print_to_console=not is_expanded)
        if not str(result).startswith("Error") and not str(result).startswith("Pre-Commit Validation Failed"):
            expanded = self._render_result(func_name, arguments, str(result), color, user_confirmed=_user_confirmed, expand=True, print_to_console=is_expanded)
            self.last_tool_collapsed_text = collapsed
            self.last_tool_expanded_text = expanded
            self.last_tool_state = "expanded" if is_expanded else "collapsed"
            self.last_tool_lines = len(expanded.splitlines()) if is_expanded else len(collapsed.splitlines())
        else:
            self.last_tool_collapsed_text = ""
            self.last_tool_expanded_text = ""
            self.last_tool_state = None
            self.last_tool_lines = 0

        self.tool_results.append({
            "func_name": func_name,
            "arguments": arguments,
            "result": str(result),
            "color": color
        })

        return str(result)

    def _execute_tools_parallel(self, tool_calls: List[Dict]) -> List[Tuple[Dict, str]]:
        """Execute multiple tool calls in parallel when possible.
        
        Groups tools by dependency type and executes independent tools concurrently.
        Tools that modify files (write_file, edit_file, delete_file) are executed
        sequentially to avoid conflicts.
        
        Returns list of (tool_call, result) tuples in original order.
        """
        # Tools that can be safely executed in parallel (read-only operations)
        PARALLEL_SAFE = {"read_file", "list_directory", "query_codebase", "web_search", 
                         "project_res", "plan_project", "manage_todos", "manage_memory",
                         "analyze_image", "analyze_blast_radius", "generate_image"}
        
        # Tools that must be sequential (modify state)
        SEQUENTIAL = {"write_file", "edit_file", "delete_file", "run_command",
                      "move_file", "compress_context"}
        
        # Build list of (original_index, tool_call, is_parallel) for ordering
        indexed_calls = []
        for i, tc in enumerate(tool_calls):
            func_name = tc.get("function", {}).get("name", "")
            is_parallel = func_name in PARALLEL_SAFE
            indexed_calls.append((i, tc, is_parallel))
        
        parallel_calls = [(i, tc) for i, tc, is_par in indexed_calls if is_par]
        sequential_calls = [(i, tc) for i, tc, is_par in indexed_calls if not is_par]
        
        results = [None] * len(tool_calls)  # Pre-allocate to preserve order
        
        # Execute parallel-safe tools concurrently
        if parallel_calls:
            self.console.print()
            self.console.print(f"[dim cyan]⊘ Executing {len(parallel_calls)} tool(s) in parallel...[/dim cyan]")
            
            with ThreadPoolExecutor(max_workers=min(len(parallel_calls), 8)) as executor:
                # Submit all parallel tasks with their original indices
                future_to_idx = {executor.submit(self._execute_tool_timed, tc): (orig_idx, tc) 
                                for orig_idx, tc in parallel_calls}
                
                # Collect results and place them in correct positions
                for future in as_completed(future_to_idx):
                    orig_idx, tc = future_to_idx[future]
                    try:
                        result = future.result()
                        results[orig_idx] = (tc, result)
                    except Exception as e:
                        func_name = tc.get("function", {}).get("name", "unknown")
                        results[orig_idx] = (tc, f"Error executing {func_name}: {e}")
        
        # Execute sequential tools one by one, placing in correct positions
        for orig_idx, tc in sequential_calls:
            if self.cancel_event.is_set():
                results[orig_idx] = (tc, "[Aborted by user]")
                continue
            _tools_module._cancel_event = self.cancel_event
            result = self._execute_tool_timed(tc)
            self._current_line_len = 0
            results[orig_idx] = (tc, result)
        
        return results

    # ── Rewind support ────────────────────────────────────────────────────────

    @staticmethod
    def _change_stats(changes: List[Dict]) -> str:
        """Return a '+N -M lines' summary for a list of changes."""
        add_total = del_total = 0
        for ch in changes:
            before = ch.get("before") or ""
            after  = ch.get("after")  or ""
            b_lines = before.splitlines()
            a_lines = after.splitlines()
            # Simple heuristic: added = lines only in after, removed = lines only in before
            b_set = set(b_lines); a_set = set(a_lines)
            add_total += len(a_lines) - len([l for l in a_lines if l in b_set])
            del_total += len(b_lines) - len([l for l in b_lines if l in a_set])
        n_files = len({ch["path"] for ch in changes})
        parts = []
        if n_files:
            parts.append(f"{n_files} file{'s' if n_files != 1 else ''} changed")
        if add_total:
            parts.append(f"[bold green]+{add_total}[/bold green]")
        if del_total:
            parts.append(f"[bold red]-{del_total}[/bold red]")
        return "  ".join(parts) if parts else "No files changed"

    def rewind_single_turn(self, turn_idx: int, revert_code: bool = True,
                           revert_msgs: bool = True) -> Dict[str, Any]:
        """Rewind only a single turn (not all subsequent turns)."""
        if turn_idx >= len(self.turn_history):
            return {"reverted": [], "errors": []}
        
        turn = self.turn_history[turn_idx]
        res: Dict[str, Any] = {"reverted": [], "errors": []}

        if revert_code:
            # Revert code changes for this turn only
            for ch in reversed(turn["changes"]):
                path = ch["path"]
                try:
                    if ch["action"] == "move_file":
                        src = ch["before_path"]
                        if os.path.exists(path):
                            os.makedirs(os.path.dirname(os.path.abspath(src)), exist_ok=True)
                            shutil.move(path, src)
                        res["reverted"].append(f"{path} → {src}")
                    elif ch.get("before") is None:
                        # File was created (or didn't exist) — delete it if it exists now
                        if os.path.exists(path):
                            os.remove(path)
                        res["reverted"].append(path)
                    else:
                        os.makedirs(
                            os.path.dirname(os.path.abspath(path)), exist_ok=True
                        )
                        with open(path, "w", encoding="utf-8") as wf:
                            wf.write(ch["before"])
                        res["reverted"].append(path)
                except Exception as e:
                    res["errors"].append(f"{path}: {e}")

        if revert_msgs:
            # Remove messages for this turn only
            msg_start = turn["msg_start"]
            msg_end = turn["msg_end"]
            res["msgs_removed"] = msg_end - msg_start
            
            # Remove the messages for this turn
            self.messages = self.messages[:msg_start] + self.messages[msg_end:]
            
            # Update msg_start and msg_end for all subsequent turns
            msgs_removed = msg_end - msg_start
            for i in range(turn_idx + 1, len(self.turn_history)):
                self.turn_history[i]["msg_start"] -= msgs_removed
                self.turn_history[i]["msg_end"] -= msgs_removed
            
            # Remove this turn from history and add it to redo history
            undone_turn = self.turn_history.pop(turn_idx)
            if not hasattr(self, "redo_history"):
                self.redo_history = []
            self.redo_history.append(undone_turn)

        return res

    def rewind_to_turn(self, turn_idx: int, revert_code: bool = True,
                       revert_msgs: bool = True) -> Dict[str, Any]:
        """Revert everything from turn_idx onward."""
        turns = self.turn_history[turn_idx:]
        res: Dict[str, Any] = {"reverted": [], "errors": []}
        if not turns:
            return res

        if revert_code:
            # We want to restore each file to its state BEFORE the oldest turn in `turns`
            # So we traverse `turns` chronologically (forward). The first change we see for a file
            # represents its state before the reverted range began.
            file_targets = {}
            for turn in turns:
                for ch in turn["changes"]:
                    path = ch["path"]
                    if path not in file_targets:
                        file_targets[path] = ch

            for path, ch in file_targets.items():
                try:
                    if ch["action"] == "move_file":
                        src = ch["before_path"]
                        if os.path.exists(path):
                            os.makedirs(os.path.dirname(os.path.abspath(src)), exist_ok=True)
                            shutil.move(path, src)
                        res["reverted"].append(f"{path} → {src}")
                    elif ch.get("before") is None:
                        # File was created (or didn't exist) — delete it if it exists now
                        if os.path.exists(path):
                            os.remove(path)
                        res["reverted"].append(path)
                    else:
                        os.makedirs(
                            os.path.dirname(os.path.abspath(path)), exist_ok=True
                        )
                        with open(path, "w", encoding="utf-8") as wf:
                            wf.write(ch["before"])
                        res["reverted"].append(path)
                except Exception as e:
                    res["errors"].append(f"{path}: {e}")

        if revert_msgs:
            target = turns[0]["msg_start"]
            res["msgs_removed"] = len(self.messages) - target
            self.messages = self.messages[:target]
            
            # Push all popped turns onto redo_history in reverse order (so popping redos in original forward order!)
            if not hasattr(self, "redo_history"):
                self.redo_history = []
            for t in reversed(turns):
                self.redo_history.append(t)
                
            self.turn_history = self.turn_history[:turn_idx]

        return res

    def undo_last_turn(self) -> Dict[str, Any]:
        """Undo the very last turn (conversation + code changes)."""
        if not self.turn_history:
            return {"reverted": [], "errors": ["No turns to undo."]}
        
        last_idx = len(self.turn_history) - 1
        res = self.rewind_single_turn(last_idx, revert_code=True, revert_msgs=True)
        self._persist_messages()
        return res

    def redo_last_undone_turn(self) -> Dict[str, Any]:
        """Redo the most recently undone turn."""
        if not hasattr(self, "redo_history") or not self.redo_history:
            return {"reverted": [], "errors": ["No undone turns to redo."]}
            
        turn = self.redo_history.pop()
        res: Dict[str, Any] = {"redone_code": [], "errors": []}
        
        # Redo code changes
        for ch in turn.get("changes", []):
            path = ch["path"]
            action = ch["action"]
            try:
                if action == "move_file":
                    src = ch["before_path"]
                    if os.path.exists(src):
                        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
                        shutil.move(src, path)
                    res["redone_code"].append(f"{src} → {path}")
                elif ch.get("after") is None:
                    # File was deleted
                    if os.path.exists(path):
                        os.remove(path)
                    res["redone_code"].append(f"deleted {path}")
                else:
                    # File was written/edited
                    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
                    with open(path, "w", encoding="utf-8") as wf:
                        wf.write(ch["after"])
                    res["redone_code"].append(path)
            except Exception as e:
                res["errors"].append(f"{path}: {e}")
                
        # Redo messages: append them back
        msg_start = len(self.messages)
        messages_to_add = turn.get("messages", [])
        self.messages.extend(messages_to_add)
        msg_end = len(self.messages)
        
        # Reconstruct the turn entry and append back to turn_history
        turn["msg_start"] = msg_start
        turn["msg_end"] = msg_end
        self.turn_history.append(turn)
        
        # Persist messages and redo history to DB
        self._persist_messages()
        return res

    def redo_up_to_turn(self, redo_idx: int) -> Dict[str, Any]:
        """Redo all undone turns from index 0 up to redo_idx (inclusive)."""
        if not hasattr(self, "redo_history") or not self.redo_history or redo_idx >= len(self.redo_history):
            return {"reverted": [], "errors": ["No undone turns to redo."]}
            
        # Get the slice of turns to redo
        turns_to_redo = self.redo_history[:redo_idx + 1]
        # Keep the remaining undone turns
        self.redo_history = self.redo_history[redo_idx + 1:]
        
        res: Dict[str, Any] = {"redone_code": [], "errors": []}
        
        # Redo them in order
        for turn in turns_to_redo:
            # Redo code changes
            for ch in turn.get("changes", []):
                path = ch["path"]
                action = ch["action"]
                try:
                    if action == "move_file":
                        src = ch["before_path"]
                        if os.path.exists(src):
                            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
                            shutil.move(src, path)
                        res["redone_code"].append(f"{src} → {path}")
                    elif ch.get("after") is None:
                        if os.path.exists(path):
                            os.remove(path)
                        res["redone_code"].append(f"deleted {path}")
                    else:
                        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
                        with open(path, "w", encoding="utf-8") as wf:
                            wf.write(ch["after"])
                        res["redone_code"].append(path)
                except Exception as e:
                    res["errors"].append(f"{path}: {e}")
                    
            # Redo messages: append them back
            msg_start = len(self.messages)
            messages_to_add = turn.get("messages", [])
            self.messages.extend(messages_to_add)
            msg_end = len(self.messages)
            
            # Reconstruct the turn entry and append back to turn_history
            turn["msg_start"] = msg_start
            turn["msg_end"] = msg_end
            self.turn_history.append(turn)
            
        self._persist_messages()
        return res

    # ── Context compression ──────────────────────────────────────────────────

    @staticmethod
    def _estimate_tokens(obj) -> int:
        """Rough token count: 1 token ≈ 4 chars of serialised JSON."""
        try:
            return len(json.dumps(obj, ensure_ascii=False)) // 4
        except Exception:
            return len(str(obj)) // 4

    def _get_dynamic_threshold(self) -> int:
        """Get dynamic compression threshold based on current model's context window."""
        try:
            from .server.models import get_model
            model_entry = get_model(self.model_id)
            return _get_compression_threshold(self.model_id, model_entry.context_window)
        except Exception:
            # Fallback to safe default if model registry unavailable
            return 65_000
    
    def _update_model_threshold(self, new_model_id: str) -> None:
        """Update compression threshold when model changes."""
        self.model_id = new_model_id
        self._compression_threshold = self._get_dynamic_threshold()

    def _trigger_bg_summarization(self) -> None:
        """Background thread to compress turns older than KEEP_FULL_TURNS into a rolling LLM summary."""
        if not hasattr(self, "_llm_summary"):
            self._llm_summary = ""
            self._summarized_turns = 0
            self._summarizing = False

        if self._summarizing:
            return

        completed = self.turn_history
        unsummarized = len(completed) - self._summarized_turns

        # Only summarize if there are turns falling OUTSIDE the KEEP_FULL_TURNS window
        if unsummarized > KEEP_FULL_TURNS:
            turns_to_summarize = unsummarized - KEEP_FULL_TURNS
            turns_slice = completed[self._summarized_turns : self._summarized_turns + turns_to_summarize]
            current_summary = self._llm_summary

            self._summarizing = True

            def _summarize_task():
                try:
                    text_parts = []
                    for t in turns_slice:
                        req = t.get("user_msg", "").strip()
                        c_str = self._change_stats(t.get("changes", []))

                        # BUG 6 FIX: Read from the stored per-turn message snapshot
                        # instead of slicing self.messages with potentially stale
                        # absolute indices (which shift whenever _compress_intra_turn
                        # rewrites self.messages).
                        conclusion = ""
                        stored_msgs = t.get("messages", [])
                        if stored_msgs:
                            # Use the snapshot saved at turn-end
                            source_msgs = stored_msgs
                        else:
                            # Fallback: try live slice under lock
                            with self._messages_lock:
                                source_msgs = list(self.messages[t["msg_start"]: t["msg_end"]])
                        for m in source_msgs:
                            if m.get("role") == "assistant" and m.get("content"):
                                conclusion = m["content"].strip()

                        text_parts.append(f"User: {req}\nChanges: {c_str}\nAssistant: {conclusion}\n---")

                    raw_turns = "\n".join(text_parts)

                    sys_prompt = "You are a highly analytical AI core memory compressor. Your job is to compress conversational history into a dense, highly technical narrative paragraph. Retain all factual details, architectural decisions, file paths, and current project state. Do not use conversational filler."
                    
                    if current_summary:
                        user_prompt = f"Existing Memory Summary:\n{current_summary}\n\nNew Interactions to Merge:\n{raw_turns}\n\nUpdate the memory summary to incorporate these new interactions seamlessly. Return ONLY the new summary."
                    else:
                        user_prompt = f"New Interactions:\n{raw_turns}\n\nCreate a dense memory summary of these interactions. Return ONLY the summary."

                    # Use fallback model system from context_pruner
                    from utim_cli.context_pruner import _call_compression_model_with_fallback
                    new_summary = _call_compression_model_with_fallback(
                        messages=[
                            {"role": "system", "content": sys_prompt},
                            {"role": "user", "content": user_prompt}
                        ],
                        llm_key=self._local_api_key,
                        max_tokens=2000,
                        primary_model=self.model_id
                    )
                    
                    if new_summary:
                        self._llm_summary = new_summary
                        self._summarized_turns += len(turns_slice)
                    else:
                        print(f"[WARNING] Context summarization returned None - all fallback models failed", file=sys.stderr)
                except Exception as e:
                    print(f"[ERROR] Context summarization failed: {e}", file=sys.stderr)
                finally:
                    self._summarizing = False

            import threading
            threading.Thread(target=_summarize_task, daemon=True).start()

    def _get_send_messages(self, turn_msg_start: Optional[int] = None) -> List[Dict]:
        """Return the context payload, injecting the rolling LLM summary (passive memory)
        and a dynamic active context checklist.

        Args:
            turn_msg_start: The absolute index in self.messages where the current
                user turn begins.  Passing this explicitly avoids relying on the
                stale self._current_turn_start class attribute, which can point to
                the wrong position after _compress_intra_turn rewrites self.messages.
        """
        # BUG 1 FIX: Prefer the caller-supplied index; fall back to the cached
        # attribute only when called from paths that haven't been updated yet.
        effective_turn_start = turn_msg_start if turn_msg_start is not None else self._current_turn_start

        with self._messages_lock:
            messages_snapshot = list(self.messages)

        system_msg = dict(messages_snapshot[0])

        # Extract current user prompt to perform dynamic keyword-based RAG search
        user_prompt = ""
        if effective_turn_start is not None and effective_turn_start < len(messages_snapshot):
            for m in messages_snapshot[effective_turn_start:]:
                if m.get("role") == "user":
                    user_prompt = m.get("content", "")
                    break

        # Reconstruct system prompt with prompt-relevant experiences
        task_elapsed = int(time.time() - getattr(self, "task_start_time", time.time()))
        task_iter = getattr(self, "current_iteration", 0)
        try:
            system_msg["content"] = get_system_prompt(user_prompt, task_iter, task_elapsed, self.turn_history, self.messages)
        except Exception:
            try:
                system_msg["content"] = get_system_prompt(user_prompt, turn_history=self.turn_history, messages=self.messages)
            except Exception:
                pass
        
        # Inject current timestamp so the model lives in the present
        from datetime import datetime
        current_ts = datetime.now().strftime("%A, %B %d, %Y at %I:%M %p")
        system_msg["content"] = f"Current date/time: {current_ts}\n\n" + system_msg["content"]
        
        # Exclude duration, temporal logs, consciousness state, and milestone reflections from message payload to keep it as a pure coding agent.

        

        # ── 1. ACTIVE CONTEXT CHECKLIST (Checklist-based Focus) ────────────────
        active_context = "\n\n### ACTIVE CONTEXT CHECKLIST:"

        # A. Find active file path dynamically from recent messages
        active_file = ""
        for msg in reversed(messages_snapshot):
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                for tc in msg["tool_calls"]:
                    func = tc.get("function", {})
                    if func.get("name") in ("write_file", "edit_file", "read_file"):
                        try:
                            args = json.loads(func.get("arguments", "{}"))
                            active_file = args.get("filepath", args.get("path", ""))
                            if active_file:
                                break
                        except Exception:
                            pass
                if active_file:
                    break
        if active_file:
            active_context += f"\n- **Current File**: {active_file}"

        # B. Get latest command status from the most recent run_command output
        last_command_output = ""
        for msg in reversed(messages_snapshot):
            if msg.get("role") == "tool" and msg.get("name") == "run_command":
                content = msg.get("content", "")
                lines = [l.strip() for l in content.splitlines() if l.strip()]
                if lines:
                    exit_code_line = next((l for l in lines if "exit_code:" in l), "")
                    err_lines = [l for l in lines if "error" in l.lower() or "failed" in l.lower() or "exception" in l.lower()]
                    last_command_output = f"Command exit: {exit_code_line or 'unknown'}"
                    if err_lines:
                        last_command_output += f" | Errors: {'; '.join(err_lines[:2])}"
                    else:
                        last_command_output += f" | Output: {'; '.join(lines[:2])}"
                    break
        if last_command_output:
            active_context += f"\n- **Latest Command Status**: {last_command_output}"

        # C. Read active todos from todos.json
        active_todo_checklist = ""
        todo_file = ".utim_tmp/todos.json"
        if os.path.exists(todo_file):
            try:
                with open(todo_file, "r", encoding="utf-8") as f:
                    todos = json.load(f)
                if todos and isinstance(todos, dict):
                    active_todo_checklist = "\n### ACTIVE TASK CHECKLIST:\n"
                    for tid, t in todos.items():
                        status_mark = "[x]" if t.get("status") == "done" else "[ ]"
                        active_todo_checklist += f"{status_mark} {t.get('description', '')}\n"
            except Exception:
                pass

        if active_todo_checklist:
            active_context += active_todo_checklist
        else:
            # BUG 7 FIX: Guard against effective_turn_start being out-of-bounds
            # after _compress_intra_turn shortens self.messages.  Without this
            # guard the IndexError is silently swallowed and the model gets no
            # active objective in its system prompt for the rest of the turn.
            if 0 < effective_turn_start < len(messages_snapshot):
                obj = (messages_snapshot[effective_turn_start].get("content") or "")[:200]
                active_context += f"\n- **Active Objective**: {obj}..."

        system_msg["content"] += active_context

        # ── 2. PASSIVE MEMORY SUMMARY (Whole memory rollup) ───────────────────
        if getattr(self, "_llm_summary", ""):
            system_msg["content"] += "\n\n### PASSIVE MEMORY SUMMARY (Older events):\n" + self._llm_summary

        completed = self.turn_history
        n_full = max(0, len(completed) - getattr(self, "_summarized_turns", 0))
        recent = completed[-n_full:] if n_full > 0 else []

        if recent:
            rec_slice = messages_snapshot[recent[0]["msg_start"]: effective_turn_start]
        else:
            rec_slice = messages_snapshot[1: effective_turn_start]

        cur_msgs = messages_snapshot[effective_turn_start:]

        return [system_msg] + rec_slice + cur_msgs

    # Main agentic loop

    def _compress_intra_turn(self, turn_msg_start: int, instruction: str = "") -> None:
        """Stable, synchronous compression of the current turn's tool calls if it gets too long or if requested.
        
        Uses importance-weighted pruning (score >= 0.75 = preserved verbatim) so that
        high-signal context such as file reads and error messages is carried forward
        in full, while low-signal chatter is condensed by a compression model.
        sanitize_message_sequence() is applied on the rebuilt list to keep
        assistant/tool-call pairs structurally intact.
        """
        # Compress any uncompressed skill files in the message history immediately
        for m in self.messages:
            if m.get("role") == "tool" and m.get("name") == "view_file":
                content = m.get("content", "")
                if isinstance(content, str) and "description:" in content and "---" in content[:200]:
                    import re as _re
                    match = _re.search(r"name:\s*([a-zA-Z0-9_-]+)", content)
                    skill_name = match.group(1) if match else "workspace skill"
                    
                    sys_prompt = (
                        "You are a technical context pruner. Compress this SKILL.md guide "
                        "into a dense, extremely compact summary of core design principles, HSL variables, "
                        "architectural rules, and syntax requirements (aim for 200-300 words total). "
                        "Do NOT drop HSL templates, critical rules, or exact variable names. No fluff."
                    )
                    from utim_cli.context_pruner import _call_compression_model_with_fallback
                    compressed = _call_compression_model_with_fallback(
                        messages=[
                            {"role": "system", "content": sys_prompt},
                            {"role": "user", "content": f"Skill Guide:\n{content}"}
                        ],
                        llm_key=self._local_api_key,
                        max_tokens=600,
                        content_hint=content[:500],
                        primary_model=self.model_id
                    )
                    if compressed:
                        m["content"] = f"### RELEVANT CORE SKILL: {skill_name.upper()} (COMPRESSED) ###\n{compressed}"

        current_turn_msgs = self.messages[turn_msg_start:]
        
        # We need at least 5 messages to justify compression
        if len(current_turn_msgs) < 5:
            return
            
        # If no explicit instruction is given, check multiple conditions for proactive compression:
        # 1. Token estimate > dynamic threshold (based on model's context window)
        # 2. Message count > dynamic limit (scaled based on model's context window)
        threshold = getattr(self, "_compression_threshold", 65_000)
        if not instruction:
            est_tokens = self._estimate_tokens(self.messages)
            if est_tokens < threshold:
                return
            
        tail_keep = 8

        # Build a compact state anchor so compression never drops the active objective.
        latest_user = ""
        latest_assistant = ""
        latest_tool_plan = ""
        for m in reversed(current_turn_msgs):
            if not latest_user and m.get("role") == "user":
                latest_user = (m.get("content", "") or "")[:1200]
            if m.get("role") == "assistant":
                if not latest_assistant and (m.get("content", "") or "").strip():
                    latest_assistant = (m.get("content", "") or "")[:1200]
                if not latest_tool_plan and m.get("tool_calls"):
                    tc_names = [tc.get("function", {}).get("name", "") for tc in m.get("tool_calls", [])]
                    latest_tool_plan = ", ".join([n for n in tc_names if n])[:500]
            if latest_user and latest_assistant and latest_tool_plan:
                break

        state_anchor = {
            "role": "user",
            "content": (
                "### SYSTEM NOTE: TASK STATE ANCHOR (MUST PRESERVE)\n"
                f"Current user objective (latest):\n{latest_user or '[not found]'}\n\n"
                f"Most recent assistant intent/progress:\n{latest_assistant or '[not found]'}\n\n"
                f"Most recent pending/attempted tool actions:\n{latest_tool_plan or '[none]'}\n\n"
                "Continue from this exact objective. Do not restart completed steps."
            ),
        }

        # ── Unified importance-weighted compression ──────────────────────────
        # Threshold 0.75: messages scoring at or above are kept verbatim so that
        # file-read payloads, error traces, and key facts survive into context.
        # Everything below goes to the compression model for condensation.
        try:
            from utim_cli.context_pruner import score_message_importance, sanitize_message_sequence

            candidate_msgs = current_turn_msgs[1:-tail_keep]
            scored_msgs = [(score_message_importance(m), m) for m in candidate_msgs]

            # Split into verbatim-keep (high) and compress (low) pools
            preserved_messages = [m for score, m in scored_msgs if score >= 0.75]
            to_summarize      = [m for score, m in scored_msgs if score <  0.75]

            # Cap verbatim-keep to 10 to prevent bloat; extras go to compress pool
            if len(preserved_messages) > 10:
                sorted_by_val = sorted(enumerate(scored_msgs), key=lambda x: (x[1][0], x[0]), reverse=True)
                keep_indices  = {idx for idx, _ in sorted_by_val[:10]}
                new_preserved, extra = [], []
                for idx, (score, m) in enumerate(scored_msgs):
                    (new_preserved if idx in keep_indices else extra).append(m)
                preserved_messages = new_preserved
                to_summarize.extend(extra)

            if to_summarize:
                text_parts = []
                import re as _re
                for m in to_summarize:
                    role = m.get("role", "")
                    if role == "assistant":
                        content = _re.sub(
                            r"<think(?:ing)?>.*?</think(?:ing)?>",
                            "[thought process]",
                            (m.get("content", "") or ""),
                            flags=_re.DOTALL,
                        ).strip()
                        tcs    = m.get("tool_calls", [])
                        tc_str = ", ".join(
                            f"{tc['function']['name']}({tc['function'].get('arguments', '')})"
                            for tc in tcs
                        )
                        if content or tc_str:
                            text_parts.append(f"Action: {content}\nTools Called: {tc_str}")
                    elif role == "tool":
                        name    = m.get("name", "tool")
                        content = m.get("content", "")
                        
                        # FIX #3: Intelligent truncation - preserve critical parts
                        # Detect if content has critical markers that should never be truncated
                        critical_patterns = [
                            r"error", r"exception", r"failed", r"failure",
                            r"traceback", r"undefined", r"not found",
                            r"def \w+", r"class \w+", r"import ",
                            r'"[^"]*":\s*', r"'[^']*':\s*",  # Key-value pairs
                        ]
                        
                        # Check if this is critical content that needs full preservation
                        is_critical = any(re.search(p, content, re.I) for p in critical_patterns)
                        
                        # Higher char limit for critical content, but still respect reasonable bounds
                        if len(content) > 1500:
                            if is_critical:
                                # For critical content, try to find and preserve the key part
                                # Look for error lines, function definitions, etc.
                                lines = content.split('\n')
                                critical_lines = []
                                for line in lines:
                                    if any(re.search(p, line, re.I) for p in critical_patterns):
                                        critical_lines.append(line)
                                
                                if critical_lines:
                                    # Preserve the critical lines plus context
                                    content = (content[:800] + 
                                              "\n... [critical excerpts preserved] ...\n" +
                                              "\n".join(critical_lines[:20]))
                                else:
                                    content = content[:1500] + "... [truncated]"
                            else:
                                content = content[:1200] + "... [truncated]"
                        text_parts.append(f"Result of {name}: {content}")

                if text_parts:
                    if instruction:
                        self.console.print("\n[dim magenta]⊘ Agent requested context compression: condensing intermediate tool logs...[/dim magenta]")
                    else:
                        est_tokens = self._estimate_tokens(self.messages)
                        msg_count  = len(self.messages)
                        triggers   = []
                        if est_tokens >= threshold:
                            triggers.append(f"tokens ~{est_tokens}")
                        if msg_count >= 50:
                            triggers.append(f"msg count {msg_count}")
                        trigger_str = ", ".join(triggers) if triggers else "context"
                        self.console.print(f"\n[dim magenta]⊘ Proactive compression (high {trigger_str}): condensing intermediate tool logs...[/dim magenta]")

                    raw_log = "\n---\n".join(text_parts)

                    sys_prompt = (
                        "You are an internal context stabilizer for an autonomous AI agent.\n"
                        "The agent has been running tool calls in a loop. Summarize intermediate steps "
                        "while preserving strict technical continuity.\n"
                        "Required sections:\n"
                        "1) GOAL\n2) COMPLETED\n3) IN_PROGRESS\n4) BLOCKERS/FAILURES\n5) NEXT_ACTION\n"
                        "CRITICAL: Preserve ALL specific file paths, line numbers, variable names, "
                        "error messages, and facts learned from file reads verbatim. No filler.\n\n"
                        "HALLUCINATION PREVENTION RULES:\n"
                        "- Do NOT add facts not present in the source logs\n"
                        "- Do NOT make up file paths, variable names, or error messages\n"
                        "- Do NOT invent technical details not explicitly stated\n"
                        "- When in doubt, use verbatim quotes from the source\n"
                        "- If you cannot determine a fact, state 'not specified' rather than guessing"
                    )
                    if instruction:
                        sys_prompt += (
                            f"\n\nCRITICAL PRESERVATION RULES FROM THE AGENT:\n{instruction}\n"
                            "You MUST strictly preserve these facts, constraints, and code snippets."
                        )

                    from utim_cli.context_pruner import _call_compression_model_with_fallback
                    # Pass raw_log for deduplication tracking
                    summary = _call_compression_model_with_fallback(
                        messages=[
                            {"role": "system", "content": sys_prompt},
                            {"role": "user",   "content": f"Intermediate Logs to Compress:\n{raw_log}"},
                        ],
                        llm_key=self._local_api_key,
                        max_tokens=1500,
                        content_hint=raw_log[:1000],  # Use first 1000 chars for dedup hash
                        primary_model=self.model_id
                    )

                    if summary:
                        summary_msg = {
                            "role": "user",
                            "content": (
                                "### SYSTEM NOTE: INTERMEDIATE STEPS COMPRESSED\n"
                                "The following earlier steps in this task were compressed to save memory:\n"
                                f"{summary}\n\n"
                                "Continue from IN_PROGRESS/NEXT_ACTION and finish unresolved work."
                            ),
                        }
                        recent_tail = current_turn_msgs[-tail_keep:]

                        # BUG 3 FIX: Use object identity (id()) instead of value
                        # equality (==) for deduplication.  Dict value-equality
                        # was silently dropping preserved_messages entries whose
                        # content happened to match a message in recent_tail
                        # (e.g. repeated read_file of the same file).
                        merged_tail = []
                        seen_ids: set = set()
                        for msg in preserved_messages + recent_tail:
                            if id(msg) not in seen_ids:
                                seen_ids.add(id(msg))
                                merged_tail.append(msg)

                        with self._messages_lock:
                            new_messages = (
                                self.messages[:turn_msg_start]
                                + [current_turn_msgs[0], state_anchor, summary_msg]
                                + merged_tail
                            )
                            self.messages = sanitize_message_sequence(new_messages)
                            # BUG 1 FIX: After rewriting self.messages the
                            # turn_msg_start boundary is still valid (we only
                            # shrank the current-turn slice, not the prefix).
                            # Refresh _current_turn_start so _get_send_messages
                            # slices at the correct position on the next call.
                            self._current_turn_start = turn_msg_start
                        return
                    else:
                        self.console.print(
                            "\n[dim red]⊘ Warning: Context compression failed "
                            "(no response from fallback models). Continuing with full context.[/dim red]"
                        )
            else:
                # Nothing to compress — just sanitize the existing list
                self.messages = sanitize_message_sequence(self.messages)
                return

        except Exception as e:
            self.console.print(
                f"\n[dim red]⊘ Warning: Importance-weighted compression failed ({e}). "
                "Continuing with full context.[/dim red]"
            )


    # ── Cleanup utilities ───────────────────────────────────────────────────

    def _cleanup_tmp_folder(self, keep_current_session: bool = True) -> int:
        """Clean up the .utim_tmp folder to remove files from previous runs.
        
        Args:
            keep_current_session: If True, preserve files from the current session.
        
        Returns:
            Number of files removed.
        """
        import glob
        
        tmp_dir = ".utim_tmp"
        if not os.path.exists(tmp_dir):
            return 0
        
        removed_count = 0
        errors = []
        # Define cleanup rules - files/patterns to remove
        cleanup_patterns = [
            # Research files older than 1 day
            (os.path.join(tmp_dir, "research"), "dir"),
            # Plan files are kept for /rewind functionality
            # But we can clean up very old ones
        ]
        
        # Remove old research directory contents
        research_dir = os.path.join(tmp_dir, "research")
        if os.path.exists(research_dir):
            try:
                # Remove files older than 1 day
                now = time.time()
                for root, dirs, files in os.walk(research_dir):
                    for f in files:
                        fp = os.path.join(root, f)
                        try:
                            if os.path.getmtime(fp) < now - 86400:  # 1 day old
                                os.remove(fp)
                                removed_count += 1
                        except OSError as e:
                            errors.append(str(e))
            except Exception as e:
                errors.append(str(e))
        
        # Clean up old reflection files (keep last 10)
        reflection_file = os.path.join(tmp_dir, "task_reflections.json")
        if os.path.exists(reflection_file):
            try:
                import json
                with open(reflection_file, 'r') as f:
                    reflections = json.load(f)
                if len(reflections) > 50:
                    # Keep only the most recent 50
                    reflections = reflections[-50:]
                    with open(reflection_file, 'w') as f:
                        json.dump(reflections, f)
                    removed_count += len(reflections) - 50
            except Exception:
                pass
        
        return removed_count

    def _detect_and_run_tests(self) -> Optional[str]:
        import subprocess
        import os
        import json

        # 1. Check for Python/pytest
        if os.path.exists("pytest.ini") or os.path.exists("conftest.py") or os.path.isdir("tests"):
            try:
                res = subprocess.run(["pytest"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
                if res.returncode != 0 and res.returncode != 5:
                    return f"pytest failed:\n{res.stdout}\n{res.stderr}"
                return None
            except subprocess.TimeoutExpired:
                return "pytest timed out (took longer than 60 seconds)"
            except Exception:
                pass

        # 2. Check for package.json / npm test
        if os.path.exists("package.json"):
            try:
                with open("package.json", "r", encoding="utf-8") as f:
                    pkg = json.load(f)
                if "scripts" in pkg and "test" in pkg["scripts"]:
                    res = subprocess.run(["npm", "test"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60, shell=True)
                    if res.returncode != 0:
                        return f"npm test failed:\n{res.stdout}\n{res.stderr}"
                    return None
            except subprocess.TimeoutExpired:
                return "npm test timed out"
            except Exception:
                pass

        # 3. Check for tox.ini
        if os.path.exists("tox.ini"):
            try:
                res = subprocess.run(["tox"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90)
                if res.returncode != 0:
                    return f"tox failed:\n{res.stdout}\n{res.stderr}"
                return None
            except Exception:
                pass

        # 4. Check for Cargo.toml
        if os.path.exists("Cargo.toml"):
            try:
                res = subprocess.run(["cargo", "test"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
                if res.returncode != 0:
                    return f"cargo test failed:\n{res.stdout}\n{res.stderr}"
                return None
            except Exception:
                pass

        # 5. Check for go.mod
        if os.path.exists("go.mod"):
            try:
                res = subprocess.run(["go", "test", "./..."], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
                if res.returncode != 0:
                    return f"go test failed:\n{res.stdout}\n{res.stderr}"
                return None
            except Exception:
                pass

        return None



    def run_task(self, user_message: str, max_iterations: int = 35) -> None:
        """Append user_message to history and run the full ReAct loop until the
        model stops issuing tool calls or we hit max_iterations.
        """
        from utim_cli.config import config
        max_iterations = config.get("max_iterations", max_iterations)
        self.turn_step_timings = []
        self._tool_failure_counts = {}


        # Refresh console width at start of task
        try:
            import shutil
            width = shutil.get_terminal_size().columns
            if width > 0:
                self.console.width = width
        except:
            pass

        self.cancel_event.clear()
        self.pre_prompt_text = ""
        try:
            from utim_cli.config import get_utim_dir
            pre_prompt_file = get_utim_dir() / "pre_prompt_thoughts.json"
            if os.path.exists(pre_prompt_file):
                os.remove(pre_prompt_file)
        except Exception:
            pass
        try:
            from utim_cli.state import STATE
            STATE["thinking_topic"] = ""
        except Exception:
            pass

        # Check if we asked a clarifying question in the previous turn
        try:
            from utim_cli.state import STATE
            asked = STATE.pop("asked_clarifying_question", None)
            if asked:
                from utim_cli.reflection import evaluate_clarifying_answer
                threading.Thread(
                    target=evaluate_clarifying_answer,
                    args=(asked["pattern_id"], asked["question"], user_message),
                    daemon=True,
                    name="utim-clarifying-question-evaluator"
                ).start()
        except Exception:
            pass

        turn_msg_start = len(self.messages)  # snapshot before user msg is appended
        self._current_turn_start = turn_msg_start  # used by _get_send_messages()
        self._turn_changes = []
        
        # Analyze previous turn feedback and user sentiment
        prev_assistant_content = ""
        prev_iteration_count = 0
        prev_elapsed_time = 0
        if self.turn_history:
            prev_turn = self.turn_history[-1]
            prev_iteration_count = prev_turn.get("iteration_count", 0)
            prev_elapsed_time = prev_turn.get("elapsed_time", 0)

        if self.messages:
            for msg in reversed(self.messages):
                if msg.get("role") == "assistant" and msg.get("content"):
                    prev_assistant_content = msg["content"]
                    break


        try:
            from utim_cli.state import STATE
            hint = STATE.pop("hint", None)
            if hint:
                user_message = f"[Secret Hint Guidance: {hint}]\n{user_message}"
                self.session_hints.append(hint)
        except Exception:
            pass

        self.messages.append({"role": "user", "content": user_message})
        self.redo_history = []  # Clear redo history on new user action
        self._persist_messages(in_progress_turn={
            "user_msg": user_message,
            "msg_start": turn_msg_start,
            "msg_end": len(self.messages),
            "messages": list(self.messages[turn_msg_start:]),
            "changes": [],
        })
        task_start_time = time.time()
        self.task_start_time = task_start_time
        
        # Update the experience summary cache for this task at start
        try:
            update_experience_summary_cache(user_message)
        except Exception:
            pass

        self._test_run_attempts = 0
        final_answer = ""
        _empty_response_streak = 0  # tracks consecutive empty (no content, no tools) responses
        turn_iteration = 0
        for iteration in range(max_iterations):
            self.current_iteration = iteration
            turn_iteration = iteration + 1
            # Check for cancellation before each LLM call
            if self.cancel_event.is_set():
                del self.messages[turn_msg_start + 1:]
                self._persist_messages()
                break

            # ── Resilient LLM call with per-iteration retry ────────────────────
            # We allow up to 3 transient-error retries per iteration before
            # giving up for real.  This prevents a single network blip from
            # silently killing a long-running task.
            _llm_retries = 0
            _llm_max_retries = 3
            msg = None
            while _llm_retries <= _llm_max_retries:
                try:
                    # Make the thinking indicator interactive before TTFT
                    from utim_cli.state import STATE
                    if iteration == 0:
                        if is_casual_message(user_message):
                            STATE["thinking_topic"] = "Formulating greeting..."
                        else:
                            STATE["thinking_topic"] = "Formulating response..."
                        draft_text = getattr(self, "_pre_computation_text", "").strip()
                        actual_text = user_message.strip()
                        
                        def get_similarity(s1, s2):
                            s1_clean = "".join(c for c in s1.lower() if c.isalnum() or c.isspace()).strip()
                            s2_clean = "".join(c for c in s2.lower() if c.isalnum() or c.isspace()).strip()
                            s1_words = s1_clean.split()
                            s2_words = s2_clean.split()
                            if not s1_words or not s2_words:
                                return 0.0
                            w1 = set(s1_words)
                            w2 = set(s2_words)
                            intersection = w1.intersection(w2)
                            union = w1.union(w2)
                            return len(intersection) / len(union)

                        is_match = False
                        match_reason = ""
                        if draft_text:
                            if draft_text == actual_text:
                                is_match = True
                                match_reason = "exact match"
                            elif actual_text.startswith(draft_text) and len(actual_text) - len(draft_text) < 20:
                                is_match = True
                                match_reason = "prefix match"
                            else:
                                similarity = get_similarity(draft_text, actual_text)
                                if similarity >= 0.80:
                                    is_match = True
                                    match_reason = f"fuzzy match ({similarity:.1%} similarity)"

                        if is_match:
                            if (self._pre_computation_thread and 
                                    self._pre_computation_thread.is_alive() and 
                                    not self._pre_computation_done):
                                STATE["thinking_topic"] = "Anticipating response (finishing background reasoning)..."
                                self._pre_computation_thread.join(timeout=30)
                            
                            if self._pre_computation_done and self._pre_computation_result:
                                self.console.print(f"[bold green]⚡ Anticipatory Cache HIT: Reused background reasoning ({match_reason}).[/bold green]")
                                msg = self._pre_computation_result
                                was_streamed = True
                                clean_content = msg.get("content") or ""
                                if clean_content:
                                    self.console.print()
                                    self.console.print(Markdown(clean_content))
                                    self.console.print()
                                self.turn_step_timings.append({
                                    "step": turn_iteration,
                                    "reasoning_time": 0.0,
                                    "tool_time": 0.0,
                                    "tools": []
                                })
                                break
                    else:
                        STATE["thinking_topic"] = "Evaluating tool results & logic..."
                        
                    # BUG 1 FIX: Pass the live turn_msg_start so _get_send_messages
                    # always slices at the correct boundary, even after compression
                    # has rewritten self.messages and potentially shifted indices.
                    send_msgs = self._get_send_messages(turn_msg_start)
                    STATE["thinking_topic"] = "Synthesizing response..."
                    t_llm_start = time.time()
                    msg, was_streamed = self._call_llm(send_msgs)
                    reasoning_duration = time.time() - t_llm_start
                    break  # success
                except _ServerUnavailableError as exc:
                    if self.cancel_event.is_set():
                        del self.messages[turn_msg_start + 1:]
                        self._persist_messages()
                        return
                    if _llm_retries < _llm_max_retries:
                        _llm_retries += 1
                        wait_s = 5 * _llm_retries
                        self.console.print(
                            f"\n[bold yellow]⚠  All models unreachable (attempt {_llm_retries}/{_llm_max_retries}). "
                            f"Retrying in {wait_s}s...[/bold yellow]"
                        )
                        # Interruptible wait — checks cancel_event every 100ms so Ctrl+C stops instantly
                        deadline = time.time() + wait_s
                        while time.time() < deadline:
                            if self.cancel_event.is_set():
                                break
                            time.sleep(0.1)
                        if self.cancel_event.is_set():
                            del self.messages[turn_msg_start + 1:]
                            self._persist_messages()
                            return
                        continue
                    # All retries exhausted — show error and abort turn
                    self.console.print()
                    self.console.print(Panel(
                        Text.from_markup(
                            f"[bold #FFE066]⚠  UTIM Server Unavailable[/bold #FFE066]\n\n"
                            f"[white]{exc}[/white]\n\n"
                            "[dim]All retry attempts failed. The task has been paused.\n"
                            "Type your message again when the connection is restored.[/dim]"
                        ),
                        border_style="#FFE066",
                        padding=(0, 2),
                        expand=False,
                        width=min(70, self.console.width - 4),
                    ))
                    self.console.print()
                    del self.messages[turn_msg_start:]
                    return
                except _FatalClientError as exc:
                    del self.messages[turn_msg_start + 1:]
                    self._persist_messages()
                    return
                except Exception as exc:
                    if self.cancel_event.is_set():
                        del self.messages[turn_msg_start + 1:]
                        self._persist_messages()
                        return
                    if _llm_retries < _llm_max_retries:
                        _llm_retries += 1
                        wait_s = 3 * _llm_retries
                        self.console.print(
                            f"\n[dim yellow]⟳  Transient error on iteration {iteration+1} "
                            f"(attempt {_llm_retries}/{_llm_max_retries}): {exc}. "
                            f"Retrying in {wait_s}s...[/dim yellow]"
                        )
                        # Interruptible wait — checks cancel_event every 100ms so Ctrl+C stops instantly
                        deadline = time.time() + wait_s
                        while time.time() < deadline:
                            if self.cancel_event.is_set():
                                break
                            time.sleep(0.1)
                        if self.cancel_event.is_set():
                            del self.messages[turn_msg_start + 1:]
                            self._persist_messages()
                            return
                        continue
                    # All retries exhausted — log and abort turn cleanly
                    self.console.print(f"\n[bold red]Error (all retries failed):[/bold red] {exc}\n")
                    del self.messages[turn_msg_start + 1:]
                    self._persist_messages()
                    return
            
            if msg is None or msg.get("aborted") or self.cancel_event.is_set():
                if not self.cancel_event.is_set():
                    self.console.print("\n[dim yellow]⊘  Aborted.[/dim yellow]\n")
                del self.messages[turn_msg_start + 1:]
                self._persist_messages()
                return



            content: str = msg.get("content") or ""
            final_answer = content
            tool_calls: List[Dict] = msg.get("tool_calls") or []

            # Print content that wasn't already streamed live
            if not was_streamed and content and content.strip():
                self.console.print()
                self.console.print(Markdown(content))
                self._current_line_len = 0
                if not tool_calls:
                    self.console.print()
            elif was_streamed and content:
                # We finished streaming. The cursor is at some position on the current line.
                # No extra newline here - let the next block handle it
                pass

            # Parse text-based tool calls fallback if native tool calls are empty
            if not tool_calls and content:
                parsed_calls = []
                try:
                    from utim_cli.tools import get_tools
                    _, tool_functions = get_tools()
                    tool_names = set(tool_functions.keys())
                    import json
                    decoder = json.JSONDecoder()
                    pos = 0
                    while pos < len(content):
                        start = content.find('{', pos)
                        if start == -1:
                            break
                        try:
                            obj, end_idx = decoder.raw_decode(content[start:])
                            extracted = []
                            # 1. Standard OpenAI format
                            if "function" in obj and isinstance(obj["function"], dict):
                                func_obj = obj["function"]
                                name = func_obj.get("name")
                                if name in tool_names:
                                    args = func_obj.get("arguments", "{}")
                                    if isinstance(args, dict):
                                        args = json.dumps(args)
                                    extracted = [{
                                        "id": obj.get("id", f"call_parsed_{iteration}"),
                                        "type": "function",
                                        "function": {"name": name, "arguments": args}
                                    }]
                            # 2. Simplified formats
                            if not extracted:
                                name_keys = ["name", "tool", "function", "action", "tool_name"]
                                name = None
                                for k in name_keys:
                                    if k in obj and isinstance(obj[k], str) and obj[k] in tool_names:
                                        name = obj[k]
                                        break
                                if name:
                                    args_obj = {}
                                    args_keys = ["arguments", "args", "parameters", "params"]
                                    for k in args_keys:
                                        if k in obj and isinstance(obj[k], dict):
                                            args_obj = obj[k]
                                            break
                                    else:
                                        args_obj = {k: v for k, v in obj.items() if k not in name_keys}
                                    extracted = [{
                                        "id": f"call_parsed_{iteration}",
                                        "type": "function",
                                        "function": {"name": name, "arguments": json.dumps(args_obj)}
                                    }]
                            if extracted:
                                parsed_calls.extend(extracted)
                            pos = start + end_idx
                        except json.JSONDecodeError:
                            pos = start + 1
                except Exception:
                    pass
                if parsed_calls:
                    tool_calls = parsed_calls
                    self.console.print(f"\n[bold yellow]🔧 Parsed {len(tool_calls)} tool call(s) from assistant text response.[/bold yellow]")

            # If the model response was cut off mid-turn due to length/token limits, nudge it to continue
            if msg.get("was_cut_off"):
                self.console.print("\n[bold yellow]⚠ Response truncated by token limits. Continuing response...[/bold yellow]\n")
                self.messages.append(
                    {
                        "role": "assistant",
                        "content": content or None,
                        "tool_calls": tool_calls if tool_calls else None,
                    }
                )
                self.messages.append(
                    {
                        "role": "user",
                        "content": "You were cut off mid-response (token limit reached). Please continue your response exactly where you left off. Do not repeat yourself; just resume writing from the cutoff point."
                    }
                )
                continue

            # No tool calls → potentially done
            if not tool_calls:
                # Gather recent tool names from this turn to build context-aware nudges
                _recent_tool_names = []
                for _prev_msg in reversed(self.messages[turn_msg_start:]):
                    if _prev_msg.get("role") == "tool":
                        _tname = _prev_msg.get("name", "")
                        if _tname and _tname not in {"recall_experience", "store_experience", "manage_memory"}:
                            _recent_tool_names.append(_tname)
                    elif _prev_msg.get("role") == "user":
                        break  # don't look past the user's message
                _had_tools_this_turn = bool(_recent_tool_names)

                # If the model stopped with empty OR trivially short response after running tools
                _is_empty = not content.strip()
                _is_lazy_transition = False

                is_planning = False

                _lower_content = content.strip().lower() if content else ""

                # ── Case 1: model ran tools then went quiet ────────────────────
                if _had_tools_this_turn and not _is_empty and iteration > 0:
                    if is_planning:
                        _is_lazy_transition = len(_lower_content) < 20
                    else:
                        _ends_with_cliffhanger = (
                            content.strip().endswith(":") or
                            content.strip().endswith("...")
                        )
                        _has_lazy_phrases = any(phrase in _lower_content for phrase in [
                            "i will now", "let's run", "next, i'll", "running the",
                            "i am going to", "i'll now", "let me check", "let me run",
                            "continuing", "my bad", "apologies", "proceeding to",
                            "now i will", "next i will", "moving on to", "let's proceed",
                            "i will execute", "let's execute", "i will use", "executing the",
                        ])
                        _is_lazy_transition = (
                            (len(_lower_content) < 400 and _has_lazy_phrases) or
                            _ends_with_cliffhanger or
                            len(_lower_content) < 50
                        )

                # ── Case 2: model has NOT called any tools yet this turn ───────
                # Catches "I'll now do X:" on the very first step, before any tool was run.
                elif not _had_tools_this_turn and not _is_empty and not is_planning and not tool_calls:
                    _ends_with_cliffhanger = (
                        content.strip().endswith(":") or
                        content.strip().endswith("...")
                    )
                    _has_lazy_phrases = any(phrase in _lower_content for phrase in [
                        "i will now", "let me now", "let's now", "now let me",
                        "let me create", "let me write", "let me implement", "let me add",
                        "i'll now create", "i'll now write", "i'll now implement",
                        "i'll create", "i'll write", "i'll implement", "i'll use",
                        "i'll now use", "now i'll", "next, i'll", "let me use",
                        "i will use", "i will write", "i will create", "i will implement",
                        "now, let me", "to do this, i", "i am going to",
                        "proceeding to", "moving on to",
                    ])
                    # Only nudge if the model is clearly announcing work without doing it.
                    # Don't nudge a genuine conversational reply that just happens to be short.
                    if (_ends_with_cliffhanger and len(_lower_content) < 600) or \
                       (_has_lazy_phrases and len(_lower_content) < 400):
                        _is_lazy_transition = True

                if (_is_empty or _is_lazy_transition) and iteration < max_iterations - 1:
                    _empty_response_streak += 1
                    if _empty_response_streak >= 4:
                        # Model stuck in a loop — give up
                        self.console.print(
                            f"\n[bold yellow]⚠  The model got stuck providing lazy or empty responses ({_empty_response_streak} times). "
                            "It has been paused. Try nudging it manually or switching models.[/bold yellow]\n"
                        )
                        break

                    # To prevent history pollution and break repeating patterns, check if the last
                    # message in history was a previous nudge. If so, remove the previous nudge-and-response pair
                    # so they don't multiply in the LLM's context.
                    if len(self.messages) >= 2:
                        last_user = self.messages[-1]
                        if last_user.get("role") == "user" and any(marker in (last_user.get("content") or "") for marker in [
                            "Stop announcing your intentions",
                            "Stop describing plans",
                            "You described what you were going to do",
                            "You just executed tool(s)",
                            "You stopped without writing anything"
                        ]):
                            self.messages.pop()  # Pop the previous user nudge
                            if self.messages and self.messages[-1].get("role") == "assistant":
                                self.messages.pop()  # Pop the previous lazy assistant response

                    # Build a context-aware continuation nudge
                    if _had_tools_this_turn:
                        tool_list = ", ".join(dict.fromkeys(reversed(_recent_tool_names)))  # dedupe, preserve order
                        nudge = (
                            f"You just executed tool(s) [{tool_list}]. You then wrote a short response without "
                            f"calling any further tools. Stop describing plans or announcing intentions. "
                            f"If the task is incomplete, you MUST output the required JSON tool calls to DO IT. "
                            f"If the task is truly complete, provide a comprehensive final summary."
                        )
                    elif _is_lazy_transition:
                        # First-step lazy: model announced what it would do but didn't call any tools
                        nudge = (
                            "Stop describing plans, listing todos, or announcing your intentions in text. "
                            "You MUST immediately execute the appropriate tool call(s) right now. "
                            "Do NOT write conversational filler, explanations, or 'I will now...' statements. "
                            "Output the tool call JSON directly."
                        )
                    else:
                        nudge = (
                            "You stopped without writing anything or taking action. The user's request was: "
                            f"\"{user_message[:200]}\". Stop describing plans — output the tool call JSON directly."
                        )

                    self.console.print(f"\n[dim yellow]⚠ Model provided lazy response without tools. Auto-nudging (attempt {_empty_response_streak}/3)...[/dim yellow]")
                    self.messages.append({"role": "assistant", "content": content or " "})
                    self.messages.append({"role": "user", "content": nudge})
                    continue
                
                # Got a valid response — reset streak counter
                _empty_response_streak = 0

                # ── Automated Regression Testing Loop ───────────────────────
                import utim_cli.tools as _t
                from utim_cli.config import config
                import os as _os
                if (
                    self._turn_changes 
                    and not _t._DRY_RUN 
                    and (_os.environ.get("UTIM_ENABLE_REGRESSION_TESTS") == "1" or config.get("enable_regression_tests", False))
                    and getattr(self, "_test_run_attempts", 0) < 3
                ):
                    self.console.print("\n[bold yellow]🔍 Running automated regression tests to verify changes...[/bold yellow]")
                    test_error = self._detect_and_run_tests()
                    if test_error:
                        self._test_run_attempts = getattr(self, "_test_run_attempts", 0) + 1
                        self.console.print(f"[bold red]❌ Automated tests failed (Attempt {self._test_run_attempts}/3). Nudging agent to self-heal...[/bold red]")
                        self.messages.append({"role": "assistant", "content": content})
                        self.messages.append({
                            "role": "user",
                            "content": f"Automated regression testing failed after your changes. Please fix the failing test(s) or compilation error(s) shown below:\n\n{test_error}"
                        })
                        continue
                    else:
                        self.console.print("[bold green]✓ All automated tests passed successfully![/bold green]\n")

                self.messages.append({"role": "assistant", "content": content})
                self.turn_step_timings.append({
                    "step": turn_iteration,
                    "reasoning_time": reasoning_duration,
                    "tool_time": 0.0,
                    "tools": []
                })

                break

            # Append assistant message (with tool_calls) to history
            self.messages.append(
                {
                    "role": "assistant",
                    "content": content or None,
                    "tool_calls": tool_calls,
                }
            )
            # Real-time persistence: save the assistant response & tool calls immediately
            self._persist_messages(in_progress_turn={
                "user_msg": user_message,
                "msg_start": turn_msg_start,
                "msg_end": len(self.messages),
                "messages": list(self.messages[turn_msg_start:]),
                "changes": list(self._turn_changes),
            })

            # Execute tools - use parallel execution for better performance
            t_tool_start = time.time()
            compression_instruction = ""
            
            # Extract compression instruction before parallel execution
            for tc in tool_calls:
                func_name = tc.get("function", {}).get("name", "")
                if func_name == "compress_context":
                    try:
                        args = json.loads(tc["function"].get("arguments", "{}"))
                        compression_instruction = args.get("preservation_rules", "Keep critical facts and architecture decisions.")
                    except:
                        pass

            # ── Two-phase execution: Knowledge-first gate ─────────────────
            # When recall_experience is called alongside MUTATING tools
            # (run_command, write_file, edit_file, etc.), the model has already
            # decided on those tool arguments BEFORE seeing the recall results.
            # This creates a race condition where knowledge arrives too late.
            #
            # Fix: execute ONLY recall_experience first, inject its results,
            # DROP the remaining planned calls, and force a re-plan so the
            # model can use the recalled knowledge to make better decisions.
            MUTATING_TOOLS = {"run_command", "write_file", "edit_file", "delete_file", "move_file"}
            KNOWLEDGE_TOOLS = {"recall_experience"}
            
            knowledge_calls = [tc for tc in tool_calls
                               if tc.get("function", {}).get("name", "") in KNOWLEDGE_TOOLS]
            mutating_calls = [tc for tc in tool_calls
                              if tc.get("function", {}).get("name", "") in MUTATING_TOOLS]
            
            if knowledge_calls and mutating_calls:
                # Phase 1: Execute ONLY the knowledge tools (silently)
                
                for ktc in knowledge_calls:
                    result = self._execute_tool_timed(ktc)
                    tc_id = ktc.get("id") or str(ktc.get("index", "0"))
                    func_name = ktc.get("function", {}).get("name", "")
                    self.messages.append({
                        "role": "tool",
                        "tool_call_id": tc_id,
                        "name": func_name,
                        "content": result,
                    })
                
                # Phase 2: Tell the model the remaining calls were NOT executed
                # and ask it to re-plan with the new knowledge
                dropped_names = [tc.get("function", {}).get("name", "?") for tc in mutating_calls]
                non_knowledge_non_mutating = [tc for tc in tool_calls
                                              if tc.get("function", {}).get("name", "") not in KNOWLEDGE_TOOLS
                                              and tc.get("function", {}).get("name", "") not in MUTATING_TOOLS]
                
                # Execute non-mutating, non-knowledge tools normally (they're safe)
                for safe_tc in non_knowledge_non_mutating:
                    result = self._execute_tool_timed(safe_tc)
                    tc_id = safe_tc.get("id") or str(safe_tc.get("index", "0"))
                    func_name = safe_tc.get("function", {}).get("name", "")
                    self.messages.append({
                        "role": "tool",
                        "tool_call_id": tc_id,
                        "name": func_name,
                        "content": result,
                    })
                
                # Insert placeholder results for dropped mutating calls so the API
                # doesn't complain about missing tool_call_id responses
                for mtc in mutating_calls:
                    tc_id = mtc.get("id") or str(mtc.get("index", "0"))
                    func_name = mtc.get("function", {}).get("name", "?")
                    self.messages.append({
                        "role": "tool",
                        "tool_call_id": tc_id,
                        "name": func_name,
                        "content": f"[NOT EXECUTED] This {func_name} call was held back. "
                                   f"Review the recall_experience results above — they may "
                                   f"contain constraints that affect how you should call this tool. "
                                   f"Please re-plan and re-issue the call with any necessary adjustments.",
                    })
                
                # Force the model to re-plan by continuing the loop
                tool_duration = time.time() - t_tool_start
                self.turn_step_timings.append({
                    "step": turn_iteration,
                    "reasoning_time": reasoning_duration,
                    "tool_time": tool_duration,
                    "tools": [tc.get("function", {}).get("name", "") for tc in tool_calls]
                })
                continue

            # Execute tools in parallel when beneficial
            if len(tool_calls) > 1:
                # Use parallel execution for multiple tools
                parallel_results = self._execute_tools_parallel(tool_calls)
                for slot in parallel_results:
                    if self.cancel_event.is_set():
                        break
                    # Guard against None slots (defensive: shouldn't happen but prevents crash)
                    if slot is None:
                        continue
                    tc, result = slot
                    
                    tc_id = tc.get("id") or str(tc.get("index", "0"))
                    func_name = tc.get("function", {}).get("name", "")
                    

                    
                    self.messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc_id,
                            "name": func_name,
                            "content": result,
                        }
                    )
            else:
                # Single tool - execute directly
                for tc in tool_calls:
                    if self.cancel_event.is_set():
                        break
                        
                    func_name = tc.get("function", {}).get("name", "")
                    _tools_module._cancel_event = self.cancel_event
                    result = self._execute_tool_timed(tc)
                    self._current_line_len = 0
                    tc_id = tc.get("id") or str(tc.get("index", "0"))
                    

                        
                    self.messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc_id,
                            "name": func_name,
                            "content": result,
                        }
                    )
                
            # --- Repeated Tool Failure Loop Detection ---
            if not hasattr(self, "_tool_failure_counts"):
                self._tool_failure_counts = {}

            READ_ONLY_TOOLS = {"read_file", "view_file", "grep_search", "list_dir", "read_url_content", "search_web"}

            for tc in tool_calls:
                func_name = tc.get("function", {}).get("name", "")
                args_str = tc.get("function", {}).get("arguments", "{}")
                
                # Retrieve the result we just appended for this tool call ID
                tc_id = tc.get("id") or str(tc.get("index", "0"))
                tool_res = ""
                for msg in reversed(self.messages):
                    if msg.get("role") == "tool" and msg.get("tool_call_id") == tc_id:
                        tool_res = msg.get("content") or ""
                        break
                
                # Check if it failed
                is_fail = False
                if isinstance(tool_res, str) and tool_res.strip():
                    tool_res_strip = tool_res.strip()
                    res_prefix = tool_res_strip[:100].lower()

                    if func_name in READ_ONLY_TOOLS:
                        # For read-only tools, only explicit error prefixes count as failures.
                        # Reading source code that contains words like "error" or "failed" is NOT a failure.
                        if (tool_res_strip.startswith("Error:") or 
                            tool_res_strip.startswith("[!] Error") or 
                            tool_res_strip.startswith("FileNotFoundError") or 
                            tool_res_strip.startswith("PermissionError") or 
                            tool_res_strip.startswith("NoSuchFileError") or
                            res_prefix.startswith("invalid path")):
                            is_fail = True
                    else:
                        # For commands/writes, check explicit error markers in prefix or exit code
                        if (tool_res_strip.startswith("[!] Error") or 
                            tool_res_strip.startswith("Error:") or 
                            "exit code" in res_prefix or 
                            "syntaxerror" in res_prefix or
                            "pre-commit validation failed" in res_prefix or
                            "command failed" in res_prefix):
                            is_fail = True
                
                fingerprint = (func_name, args_str)
                if is_fail:
                    count = self._tool_failure_counts.get(fingerprint, 0) + 1
                    self._tool_failure_counts[fingerprint] = count
                    
                    if count >= 3:
                        # Reset count after issuing nudge so it doesn't repeatedly spam on subsequent steps
                        self._tool_failure_counts[fingerprint] = 0
                        warning_text = (
                            f"⚠️ [SYSTEM CRITICAL NOTICE] You have attempted to execute the tool `{func_name}` "
                            f"with arguments `{args_str}` 3 times in a row, and it continues to fail with the error:\n"
                            f"{tool_res}\n\n"
                            f"Your current approach is stuck in a loop. You MUST change your parameters, check the syntax, "
                            f"or try a different tool/command. Do NOT repeat this exact call again."
                        )
                        self.messages.append({
                            "role": "user",
                            "content": warning_text
                        })
                        self.console.print(f"\n[bold red]⚠️ Tool Loop Intercepted: Nudging agent to prevent repeated `{func_name}` failures.[/bold red]")

                    # Also track general failures by tool name to catch cases where the model
                    # changes arguments slightly but keeps failing the same tool type.
                    if not hasattr(self, "_tool_name_failure_counts"):
                        self._tool_name_failure_counts = {}
                    
                    name_count = self._tool_name_failure_counts.get(func_name, 0) + 1
                    self._tool_name_failure_counts[func_name] = name_count
                    
                    if name_count >= 4:
                        self._tool_name_failure_counts[func_name] = 0
                        warning_text = (
                            f"⚠️ [SYSTEM NOTICE] The tool `{func_name}` has failed 4 times with different arguments in this turn. "
                            f"Your general approach with `{func_name}` is failing. Please check if your file paths are absolute, "
                            f"if directories exist, or if command flags are correct. You MUST alter your strategy or verify "
                            f"path structure before calling `{func_name}` again."
                        )
                        self.messages.append({
                            "role": "user",
                            "content": warning_text
                        })
                        self.console.print(f"\n[bold red]⚠️ Tool Type Failure Loop Intercepted: Nudging agent for `{func_name}` general failures.[/bold red]")
                else:
                    # Successful tool run clears the failure counts
                    self._tool_failure_counts.pop(fingerprint, None)
                    if hasattr(self, "_tool_name_failure_counts"):
                        self._tool_name_failure_counts.pop(func_name, None)

            # Attempt to compress context if requested or if token limit is breached.
            # turn_msg_start is passed so that after compression rewrites
            # self.messages the method can refresh _current_turn_start.
            self._compress_intra_turn(turn_msg_start, compression_instruction)
            
            # Real-time persistence: save tool results and file diffs immediately
            self._persist_messages(in_progress_turn={
                "user_msg": user_message,
                "msg_start": turn_msg_start,
                "msg_end": len(self.messages),
                "messages": list(self.messages[turn_msg_start:]),
                "changes": list(self._turn_changes),
            })
            
            tool_duration = time.time() - t_tool_start
            self.turn_step_timings.append({
                "step": turn_iteration,
                "reasoning_time": reasoning_duration,
                "tool_time": tool_duration,
                "tools": [tc.get("function", {}).get("name", "") for tc in tool_calls]
            })

            # Mid-turn Real-time reflection: Evolve after every 3 iterations if tool errors occur
            if iteration > 0 and iteration % 3 == 0:
                try:
                    recent_start = max(turn_msg_start, len(self.messages) - 6)
                    recent_msgs = self.messages[recent_start:]
                    
                    has_errors = False
                    for m in recent_msgs:
                        if m.get("role") == "tool":
                            c_str = str(m.get("content", "")).lower()
                            if any(err_kw in c_str for err_kw in ["error", "failed", "exception", "not found", "invalid syntax", "undefined"]):
                                has_errors = True
                                break
                                
                    if has_errors:
                        last_assistant = ""
                        last_tools = []
                        for m in reversed(recent_msgs):
                            if m.get("role") == "assistant" and m.get("content"):
                                last_assistant = m["content"]
                                break
                        for m in recent_msgs:
                            if m.get("role") == "tool":
                                last_tools.append(m)
                                
                        if last_tools:
                            from utim_cli.reflection import run_reflection_phase
                            
                            def run_mid_turn_reflection_bg():
                                try:
                                    run_reflection_phase(
                                        user_message=user_message,
                                        assistant_content=last_assistant,
                                        tool_results=last_tools,
                                        elapsed_seconds=int(time.time() - task_start_time),
                                        iterations=iteration,
                                        hints=list(self.session_hints)
                                    )
                                    update_experience_summary_cache(user_message)
                                except Exception:
                                    pass
                            
                            threading.Thread(
                                target=run_mid_turn_reflection_bg,
                                daemon=True,
                                name=f"utim-mid-turn-reflector-iter-{iteration}"
                            ).start()
                except Exception:
                    pass
            
        else:
            if not self.cancel_event.is_set():
                self.console.print(f"\n[bold yellow]⚠ Agent paused after reaching maximum iterations ({max_iterations}).[/bold yellow]")
                self.console.print("[dim]You can type 'continue' to resume the task.[/dim]\n")

        elapsed = int(time.time() - task_start_time)
        elapsed_str = (
            f"{elapsed // 60}m {elapsed % 60}s" if elapsed >= 60 else f"{elapsed}s"
        )
        self.console.print(Rule(f"[dim]⚙  {elapsed_str}[/dim]"))

        # Save turn snapshot for /rewind (even if cancelled — partial work matters)
        # ALWAYS save the turn, even if there are no code changes, so the user can rewind the conversation
        if not self.cancel_event.is_set():
            turn_entry = {
                "user_msg": user_message,
                "msg_start": turn_msg_start,
                "msg_end": len(self.messages),
                "messages": list(self.messages[turn_msg_start:]),  # Save messages slice!
                "changes": list(self._turn_changes),
                "iteration_count": turn_iteration,
                "elapsed_time": elapsed,
                "step_timings": list(self.turn_step_timings),
            }
            self.turn_history.append(turn_entry)
            # Persist messages to server for /resume (background, non-blocking)
            self._persist_messages()
            self._trigger_bg_summarization()
            
            # Automated Reflection Phase and cleanup run in background, non-blocking
            def bg_reflection_and_cleanup(u_msg, a_content, t_results, el, iter_count, hints):
                try:
                    from utim_cli.reflection import run_reflection_phase
                    run_reflection_phase(
                        user_message=u_msg,
                        assistant_content=a_content,
                        tool_results=t_results,
                        elapsed_seconds=el,
                        iterations=iter_count,
                        hints=hints
                    )
                except Exception:
                    pass
                
                try:
                    self._cleanup_tmp_folder()
                except Exception:
                    pass

            threading.Thread(
                target=bg_reflection_and_cleanup,
                args=(user_message or "", final_answer or "", list(self._turn_changes) if self._turn_changes else [], int(elapsed), turn_iteration, list(self.session_hints)),
                daemon=True
            ).start()
            
        self._turn_changes = []

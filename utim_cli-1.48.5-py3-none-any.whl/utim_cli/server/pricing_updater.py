import logging
import datetime
import time
import threading
import requests
from utim_cli.server.models import MODEL_REGISTRY

logger = logging.getLogger("utim.pricing_updater")

def fetch_and_update_pricing() -> bool:
    logger.info("Fetching model pricing from OpenRouter...")
    try:
        # Fetch directly from OpenRouter
        response = requests.get("https://openrouter.ai/api/v1/models", timeout=15)
        if response.status_code != 200:
            logger.error(f"Failed to fetch models from OpenRouter: HTTP {response.status_code}")
            return False
        
        data = response.json()
        models_data = data.get("data", [])
        if not models_data:
            logger.error("No model data returned from OpenRouter")
            return False
        
        # Create a map of model_id -> data
        openrouter_models = {}
        for m in models_data:
            m_id = m.get("id")
            pricing = m.get("pricing")
            context_length = m.get("context_length")
            if m_id:
                openrouter_models[m_id] = {
                    "pricing": pricing,
                    "context_length": context_length
                }
                
        updated_count = 0
        for model_id, entry in MODEL_REGISTRY.items():
            if "free" in entry.tags:
                entry.cost_input_per_1k = 0.0
                entry.cost_output_per_1k = 0.0
                continue
            if model_id in openrouter_models:
                m_data = openrouter_models[model_id]
                pricing = m_data.get("pricing")
                context_length = m_data.get("context_length")
                
                if context_length is not None:
                    try:
                        entry.context_window = int(context_length)
                    except Exception as ce:
                        logger.error(f"Error parsing context_length for {model_id}: {ce}")

                if pricing:
                    try:
                        # prompt and completion are prices in USD per token
                        prompt_str = pricing.get("prompt", "0.0")
                        completion_str = pricing.get("completion", "0.0")
                        
                        prompt_usd = float(prompt_str)
                        completion_usd = float(completion_str)
                        
                        # Convert to USD per 1M tokens (credits per 1K tokens) and add 5% markup fee
                        cost_input = prompt_usd * 1_000_000 * 1.05
                        cost_output = completion_usd * 1_000_000 * 1.05
                        
                        entry.cost_input_per_1k = cost_input
                        entry.cost_output_per_1k = cost_output
                        updated_count += 1
                    except Exception as e:
                        logger.error(f"Error parsing pricing for model {model_id}: {e}")
                    
        logger.info(f"Successfully updated pricing for {updated_count} models (with 5% markup).")
        return True
    except Exception as e:
        logger.error(f"Error updating pricing from OpenRouter: {e}")
        return False

def start_pricing_scheduler():
    def scheduler_loop():
        # Fetch once on startup
        fetch_and_update_pricing()

        last_fetched_date = datetime.date.today()

        while True:
            try:
                now = datetime.datetime.now()
                # Check if it's 1 AM and we haven't fetched today yet
                if now.hour == 1 and now.date() != last_fetched_date:
                    fetch_and_update_pricing()
                    last_fetched_date = now.date()
            except Exception as e:
                logger.error(f"Error in pricing updater scheduler loop: {e}")
            
            # Sleep for 60 seconds before checking again
            time.sleep(60)

    thread = threading.Thread(target=scheduler_loop, daemon=True)
    thread.start()

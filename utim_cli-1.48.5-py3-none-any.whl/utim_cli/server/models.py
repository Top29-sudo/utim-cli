"""
Model registry, routing logic, and cost estimation for the UTIM server.
"""
from __future__ import annotations
from typing import Optional

MODEL_ID = str

class ModelEntry:
    def __init__(
        self,
        model_id: MODEL_ID,
        provider: str,
        cost_input_per_1k: float,
        cost_output_per_1k: float,
        context_window: int,
        capabilities: list[str] | None = None,
        tags: list[str] | None = None,
        max_output_tokens: Optional[int] = None,
    ):
        self.model_id = model_id
        self.provider = provider
        self.cost_input_per_1k = cost_input_per_1k
        self.cost_output_per_1k = cost_output_per_1k
        self.context_window = context_window
        self.capabilities = capabilities or []
        self.tags = tags or []
        # Real max completion tokens as reported by the provider.
        # None means "unknown" — caller should use a safe default.
        self.max_output_tokens: Optional[int] = max_output_tokens

    def __repr__(self) -> str:
        return (
            f"ModelEntry({self.model_id}, provider={self.provider}, "
            f"cost_in={self.cost_input_per_1k}/1k, context={self.context_window}, "
            f"max_output={self.max_output_tokens})"
        )


# ─── Registered Models ────────────────────────────────────────────────────────
# ─── Helpers ──────────────────────────────────────────────────────────────────

def get_max_output_tokens(model_id: MODEL_ID, fallback: int = 32_768) -> int:
    """Return the real max completion tokens for *model_id* from the registry.

    Falls back to *fallback* (default 32 768) when the model is not listed or
    its ``max_output_tokens`` was not set (i.e. is ``None``).
    """
    entry = MODEL_REGISTRY.get(model_id)
    if entry is not None and entry.max_output_tokens is not None:
        return entry.max_output_tokens
    return fallback


MODEL_REGISTRY: dict[MODEL_ID, ModelEntry] = {
    "nex-agi/nex-n2-pro:free": ModelEntry(
        model_id="nex-agi/nex-n2-pro:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=128_000,
        capabilities=["code", "chat", "tool_use"],
        tags=["free", "default"],
        max_output_tokens=262_144,
    ),
    "poolside/laguna-m.1:free": ModelEntry(
        model_id="poolside/laguna-m.1:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=100_000,
        capabilities=["code", "chat", "tool_use"],
        tags=["free"],
    ),
    "cohere/north-mini-code:free": ModelEntry(
        model_id="cohere/north-mini-code:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=128_000,
        capabilities=["code", "chat", "tool_use"],
        tags=["free"],
    ),
    "openrouter/free": ModelEntry(
        model_id="openrouter/free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=128_000,
        capabilities=["chat"],
        tags=["free"],
    ),
    "google/gemma-4-31b-it:free": ModelEntry(
        model_id="google/gemma-4-31b-it:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=128_000,
        capabilities=["chat"],
        tags=["free"],
    ),
    "google/gemma-4-26b-a4b-it:free": ModelEntry(
        model_id="google/gemma-4-26b-a4b-it:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=128_000,
        capabilities=["chat"],
        tags=["free"],
    ),
    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free": ModelEntry(
        model_id="nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=128_000,
        capabilities=["chat"],
        tags=["free"],
    ),
    "nvidia/nemotron-nano-12b-v2-vl:free": ModelEntry(
        model_id="nvidia/nemotron-nano-12b-v2-vl:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=128_000,
        capabilities=["chat"],
        tags=["free"],
    ),
    "openai/gpt-oss-20b:free": ModelEntry(
        model_id="openai/gpt-oss-20b:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=128_000,
        capabilities=["chat"],
        tags=["free"],
    ),
    "poolside/laguna-xs.2:free": ModelEntry(
        model_id="poolside/laguna-xs.2:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=32_000,
        capabilities=["chat"],
        tags=["free"],
    ),
    "qwen/qwen3-next-80b-a3b-instruct:free": ModelEntry(
        model_id="qwen/qwen3-next-80b-a3b-instruct:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=80_000,
        capabilities=["chat"],
        tags=["free"],
    ),
    "xiaomi/mimo-v2-pro": ModelEntry(
        model_id="xiaomi/mimo-v2-pro",
        provider="openrouter",
        cost_input_per_1k=1.0,
        cost_output_per_1k=2.0,
        context_window=1_048_576,
        capabilities=["chat"],
        tags=["new"],
    ),
    "kwaipilot/kat-coder-air-v2.5": ModelEntry(
        model_id="kwaipilot/kat-coder-air-v2.5",
        provider="openrouter",
        cost_input_per_1k=0.00015,
        cost_output_per_1k=0.0006,
        context_window=256_000,
        capabilities=["code", "chat", "tool_use"],
        tags=["new"],
        max_output_tokens=80_000,
    ),
    "kwaipilot/kat-coder-pro-v2.5": ModelEntry(
        model_id="kwaipilot/kat-coder-pro-v2.5",
        provider="openrouter",
        cost_input_per_1k=0.00074,
        cost_output_per_1k=0.00296,
        context_window=256_000,
        capabilities=["code", "chat", "tool_use"],
        tags=["new"],
        max_output_tokens=80_000,
    ),
    "nex-agi/nex-n2-mini": ModelEntry(
        model_id="nex-agi/nex-n2-mini",
        provider="openrouter",
        cost_input_per_1k=0.000025,
        cost_output_per_1k=0.0001,
        context_window=262_144,
        capabilities=["code", "chat", "tool_use"],
        tags=["new"],
        max_output_tokens=262_144,
    ),
    "minimax/minimax-m2.7": ModelEntry(
        model_id="minimax/minimax-m2.7",
        provider="openrouter",
        cost_input_per_1k=1.02,
        cost_output_per_1k=2.04,
        context_window=204_800,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=131_072,
    ),
    "z-ai/glm-5.1": ModelEntry(
        model_id="z-ai/glm-5.1",
        provider="openrouter",
        cost_input_per_1k=1.02,
        cost_output_per_1k=2.04,
        context_window=202_752,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "anthropic/claude-sonnet-4.6": ModelEntry(
        model_id="anthropic/claude-sonnet-4.6",
        provider="openrouter",
        cost_input_per_1k=3.0,
        cost_output_per_1k=15.0,
        context_window=1_000_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "google/gemini-3.1-pro-preview": ModelEntry(
        model_id="google/gemini-3.1-pro-preview",
        provider="openrouter",
        cost_input_per_1k=1.25,
        cost_output_per_1k=5.0,
        context_window=1_000_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=65_536,
    ),
    "anthropic/claude-opus-4.6": ModelEntry(
        model_id="anthropic/claude-opus-4.6",
        provider="openrouter",
        cost_input_per_1k=15.0,
        cost_output_per_1k=75.0,
        context_window=1_000_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "openai/gpt-5.3-codex": ModelEntry(
        model_id="openai/gpt-5.3-codex",
        provider="openrouter",
        cost_input_per_1k=10.2,
        cost_output_per_1k=30.6,
        context_window=400_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "inclusionai/ling-2.6-flash": ModelEntry(
        model_id="inclusionai/ling-2.6-flash",
        provider="openrouter",
        cost_input_per_1k=0.0102,
        cost_output_per_1k=0.0306,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=32_768,
    ),
    "xiaomi/mimo-v2.5": ModelEntry(
        model_id="xiaomi/mimo-v2.5",
        provider="openrouter",
        cost_input_per_1k=0.1428,
        cost_output_per_1k=0.2856,
        context_window=128_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=131_072,
    ),
    "xiaomi/mimo-v2.5-pro": ModelEntry(
        model_id="xiaomi/mimo-v2.5-pro",
        provider="openrouter",
        cost_input_per_1k=1.02,
        cost_output_per_1k=3.06,
        context_window=128_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=131_072,
    ),
    "deepseek/deepseek-v4-flash": ModelEntry(
        model_id="deepseek/deepseek-v4-flash",
        provider="openrouter",
        cost_input_per_1k=0.0918,
        cost_output_per_1k=0.1836,
        context_window=64_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=32_768,  # OpenRouter reports None; use safe default
    ),
    "deepseek/deepseek-v4-pro": ModelEntry(
        model_id="deepseek/deepseek-v4-pro",
        provider="openrouter",
        cost_input_per_1k=0.4437,
        cost_output_per_1k=0.8874,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=384_000,
    ),
    "openai/gpt-5.5": ModelEntry(
        model_id="openai/gpt-5.5",
        provider="openrouter",
        cost_input_per_1k=5.1,
        cost_output_per_1k=30.6,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "inclusionai/ling-2.6-1t": ModelEntry(
        model_id="inclusionai/ling-2.6-1t",
        provider="openrouter",
        cost_input_per_1k=0.306,
        cost_output_per_1k=2.55,
        context_window=262_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=32_768,
    ),
    "moonshotai/kimi-k2.6": ModelEntry(
        model_id="moonshotai/kimi-k2.6",
        provider="openrouter",
        cost_input_per_1k=0.969,
        cost_output_per_1k=4.08,
        context_window=128_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=262_144,
    ),
    "google/gemini-3.1-pro-preview-customtools": ModelEntry(
        model_id="google/gemini-3.1-pro-preview-customtools",
        provider="openrouter",
        cost_input_per_1k=1.275,
        cost_output_per_1k=5.1,
        context_window=1_000_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=65_536,
    ),
    "openai/gpt-5.4": ModelEntry(
        model_id="openai/gpt-5.4",
        provider="openrouter",
        cost_input_per_1k=2.55,
        cost_output_per_1k=15.3,
        context_window=128_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "kwaipilot/kat-coder-pro-v2": ModelEntry(
        model_id="kwaipilot/kat-coder-pro-v2",
        provider="openrouter",
        cost_input_per_1k=0.306,
        cost_output_per_1k=1.224,
        context_window=256_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=80_000,
    ),
    "anthropic/claude-fable-5": ModelEntry(
        model_id="anthropic/claude-fable-5",
        provider="openrouter",
        cost_input_per_1k=10.2,
        cost_output_per_1k=51.0,
        context_window=200_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "nex-agi/nex-n2-pro": ModelEntry(
        model_id="nex-agi/nex-n2-pro",
        provider="openrouter",
        cost_input_per_1k=1.02,
        cost_output_per_1k=2.04,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=262_144,
    ),
    "minimax/minimax-m3": ModelEntry(
        model_id="minimax/minimax-m3",
        provider="openrouter",
        cost_input_per_1k=0.306,
        cost_output_per_1k=1.224,
        context_window=128_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=512_000,
    ),
    "moonshotai/kimi-k2.7-code": ModelEntry(
        model_id="moonshotai/kimi-k2.7-code",
        provider="openrouter",
        cost_input_per_1k=0.969,
        cost_output_per_1k=4.08,
        context_window=262_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=262_144,
    ),
    "deepseek/deepseek-r1": ModelEntry(
        model_id="deepseek/deepseek-r1",
        provider="openrouter",
        cost_input_per_1k=0.714,
        cost_output_per_1k=2.55,
        context_window=163_840,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=16_000,
    ),
    "x-ai/grok-4.3": ModelEntry(
        model_id="x-ai/grok-4.3",
        provider="openrouter",
        cost_input_per_1k=1.275,
        cost_output_per_1k=2.55,
        context_window=128_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=32_768,  # OpenRouter reports None; use safe default
    ),
    "google/gemini-3.5-flash": ModelEntry(
        model_id="google/gemini-3.5-flash",
        provider="openrouter",
        cost_input_per_1k=1.53,
        cost_output_per_1k=9.18,
        context_window=1_000_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=65_536,
    ),
    "google/gemini-3.6-flash": ModelEntry(
        model_id="google/gemini-3.6-flash",
        provider="openrouter",
        cost_input_per_1k=1.53,
        cost_output_per_1k=7.65,
        context_window=1_048_576,
        capabilities=["chat", "code", "tool_use"],
        tags=["premium"],
        max_output_tokens=65_536,
    ),
    "poolside/laguna-s-2.1:free": ModelEntry(
        model_id="poolside/laguna-s-2.1:free",
        provider="openrouter",
        cost_input_per_1k=0.0002,
        cost_output_per_1k=0.0003,
        context_window=1_048_576,
        capabilities=["code", "chat", "tool_use"],
        tags=["free"],
    ),
    "krea/krea-2-medium-turbo": ModelEntry(
        model_id="krea/krea-2-medium-turbo",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.015750,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "krea/krea-2-medium": ModelEntry(
        model_id="krea/krea-2-medium",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.031500,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "krea/krea-2-large": ModelEntry(
        model_id="krea/krea-2-large",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.063000,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "krea/krea-2": ModelEntry(
        model_id="krea/krea-2",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.031500,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "qwen/qwen3.7-max": ModelEntry(
        model_id="qwen/qwen3.7-max",
        provider="openrouter",
        cost_input_per_1k=1.275,
        cost_output_per_1k=3.825,
        context_window=1_000_000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=65_536,
    ),
    "stepfun/step-3.7-flash": ModelEntry(
        model_id="stepfun/step-3.7-flash",
        provider="openrouter",
        cost_input_per_1k=0.204,
        cost_output_per_1k=1.173,
        context_window=128_000,
        capabilities=["chat"],
        tags=["premium"],
        max_output_tokens=256_000,
    ),
    "black-forest-labs/flux.2-flex": ModelEntry(
        model_id="black-forest-labs/flux.2-flex",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.030600,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "black-forest-labs/flux.2-max": ModelEntry(
        model_id="black-forest-labs/flux.2-max",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.051000,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "black-forest-labs/flux.2-klein-4b": ModelEntry(
        model_id="black-forest-labs/flux.2-klein-4b",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.010200,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "sourceful/riverflow-v2-fast": ModelEntry(
        model_id="sourceful/riverflow-v2-fast",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.010200,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "sourceful/riverflow-v2-pro": ModelEntry(
        model_id="sourceful/riverflow-v2-pro",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.035700,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "sourceful/riverflow-v2.5-fast": ModelEntry(
        model_id="sourceful/riverflow-v2.5-fast",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.015300,
        context_window=1000,
        capabilities=["image"],
        tags=["premium"],
    ),
    "google/gemini-3-pro-image-preview": ModelEntry(
        model_id="google/gemini-3-pro-image-preview",
        provider="openrouter",
        cost_input_per_1k=0.002040,
        cost_output_per_1k=0.012240,
        context_window=128_000,
        capabilities=["chat", "image"],
        tags=["premium"],
    ),
    "google/gemini-3.1-flash-image-preview": ModelEntry(
        model_id="google/gemini-3.1-flash-image-preview",
        provider="openrouter",
        cost_input_per_1k=0.51,
        cost_output_per_1k=3.06,
        context_window=128_000,
        capabilities=["chat", "image"],
        tags=["premium"],
    ),
    "google/gemini-3.1-flash-image": ModelEntry(
        model_id="google/gemini-3.1-flash-image",
        provider="openrouter",
        cost_input_per_1k=0.000510,
        cost_output_per_1k=0.003060,
        context_window=128_000,
        capabilities=["chat", "image"],
        tags=["premium"],
    ),
    "openai/gpt-5-image-mini": ModelEntry(
        model_id="openai/gpt-5-image-mini",
        provider="openrouter",
        cost_input_per_1k=0.002550,
        cost_output_per_1k=0.002040,
        context_window=400_000,
        capabilities=["chat", "image"],
        tags=["premium"],
    ),
    "openai/gpt-image-2": ModelEntry(
        model_id="openai/gpt-image-2",
        provider="openrouter",
        cost_input_per_1k=0.020400,
        cost_output_per_1k=0.020400,
        context_window=128_000,
        capabilities=["chat", "image"],
        tags=["premium"],
    ),
    "anthropic/claude-sonnet-4.5": ModelEntry(
        model_id="anthropic/claude-sonnet-4.5",
        provider="openrouter",
        cost_input_per_1k=3.06,
        cost_output_per_1k=15.3,
        context_window=1000000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=64_000,
    ),
    "anthropic/claude-opus-4.5": ModelEntry(
        model_id="anthropic/claude-opus-4.5",
        provider="openrouter",
        cost_input_per_1k=5.1,
        cost_output_per_1k=25.5,
        context_window=200000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=64_000,
    ),
    "anthropic/claude-opus-4.7": ModelEntry(
        model_id="anthropic/claude-opus-4.7",
        provider="openrouter",
        cost_input_per_1k=5.1,
        cost_output_per_1k=25.5,
        context_window=1000000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "anthropic/claude-opus-4.8": ModelEntry(
        model_id="anthropic/claude-opus-4.8",
        provider="openrouter",
        cost_input_per_1k=5.1,
        cost_output_per_1k=25.5,
        context_window=1000000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "anthropic/claude-sonnet-5": ModelEntry(
        model_id="anthropic/claude-sonnet-5",
        provider="openrouter",
        cost_input_per_1k=2.04,
        cost_output_per_1k=10.2,
        context_window=1000000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "z-ai/glm-5-turbo": ModelEntry(
        model_id="z-ai/glm-5-turbo",
        provider="openrouter",
        cost_input_per_1k=1.224,
        cost_output_per_1k=4.08,
        context_window=262144,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=131_072,
    ),
    "z-ai/glm-4.7": ModelEntry(
        model_id="z-ai/glm-4.7",
        provider="openrouter",
        cost_input_per_1k=0.408,
        cost_output_per_1k=1.785,
        context_window=202752,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=131_072,
    ),
    "z-ai/glm-5": ModelEntry(
        model_id="z-ai/glm-5",
        provider="openrouter",
        cost_input_per_1k=0.612,
        cost_output_per_1k=1.9584,
        context_window=202752,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=202_752,
    ),
    "z-ai/glm-5.2": ModelEntry(
        model_id="z-ai/glm-5.2",
        provider="openrouter",
        cost_input_per_1k=0.9486,
        cost_output_per_1k=3.06,
        context_window=1048576,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=131_072,
    ),
    "qwen/qwen3.7-plus": ModelEntry(
        model_id="qwen/qwen3.7-plus",
        provider="openrouter",
        cost_input_per_1k=0.3264,
        cost_output_per_1k=1.3056,
        context_window=1000000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=65_536,
    ),
    "qwen/qwen3.6-plus": ModelEntry(
        model_id="qwen/qwen3.6-plus",
        provider="openrouter",
        cost_input_per_1k=0.3315,
        cost_output_per_1k=1.989,
        context_window=1000000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=65_536,
    ),
    "openai/gpt-5.4-mini": ModelEntry(
        model_id="openai/gpt-5.4-mini",
        provider="openrouter",
        cost_input_per_1k=0.765,
        cost_output_per_1k=4.59,
        context_window=400000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=128_000,
    ),
    "minimax/minimax-m2.5": ModelEntry(
        model_id="minimax/minimax-m2.5",
        provider="openrouter",
        cost_input_per_1k=0.1224,
        cost_output_per_1k=0.4896,
        context_window=204800,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=196_608,
    ),
    "x-ai/grok-4.20": ModelEntry(
        model_id="x-ai/grok-4.20",
        provider="openrouter",
        cost_input_per_1k=1.275,
        cost_output_per_1k=2.55,
        context_window=2000000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=32_768,  # OpenRouter reports None; use safe default
    ),
    "x-ai/grok-build-0.1": ModelEntry(
        model_id="x-ai/grok-build-0.1",
        provider="openrouter",
        cost_input_per_1k=1.02,
        cost_output_per_1k=2.04,
        context_window=256000,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=32_768,  # OpenRouter reports None; use safe default
    ),
    "moonshotai/kimi-k2.5": ModelEntry(
        model_id="moonshotai/kimi-k2.5",
        provider="openrouter",
        cost_input_per_1k=0.3825,
        cost_output_per_1k=2.0655,
        context_window=262144,
        capabilities=["chat", "code"],
        tags=["premium"],
        max_output_tokens=262_144,
    ),
    "recraft/recraft-v4.1": ModelEntry(
        model_id="recraft/recraft-v4.1",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.035700,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1-pro": ModelEntry(
        model_id="recraft/recraft-v4.1-pro",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.306000,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1-utility": ModelEntry(
        model_id="recraft/recraft-v4.1-utility",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.035700,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1-utility-pro": ModelEntry(
        model_id="recraft/recraft-v4.1-utility-pro",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.306000,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1-vector": ModelEntry(
        model_id="recraft/recraft-v4.1-vector",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.051000,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1-pro-vector": ModelEntry(
        model_id="recraft/recraft-v4.1-pro-vector",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.306000,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "x-ai/grok-imagine-image-quality": ModelEntry(
        model_id="x-ai/grok-imagine-image-quality",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.040800,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "microsoft/mai-image-2.5": ModelEntry(
        model_id="microsoft/mai-image-2.5",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.020400,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "sourceful/riverflow-v2.5-fast": ModelEntry(
        model_id="sourceful/riverflow-v2.5-fast",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.015300,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "sourceful/riverflow-v2.5-pro": ModelEntry(
        model_id="sourceful/riverflow-v2.5-pro",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.040800,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "sourceful/riverflow-v2.5-fast": ModelEntry(
        model_id="sourceful/riverflow-v2.5-fast",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.010200,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "sourceful/riverflow-v2-pro": ModelEntry(
        model_id="sourceful/riverflow-v2-pro",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.035700,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "sourceful/riverflow-v2-fast": ModelEntry(
        model_id="sourceful/riverflow-v2-fast",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.010200,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "black-forest-labs/flux.2-pro": ModelEntry(
        model_id="black-forest-labs/flux.2-pro",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.030600,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "black-forest-labs/flux.2-flex": ModelEntry(
        model_id="black-forest-labs/flux.2-flex",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.030600,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "black-forest-labs/flux.2-max": ModelEntry(
        model_id="black-forest-labs/flux.2-max",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.051000,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "black-forest-labs/flux.2-klein-4b": ModelEntry(
        model_id="black-forest-labs/flux.2-klein-4b",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.010200,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "bytedance-seed/seedream-4.5": ModelEntry(
        model_id="bytedance-seed/seedream-4.5",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.040800,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v3": ModelEntry(
        model_id="recraft/recraft-v3",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.040800,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4": ModelEntry(
        model_id="recraft/recraft-v4",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.040800,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4-pro": ModelEntry(
        model_id="recraft/recraft-v4-pro",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.255000,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4-vector": ModelEntry(
        model_id="recraft/recraft-v4-vector",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.081600,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4-pro-vector": ModelEntry(
        model_id="recraft/recraft-v4-pro-vector",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.306000,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1": ModelEntry(
        model_id="recraft/recraft-v4.1",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.035700,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1-pro": ModelEntry(
        model_id="recraft/recraft-v4.1-pro",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.214200,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1-vector": ModelEntry(
        model_id="recraft/recraft-v4.1-vector",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.081600,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "recraft/recraft-v4.1-pro-vector": ModelEntry(
        model_id="recraft/recraft-v4.1-pro-vector",
        provider="openrouter",
        cost_input_per_1k=0.000000,
        cost_output_per_1k=0.306000,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "google/gemini-3-pro-image": ModelEntry(
        model_id="google/gemini-3-pro-image",
        provider="openrouter",
        cost_input_per_1k=0.002040,
        cost_output_per_1k=0.012240,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "google/gemini-3.1-flash-image": ModelEntry(
        model_id="google/gemini-3.1-flash-image",
        provider="openrouter",
        cost_input_per_1k=0.000510,
        cost_output_per_1k=0.003060,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "openai/gpt-image-1": ModelEntry(
        model_id="openai/gpt-image-1",
        provider="openrouter",
        cost_input_per_1k=0.002040,
        cost_output_per_1k=0.002040,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "openai/gpt-image-1-mini": ModelEntry(
        model_id="openai/gpt-image-1-mini",
        provider="openrouter",
        cost_input_per_1k=0.000510,
        cost_output_per_1k=0.000510,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "openai/gpt-image-2": ModelEntry(
        model_id="openai/gpt-image-2",
        provider="openrouter",
        cost_input_per_1k=0.020400,
        cost_output_per_1k=0.020400,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "google/gemini-2.5-flash-image": ModelEntry(
        model_id="google/gemini-2.5-flash-image",
        provider="openrouter",
        cost_input_per_1k=0.000306,
        cost_output_per_1k=0.002550,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "openai/gpt-5-image": ModelEntry(
        model_id="openai/gpt-5-image",
        provider="openrouter",
        cost_input_per_1k=0.010200,
        cost_output_per_1k=0.010200,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "openai/gpt-5-image-mini": ModelEntry(
        model_id="openai/gpt-5-image-mini",
        provider="openrouter",
        cost_input_per_1k=0.002550,
        cost_output_per_1k=0.002040,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "google/gemini-3-pro-image-preview": ModelEntry(
        model_id="google/gemini-3-pro-image-preview",
        provider="openrouter",
        cost_input_per_1k=0.002040,
        cost_output_per_1k=0.012240,
        context_window=100000,
        capabilities=["image_generation"],
        tags=["image"],
    ),
    "aion-labs/aion-3.0": ModelEntry(
        model_id="aion-labs/aion-3.0",
        provider="openrouter",
        cost_input_per_1k=1.0,
        cost_output_per_1k=2.0,
        context_window=200_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "aion-labs/aion-3.0-mini": ModelEntry(
        model_id="aion-labs/aion-3.0-mini",
        provider="openrouter",
        cost_input_per_1k=0.1,
        cost_output_per_1k=0.2,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "x-ai/grok-4.5": ModelEntry(
        model_id="x-ai/grok-4.5",
        provider="openrouter",
        cost_input_per_1k=2.0,
        cost_output_per_1k=10.0,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "openai/gpt-5.6-luna-pro": ModelEntry(
        model_id="openai/gpt-5.6-luna-pro",
        provider="openrouter",
        cost_input_per_1k=5.0,
        cost_output_per_1k=15.0,
        context_window=200_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "openai/gpt-5.6-luna": ModelEntry(
        model_id="openai/gpt-5.6-luna",
        provider="openrouter",
        cost_input_per_1k=2.5,
        cost_output_per_1k=7.5,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "openai/gpt-5.6-terra-pro": ModelEntry(
        model_id="openai/gpt-5.6-terra-pro",
        provider="openrouter",
        cost_input_per_1k=4.0,
        cost_output_per_1k=12.0,
        context_window=200_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "openai/gpt-5.6-terra": ModelEntry(
        model_id="openai/gpt-5.6-terra",
        provider="openrouter",
        cost_input_per_1k=2.0,
        cost_output_per_1k=6.0,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "openai/gpt-5.6-sol-pro": ModelEntry(
        model_id="openai/gpt-5.6-sol-pro",
        provider="openrouter",
        cost_input_per_1k=3.0,
        cost_output_per_1k=9.0,
        context_window=200_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "openai/gpt-5.6-sol": ModelEntry(
        model_id="openai/gpt-5.6-sol",
        provider="openrouter",
        cost_input_per_1k=1.5,
        cost_output_per_1k=4.5,
        context_window=128_000,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "thinkingmachines/inkling": ModelEntry(
        model_id="thinkingmachines/inkling",
        provider="openrouter",
        cost_input_per_1k=0.00105,
        cost_output_per_1k=0.0042525,
        context_window=1_048_576,
        capabilities=["chat", "code"],
        tags=["premium"],
    ),
    "moonshotai/kimi-k3": ModelEntry(
        model_id="moonshotai/kimi-k3",
        provider="openrouter",
        cost_input_per_1k=0.00315,
        cost_output_per_1k=0.01575,
        context_window=1_000_000,
        capabilities=["chat", "reasoning"],
        tags=["premium", "reasoning"],
    ),
    "meta/muse-spark-1.1": ModelEntry(
        model_id="meta/muse-spark-1.1",
        provider="openrouter",
        cost_input_per_1k=0.0013125,
        cost_output_per_1k=0.0044625,
        context_window=1_048_576,
        capabilities=["chat", "code", "multimodal"],
        tags=["premium", "multimodal"],
    ),
}

def _load_all_openrouter_models():
    import json, os
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    models_txt_path = os.path.join(root_dir, "models.txt")
    if not os.path.exists(models_txt_path):
        models_txt_path = "models.txt"
        
    if os.path.exists(models_txt_path):
        try:
            with open(models_txt_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data.get("data", []) if isinstance(data, dict) else data
            for m in items:
                mid = m.get("id")
                if not mid or mid in MODEL_REGISTRY:
                    continue
                pricing = m.get("pricing", {})
                try:
                    p_in = float(pricing.get("prompt", 0)) * 1_000_000 * 1.02
                except Exception:
                    p_in = 1.0
                try:
                    p_out = float(pricing.get("completion", 0)) * 1_000_000 * 1.02
                except Exception:
                    p_out = 2.0
                ctx = m.get("context_length", 128_000)
                is_free = mid.endswith(":free") or ":free" in mid or (p_in == 0 and p_out == 0)
                tags = ["free"] if is_free else ["premium"]
                arch = m.get("architecture", {})
                in_mods = arch.get("input_modalities", [])
                out_mods = arch.get("output_modalities", [])
                caps = ["chat"]
                if "image" in in_mods:
                    caps.append("vision")
                if "image" in out_mods:
                    caps.append("image")
                    
                MODEL_REGISTRY[mid] = ModelEntry(
                    model_id=mid,
                    provider="openrouter",
                    cost_input_per_1k=p_in if not is_free else 0.0002,
                    cost_output_per_1k=p_out if not is_free else 0.0003,
                    context_window=ctx,
                    capabilities=caps,
                    tags=tags,
                )
        except Exception:
            pass

_load_all_openrouter_models()

# Default model used when the user does not specify one
DEFAULT_MODEL: MODEL_ID = "cohere/north-mini-code:free"


# ─── Routing helpers ──────────────────────────────────────────────────────────

def get_model(model_id: MODEL_ID | None = None) -> ModelEntry:
    """Return a ModelEntry. Falls back to DEFAULT_MODEL if not found."""
    if model_id and model_id in MODEL_REGISTRY:
        return MODEL_REGISTRY[model_id]
    return MODEL_REGISTRY[DEFAULT_MODEL]


def list_models() -> list[ModelEntry]:
    """Return all registered models."""
    return list(MODEL_REGISTRY.values())


def estimate_cost(
    model_id: MODEL_ID,
    input_tokens: int,
    output_tokens: int,
    is_upgraded: bool = False,
) -> float:
    """Return estimated cost in credits for a request."""
    # Check if this is a free model (ends with :free, openrouter/free, or tagged free in registry)
    is_free = model_id.endswith(":free") or model_id == "openrouter/free"
    if not is_free:
        m = MODEL_REGISTRY.get(model_id)
        if m and "free" in m.tags:
            is_free = True
            
    if is_free:
        if is_upgraded:
            # Upgraded pricing: $0.002 per 1M input, $0.003 per 1M output
            # Mapped to credits (1 USD = 1,000 credits):
            # 0.002 credits per 1,000 input tokens, 0.003 credits per 1,000 output tokens
            return (input_tokens / 1_000) * 0.002 + (output_tokens / 1_000) * 0.003
        else:
            # Free models pricing: $0.2 per 1M input, $0.3 per 1M output
            # Mapped to credits (1 USD = 1,000 credits):
            # 0.2 credits per 1,000 input tokens, 0.3 credits per 1,000 output tokens
            return (input_tokens / 1_000) * 0.2 + (output_tokens / 1_000) * 0.3
        
    m = get_model(model_id)
    return (input_tokens / 1_000) * m.cost_input_per_1k + (
        output_tokens / 1_000
    ) * m.cost_output_per_1k


def route_model(task_description: str) -> MODEL_ID:
    """
    Simple heuristic router — can be swapped out for model-based routing later.

    Currently falls back to the DEFAULT_MODEL.
    """
    _ = task_description  # reserved for future LLM-based routing
    return DEFAULT_MODEL

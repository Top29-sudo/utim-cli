"""
UTIM Production Server — FastAPI Application
Deployed at: api.utim.dev

Environment variables (set in Railway dashboard):
  DATABASE_URL         PostgreSQL connection string (auto-set by Railway Postgres plugin)
  OPENROUTER_API_KEY   OpenRouter API key for LLM calls
  UTIM_MASTER_KEY      Secret key for admin endpoints (/auth/topup)
  LOG_LEVEL            (optional) DEBUG | INFO | WARNING  (default: INFO)
"""
from __future__ import annotations

import logging
import os
from typing import List, Dict, Any

from fastapi import FastAPI, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text
from pydantic import BaseModel
from openai import AsyncOpenAI

from .db import init_db, SessionLocal
from .logging_config import configure_logging, RequestLoggingMiddleware
from .rate_limit import limiter
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from .routes import auth_router, credit_router, session_router, completion_router, quota_router, share_router, feedback_router, referral_router, quota_share_router
from .models import list_models
from .auth import get_admin_user

# ── Logging ───────────────────────────────────────────────────────────────────

configure_logging(level=os.environ.get("LOG_LEVEL", "INFO"))
logger = logging.getLogger("utim.server")

# ── Database init ─────────────────────────────────────────────────────────────

init_db()

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="UTIM Agent Server",
    description=(
        "Production backend for the UTIM CLI agent. "
        "Handles authentication, credit billing, LLM proxying, and chat history."
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# CORS — allow CLI, web landing client, and local dev servers
allowed_origins_env = os.environ.get("ALLOWED_ORIGINS")
if allowed_origins_env:
    allowed_origins = [o.strip() for o in allowed_origins_env.split(",") if o.strip()]
else:
    allowed_origins = [
        "https://utim.dev",
        "https://api.utim.dev",
        "http://localhost:3000",
        "http://localhost:5173",
        "http://localhost:8000",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    ]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1|.*\.utim\.dev|utim\.dev)(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse

class LimitUploadSize(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if request.headers.get("content-length"):
            if int(request.headers["content-length"]) > 4_000_000:  # 4MB limit
                return JSONResponse({"detail": "Request too large"}, status_code=413)
        return await call_next(request)

app.add_middleware(LimitUploadSize)

app.add_middleware(RequestLoggingMiddleware)

# ── Routers ───────────────────────────────────────────────────────────────────

app.include_router(auth_router)
app.include_router(credit_router)
app.include_router(session_router)
app.include_router(completion_router)
app.include_router(quota_router)
app.include_router(share_router)
app.include_router(feedback_router)
app.include_router(referral_router)
app.include_router(quota_share_router)

# ── Support Chatbot Endpoint ──────────────────────────────────────────────────

class SupportChatRequest(BaseModel):
    model: str = "openrouter/free"
    messages: List[Dict[str, Any]]
    tools: List[Dict[str, Any]] | None = None

@app.post("/api/support-chat", tags=["support"])
async def support_chat(req: SupportChatRequest):
    key = os.environ.get("OPENROUTER_API_KEY")
    if not key:
        return {
            "reply": "Support API key not configured on the server. Please set OPENROUTER_API_KEY.",
            "message": {"role": "assistant", "content": "Support API key not configured on the server."}
        }
    
    try:
        client = AsyncOpenAI(
            api_key=key,
            base_url="https://openrouter.ai/api/v1",
        )
        kwargs = {
            "model": req.model,
            "messages": req.messages,
            "timeout": 30,
        }
        if req.tools:
            kwargs["tools"] = req.tools
            
        response = await client.chat.completions.create(**kwargs)
        choice_message = response.choices[0].message
        
        tool_calls = None
        if choice_message.tool_calls:
            tool_calls = []
            for t in choice_message.tool_calls:
                tool_calls.append({
                    "id": t.id,
                    "type": t.type,
                    "function": {
                        "name": t.function.name,
                        "arguments": t.function.arguments
                    }
                })

        return {
            "reply": choice_message.content or "",
            "message": {
                "role": "assistant",
                "content": choice_message.content or "",
                "tool_calls": tool_calls
            }
        }
    except Exception as exc:
        logger.error(f"support_chat_error: {exc}")
        return {
            "reply": f"Sorry, I had trouble processing that request: {str(exc)}",
            "message": {
                "role": "assistant",
                "content": f"Sorry, I had trouble processing that request: {str(exc)}"
            }
        }

# ── Core endpoints ────────────────────────────────────────────────────────────

def _find_changelog_path():
    import os
    # Search multiple candidates for CHANGELOG.md (robust on both local dev and Railway production)
    candidates = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "CHANGELOG.md"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "CHANGELOG.md"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "CHANGELOG.md"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "CHANGELOG.md"),
    ]
    for path in candidates:
        if os.path.exists(path):
            return path
    return None


@app.get("/health", tags=["system"], summary="Health check")
def health():
    """Always returns 200 so Railway health checks pass.
    DB status is reported in the body for diagnostics.
    """
    db_status = "ok"
    db_error = None
    try:
        db = SessionLocal()
        db.execute(text("SELECT 1"))
        db.close()
    except Exception as exc:
        db_error = str(exc)
        logger.error(f"health_db_error: {exc}")
        db_status = "error"

    # Derive version dynamically from CHANGELOG.md so a deploy auto-updates it
    try:
        import re as _re
        _cl_path = _find_changelog_path()
        _version = "1.47.16"
        if _cl_path:
            with open(_cl_path, "r", encoding="utf-8") as _f:
                for _line in _f:
                    _m = _re.match(r"^##\s+\[?([0-9a-zA-Z\.\-]+)\]?\s*-", _line.strip())
                    if _m:
                        _version = _m.group(1)
                        break
    except Exception:
        _version = "1.47.16"

    # Always return 200 — Railway must see 200 or it will keep restarting.
    # DB connectivity errors are surfaced in the body for debugging.
    body = {"status": "ok" if db_status == "ok" else "degraded", "db": db_status, "version": _version}
    if db_error:
        body["db_error"] = db_error
    return JSONResponse(content=body, status_code=200)


@app.get("/models", tags=["system"], summary="List available LLM models")
def models():
    return [
        {
            "model_id": m.model_id,
            "provider": m.provider,
            "context_window": m.context_window,
            "tags": m.tags,
            "capabilities": m.capabilities,
        }
        for m in list_models()
    ]


@app.get("/status", tags=["system"], summary="Aggregate usage stats (admin)")
def status(_: None = Depends(get_admin_user)):
    """Global token usage and session counts."""
    from sqlalchemy import func
    from .db import Conversation, Transaction
    db = SessionLocal()
    try:
        total_in = db.query(func.sum(Conversation.token_usage_input)).scalar() or 0
        total_out = db.query(func.sum(Conversation.token_usage_output)).scalar() or 0
        sessions = db.query(Conversation).count()
        total_deducted = (
            db.query(func.sum(Transaction.amount))
            .filter(Transaction.kind == "deduction")
            .scalar() or 0
        )
    finally:
        db.close()

    return {
        "sessions": sessions,
        "total_input_tokens": int(total_in),
        "total_output_tokens": int(total_out),
        "total_credits_deducted": abs(float(total_deducted)),
    }


@app.get("/api/releases", tags=["system"], summary="Get parsed CHANGELOG.md")
def get_changelog():
    import os
    import re
    import datetime
    
    changelog_path = _find_changelog_path()
    if not changelog_path:
        return []

    try:
        with open(changelog_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        logger.error(f"Failed to read changelog file: {e}")
        return []

    versions = []
    current_version = None
    current_group = None

    type_map = {
        "added": "feature",
        "changed": "update",
        "fixed": "fix",
        "security": "security"
    }

    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
            
        ver_match = re.match(r"^##\s+\[?([0-9a-zA-Z\.\-]+)\]?\s*-\s*([0-9]{4}-[0-9]{2}-[0-9]{2})", line)
        if ver_match:
            version_str = ver_match.group(1)
            date_str = ver_match.group(2)
            try:
                dt = datetime.datetime.strptime(date_str, "%Y-%m-%d")
                date_str = dt.strftime("%B %d, %Y")
            except Exception:
                pass
                
            current_version = {
                "version": version_str,
                "date": date_str,
                "changes": []
            }
            versions.append(current_version)
            current_group = None
            continue

        group_match = re.match(r"^###\s+(.+)$", line)
        if group_match and current_version is not None:
            group_name = group_match.group(1).lower().strip()
            group_type = type_map.get(group_name, "update")
            
            current_group = {
                "type": group_type,
                "items": []
            }
            current_version["changes"].append(current_group)
            continue

        item_match = re.match(r"^[\-\*]\s+(.+)$", line)
        if item_match and current_group is not None:
            item_text = item_match.group(1)
            item_text = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", item_text)
            current_group["items"].append(item_text)

    return versions


# ── Global error handler ──────────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(
        "unhandled_exception",
        extra={"path": request.url.path, "error": str(exc)},
        exc_info=True,
    )
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})

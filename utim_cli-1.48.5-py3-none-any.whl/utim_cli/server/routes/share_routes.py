import os
import json
import uuid
import datetime
import shutil
import logging
from pathlib import Path
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy.orm import Session
from ..auth import get_current_user
from ..db import User, Plan, get_db

router = APIRouter(prefix="/shares", tags=["shares"])
logger = logging.getLogger("utim.routes.shares")

# Storage directory on the server
STORAGE_DIR = Path("server_shares")
STORAGE_DIR.mkdir(exist_ok=True)
META_FILE = STORAGE_DIR / "meta.json"

def load_meta() -> dict:
    if META_FILE.exists():
        try:
            with open(META_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_meta(meta: dict):
    try:
        with open(META_FILE, 'w', encoding='utf-8') as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

def clean_expired():
    """Scan and remove expired zips and metadata."""
    meta = load_meta()
    now = datetime.datetime.now(datetime.timezone.utc)
    updated_meta = {}
    changed = False

    for share_id, info in meta.items():
        try:
            expires_at = datetime.datetime.fromisoformat(info["expires_at"])
            if now > expires_at:
                # Expired - delete file
                file_path = STORAGE_DIR / f"{share_id}.zip"
                if file_path.exists():
                    try:
                        file_path.unlink()
                    except Exception:
                        pass
                changed = True
            else:
                updated_meta[share_id] = info
        except Exception:
            changed = True

    if changed:
        save_meta(updated_meta)

@router.post("/upload")
async def upload_share(
    file: UploadFile = File(...),
    expires: str = Form("1h"),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Clean expired files first
    clean_expired()

    # Determine user's plan and its share limit
    sub = user.subscription
    plan = sub.plan if sub else None
    if not plan:
        plan_id_for_query = sub.plan_id if sub else "free"
        plan = db.query(Plan).filter(Plan.id == plan_id_for_query).first()

    plan_key = (plan.id or "free").lower() if plan else "free"
    
    # 1GB for max_plan/ultimate/team/enterprise, 500MB for professional/max, 300MB for starter/pro, 150MB for hobby, 75MB for free
    limit_map = {
        "free": 75 * 1024 * 1024,
        "hobby": 150 * 1024 * 1024,
        "pro": 300 * 1024 * 1024,
        "starter": 300 * 1024 * 1024,
        "max": 500 * 1024 * 1024,
        "professional": 500 * 1024 * 1024,
        "ultimate": 1024 * 1024 * 1024,
    }
    
    limit_bytes = limit_map.get(plan_key, 75 * 1024 * 1024)
    
    # Determine the uploaded file size
    try:
        file.file.seek(0, os.SEEK_END)
        file_size = file.file.tell()
        file.file.seek(0)
    except Exception:
        file_size = 0
        
    if file_size > limit_bytes:
        limit_mb = int(limit_bytes / (1024 * 1024))
        raise HTTPException(
            status_code=413,
            detail=f"Shared package size ({file_size / (1024 * 1024):.2f} MB) exceeds the limit for your plan ({limit_mb} MB). Please upgrade your plan."
        )

    share_id = f"share_{uuid.uuid4().hex[:12]}"
    
    # Calculate expiry time
    now = datetime.datetime.now(datetime.timezone.utc)
    if expires == "15m":
        delta = datetime.timedelta(minutes=15)
    elif expires == "1h":
        delta = datetime.timedelta(hours=1)
    elif expires == "4h":
        delta = datetime.timedelta(hours=4)
    elif expires == "1d":
        delta = datetime.timedelta(days=1)
    elif expires == "3d":
        delta = datetime.timedelta(days=3)
    elif expires == "7d":
        delta = datetime.timedelta(days=7)
    else:
        delta = datetime.timedelta(hours=1)  # Default 1h

    expires_at = now + delta

    # Save the uploaded file
    filepath = STORAGE_DIR / f"{share_id}.zip"
    try:
        with open(filepath, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        logger.error(f"failed_to_save_share_file: {e}")
        raise HTTPException(status_code=500, detail="Failed to save shared package file.")

    # Save metadata
    meta = load_meta()
    meta[share_id] = {
        "id": share_id,
        "filename": file.filename,
        "created_at": now.isoformat(),
        "expires_at": expires_at.isoformat()
    }
    save_meta(meta)

    # Construct link
    server_url = os.environ.get("SERVER_URL", "https://api.utim.dev")
    # Remove trailing slash from server_url if present
    server_url = server_url.rstrip("/")
    link = f"{server_url}/shares/download/{share_id}"

    return {"success": True, "link": link, "expires_at": expires_at.isoformat()}

@router.get("/download/{share_id}")
async def download_share(share_id: str):
    # Clean expired files first
    clean_expired()

    meta = load_meta()
    if share_id not in meta:
        raise HTTPException(status_code=404, detail="Shared package does not exist or has expired.")

    info = meta[share_id]
    now = datetime.datetime.now(datetime.timezone.utc)
    try:
        expires_at = datetime.datetime.fromisoformat(info["expires_at"])
        if now > expires_at:
            # Delete expired file
            file_path = STORAGE_DIR / f"{share_id}.zip"
            if file_path.exists():
                try:
                    file_path.unlink()
                except Exception:
                    pass
            # Remove from meta
            del meta[share_id]
            save_meta(meta)
            raise HTTPException(status_code=410, detail="This shared package has expired.")
    except Exception:
        raise HTTPException(status_code=404, detail="Error validating share expiration.")

    filepath = STORAGE_DIR / f"{share_id}.zip"
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="Shared package file not found on server.")

    return FileResponse(
        path=str(filepath),
        media_type="application/zip",
        filename=info["filename"]
    )

@router.delete("/delete/{share_id}")
async def delete_share(share_id: str):
    meta = load_meta()
    if share_id in meta:
        file_path = STORAGE_DIR / f"{share_id}.zip"
        if file_path.exists():
            try:
                file_path.unlink()
            except Exception:
                pass
        del meta[share_id]
        save_meta(meta)
        return {"success": True, "detail": "Shared package deleted successfully from server."}
    raise HTTPException(status_code=404, detail="Shared package not found on server.")
